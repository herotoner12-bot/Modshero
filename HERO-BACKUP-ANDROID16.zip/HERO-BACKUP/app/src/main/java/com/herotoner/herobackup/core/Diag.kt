package com.herotoner.herobackup.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يعرض الاستثناء الحقيقي كما هو: النوع والرسالة وأول أسطر المكدس والسبب الجذري. */
object ErrorInfo {
    fun describe(t: Throwable, frames: Int = 3): String {
        val sb = StringBuilder(t.javaClass.name)
        t.message?.let { sb.append(": ").append(it) }
        for (f in t.stackTrace.take(frames)) sb.append("\n  at ").append(f)
        var c = t.cause
        var depth = 0
        while (c != null && depth < 3) {
            sb.append("\n  caused by ").append(c.javaClass.name)
            c.message?.let { sb.append(": ").append(it) }
            c = c.cause
            depth++
        }
        return sb.toString()
    }
}

/** سجل مراحل بسعة محددة (الأقدم يُحذف أولاً) يُعرض داخل التطبيق ويُكتب أيضاً في Logcat. */
class TraceLog(private val capacity: Int = 300, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val items = ArrayDeque<String>()

    @Synchronized
    fun add(stage: String, msg: String, t: Throwable? = null) {
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(clock()))
        val line = StringBuilder("$time [$stage] $msg")
        if (t != null) line.append('\n').append(ErrorInfo.describe(t))
        items.addLast(line.toString())
        while (items.size > capacity) items.removeFirst()
    }

    @Synchronized
    fun lines(): List<String> = items.toList()

    @Synchronized
    fun clear() = items.clear()
}
