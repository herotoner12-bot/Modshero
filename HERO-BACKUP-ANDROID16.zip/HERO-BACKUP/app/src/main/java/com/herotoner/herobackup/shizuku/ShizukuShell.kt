package com.herotoner.herobackup.shizuku

import com.herotoner.herobackup.core.ErrorInfo
import rikka.shizuku.Shizuku
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * تنفيذ أوامر shell عبر Shizuku دون الاعتماد على UserService (المعطوبة في حالتنا): newProcess في Shizuku API 13.1.5
 * خاصة (private) لكنها موجودة، ويُستدعى عبر reflection كما فعل المصدر الرسمي قبل إخفائها. تُستخدم للتشخيص فقط (قراءة).
 */
object ShizukuShell {
    data class Result(val ok: Boolean, val exit: Int, val out: String, val error: String?)

    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java,
        ).also { it.isAccessible = true }
    }

    fun run(cmd: String, timeoutMs: Long = 20_000): Result {
        return try {
            val p = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val sb = StringBuilder()
            val readOut = thread(name = "shz-out") {
                try { p.inputStream.bufferedReader().forEachLine { synchronized(sb) { sb.appendLine(it) } } } catch (e: Exception) { }
            }
            val readErr = thread(name = "shz-err") {
                try { p.errorStream.bufferedReader().forEachLine { synchronized(sb) { sb.appendLine(it) } } } catch (e: Exception) { }
            }
            var exit = -1
            val waiter = thread(name = "shz-wait") { exit = try { p.waitFor() } catch (e: Exception) { -1 } }
            waiter.join(timeoutMs)
            if (waiter.isAlive) {
                try { p.destroy() } catch (e: Exception) { }
                ShizukuHelper.log("SHELL", "انتهت مهلة الأمر ($timeoutMs ms): $cmd")
                return Result(false, -1, synchronized(sb) { sb.toString() }, "انتهت المهلة")
            }
            readOut.join(TimeUnit.SECONDS.toMillis(3))
            readErr.join(TimeUnit.SECONDS.toMillis(3))
            val text = synchronized(sb) { sb.toString() }
            ShizukuHelper.log("SHELL", "exit=$exit: ${cmd.take(120)}")
            Result(exit == 0, exit, text, null)
        } catch (e: InvocationTargetException) {
            val t = e.targetException ?: e
            ShizukuHelper.log("SHELL", "newProcess رمى استثناءً: ${cmd.take(80)}", t)
            Result(false, -1, "", ErrorInfo.describe(t))
        } catch (t: Throwable) {
            ShizukuHelper.log("SHELL", "تعذر استدعاء newProcess", t)
            Result(false, -1, "", ErrorInfo.describe(t))
        }
    }
}
