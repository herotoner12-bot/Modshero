package com.herotoner.herobackup.work

import android.content.Context
import androidx.work.Data
import androidx.work.workDataOf
import com.herotoner.herobackup.core.Json
import com.herotoner.herobackup.core.Progress
import java.io.File

object Jobs {
    const val UNIQUE = "hero-job"
    const val TAG_BACKUP = "backup"
    const val TAG_RESTORE = "restore"
    const val TAG_TRANSFER = "transfer"
    const val TAG_CONVERT = "convert"

    const val K_STATUS = "status"
    const val K_BACKUP_ID = "backupId"
    const val K_CODE = "code"
    const val K_NAME = "name"
    const val K_SOURCES = "sources"
    const val K_DEST = "dest"
    const val K_POLICY = "policy"
    const val K_MODE = "mode"
    const val K_URI = "uri"

    const val ST_SUCCESS = "SUCCESS"
    const val ST_CANCELLED = "CANCELLED"
    const val ST_EMPTY = "EMPTY"
    const val ST_FAILED = "FAILED"

    private const val P_FILES_DONE = "p_fd"
    private const val P_FILES_TOTAL = "p_ft"
    private const val P_BYTES_DONE = "p_bd"
    private const val P_BYTES_TOTAL = "p_bt"
    private const val P_CURRENT = "p_cur"

    fun Progress.toData(): Data = workDataOf(
        P_FILES_DONE to filesDone, P_FILES_TOTAL to filesTotal,
        P_BYTES_DONE to bytesDone, P_BYTES_TOTAL to bytesTotal,
        P_CURRENT to current.take(120),
    )

    fun Data.toProgress(): Progress? {
        if (!keyValueMap.containsKey(P_FILES_TOTAL)) return null
        return Progress(
            getInt(P_FILES_DONE, 0), getInt(P_FILES_TOTAL, 0),
            getLong(P_BYTES_DONE, 0L), getLong(P_BYTES_TOTAL, 0L),
            getString(P_CURRENT) ?: "",
        )
    }
}

/** ملفات صغيرة لتمرير قوائم كبيرة وتقارير النتائج (حد Data في WorkManager هو 10KB). */
object JobFiles {
    private fun dir(ctx: Context) = File(ctx.filesDir, "jobs").also { it.mkdirs() }

    fun writeSelection(ctx: Context, paths: Collection<String>) {
        File(dir(ctx), "selection.json").writeText(Json.stringify(paths.toList()))
    }

    fun readSelection(ctx: Context): List<String> {
        val f = File(dir(ctx), "selection.json")
        if (!f.isFile) return emptyList()
        return (Json.parse(f.readText()) as List<*>).map { it as String }
    }

    fun writeReport(ctx: Context, type: String, json: String) {
        File(dir(ctx), "report-$type.json").writeText(json)
    }

    fun readReport(ctx: Context, type: String): String? {
        val f = File(dir(ctx), "report-$type.json")
        return if (f.isFile) f.readText() else null
    }

    fun clearReport(ctx: Context, type: String) {
        File(dir(ctx), "report-$type.json").delete()
    }
}
