package com.herotoner.herobackup.core

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

sealed interface BackupOutcome {
    data class Success(val manifest: Manifest) : BackupOutcome
    data object Cancelled : BackupOutcome
    data object EmptySource : BackupOutcome
    data class Failed(val code: String, val failures: List<FailureEntry> = emptyList()) : BackupOutcome
}

class BackupEngine(
    private val repo: BackupRepository,
    private val now: () -> Long = { System.currentTimeMillis() },
    private val bufferSize: Int = 64 * 1024,
    private val freeSpace: () -> Long = { repo.root.usableSpace },
) {
    private fun newId(): String {
        val ts = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(now()))
        return ts + "-" + Hashing.hex(Random.nextBytes(4))
    }

    fun run(
        roots: List<SourceRoot>,
        name: String,
        appVersion: String,
        cancel: () -> Boolean = { false },
        onProgress: (Progress) -> Unit = {},
    ): BackupOutcome {
        repo.root.mkdirs()
        val id = newId()
        val tmp = File(repo.root, BackupRepository.TMP_PREFIX + id)
        try {
            val rootNames = Names.uniqueRootNames(roots.map { it.displayName })
            val files = ArrayList<Pair<List<String>, SourceNode>>()
            val emptyDirs = ArrayList<String>()
            val failures = ArrayList<FailureEntry>()
            var bytesTotal = 0L

            val visitor = object : WalkVisitor {
                override fun onFile(parts: List<String>, node: SourceNode) {
                    files += parts to node
                    if (node.size > 0) bytesTotal += node.size
                }

                override fun onEmptyDir(parts: List<String>) { emptyDirs += parts.joinToString("/") }
                override fun onFailure(path: String, code: String, detail: String) {
                    failures += FailureEntry(path, code, detail)
                }
            }
            roots.forEachIndexed { i, r -> Scanner.walk(r.node, rootNames[i], visitor, cancel) }

            if (files.isEmpty()) {
                return if (failures.isEmpty()) BackupOutcome.EmptySource
                else BackupOutcome.Failed(failures.first().code, failures)
            }
            if (freeSpace() < bytesTotal) return BackupOutcome.Failed(FailureCode.NO_SPACE)

            val dataDir = File(tmp, BackupRepository.DATA)
            if (!dataDir.mkdirs() && !dataDir.isDirectory) throw IOException("تعذر إنشاء مجلد النسخة")

            val used = HashSet<String>()
            val entries = ArrayList<FileEntry>(files.size)
            var bytesDone = 0L
            var lastEmit = 0L
            fun emit(done: Int, current: String, force: Boolean) {
                val t = System.nanoTime()
                if (force || t - lastEmit > 100_000_000L) {
                    lastEmit = t
                    onProgress(Progress(done, files.size, bytesDone, bytesTotal, current))
                }
            }

            files.forEachIndexed { index, (parts, node) ->
                if (cancel()) throw OperationCancelled()
                val path = parts.joinToString("/")
                val stored = Names.uniqueStored(parts, used)
                val out = File(dataDir, stored)
                emit(index, parts.last(), true)
                try {
                    out.parentFile?.mkdirs()
                    val md = MessageDigest.getInstance("SHA-256")
                    var size = 0L
                    node.openInput().use { input ->
                        FileOutputStream(out).use { os ->
                            val buf = ByteArray(bufferSize)
                            while (true) {
                                if (cancel()) throw OperationCancelled()
                                val n = input.read(buf)
                                if (n < 0) break
                                md.update(buf, 0, n)
                                os.write(buf, 0, n)
                                size += n
                                bytesDone += n
                                emit(index, parts.last(), false)
                            }
                            os.flush()
                            os.fd.sync()
                        }
                    }
                    val hash = Hashing.hex(md.digest())
                    // تحقق ثانٍ من النسخة المكتوبة فعلياً
                    val again = Hashing.sha256(out, bufferSize, cancel)
                    if (again != hash) {
                        out.delete()
                        failures += FailureEntry(path, FailureCode.VERIFY_FAILED)
                    } else {
                        entries += FileEntry(path, stored, size, hash, node.lastModified)
                    }
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: SecurityException) {
                    out.delete()
                    failures += FailureEntry(path, FailureCode.PERMISSION_DENIED, e.message ?: "")
                } catch (e: Exception) {
                    out.delete()
                    failures += FailureEntry(path, FailureCode.IO_ERROR, e.message ?: "")
                }
            }
            emit(files.size, "", true)
            if (cancel()) throw OperationCancelled()

            if (entries.isEmpty()) {
                tmp.deleteRecursively()
                return BackupOutcome.Failed(failures.firstOrNull()?.code ?: FailureCode.IO_ERROR, failures)
            }

            val manifest = Manifest(
                formatVersion = 1,
                id = id,
                name = name.ifBlank { id },
                createdAt = now(),
                appVersion = appVersion,
                status = if (failures.isEmpty()) BackupStatus.COMPLETE else BackupStatus.PARTIAL,
                roots = rootNames,
                files = entries,
                emptyDirs = emptyDirs,
                failures = failures,
            )
            repo.commit(tmp, manifest)
            return BackupOutcome.Success(manifest)
        } catch (e: OperationCancelled) {
            tmp.deleteRecursively()
            return BackupOutcome.Cancelled
        } catch (e: Exception) {
            tmp.deleteRecursively()
            return BackupOutcome.Failed(FailureCode.IO_ERROR, listOf(FailureEntry("", FailureCode.IO_ERROR, e.message ?: "")))
        }
    }
}
