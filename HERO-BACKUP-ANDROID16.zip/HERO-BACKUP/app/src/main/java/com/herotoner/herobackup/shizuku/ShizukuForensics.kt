package com.herotoner.herobackup.shizuku

import android.content.Context
import android.os.SystemClock
import com.herotoner.herobackup.core.CheckResult
import com.herotoner.herobackup.core.CheckStatus
import com.herotoner.herobackup.core.ServiceStartAnalyzer
import com.herotoner.herobackup.data.McPackages
import kotlinx.coroutines.delay
import java.io.File

/**
 * تشخيص عميق لسبب عدم بدء خدمة المستخدم، يعتمد على أدلة حقيقية فقط:
 * 1) إعادة تنفيذ خطوات UserService.create (من المصدر الرسمي) يدوياً من shell عبر app_process مع PingMain.
 * 2) محاولة bindUserService حقيقية مع أخذ عينات من قائمة العمليات (هل أُنشئت عملية الخدمة؟) والانتظار حتى 35 ثانية
 *    (مهلة خادم Shizuku الرسمية 30 ثانية) دون قتل المحاولة.
 * 3) جمع Logcat من shell (وليس من التطبيق) خلال المحاولة، وفلترته، وتحليله.
 */
object ShizukuForensics {
    const val G = "تشخيص عميق لفشل بدء خدمة المستخدم"
    private const val WAIT_MS = 35_000L

    suspend fun run(ctx: Context, emit: (CheckResult) -> Unit): String {
        val raw = StringBuilder()
        fun row(t: String, s: CheckStatus, d: String = "") = emit(CheckResult(G, t, s, d))
        fun section(title: String, body: String) {
            raw.append("\n===== ").append(title).append(" =====\n").append(body.take(120_000)).append('\n')
        }
        val pkg = ctx.packageName
        val apk = ctx.applicationInfo.sourceDir
        ShizukuHelper.init(ctx)
        ShizukuHelper.refresh()
        ShizukuHelper.log("FORENSICS", "بدء التشخيص العميق: pkg=$pkg apk=$apk")

        // 0) هل نستطيع أصلاً تشغيل أوامر shell عبر Shizuku؟
        val id = ShizukuShell.run("id")
        if (!id.ok) {
            row("تشغيل أوامر shell عبر Shizuku (newProcess)", CheckStatus.FAIL, id.error ?: id.out)
            row("الخلاصة", CheckStatus.FAIL, "تعذر تنفيذ أوامر shell عبر Shizuku، فلا يمكن جمع الأدلة. تأكد أن Shizuku يعمل وأن الصلاحية GRANTED.")
            return raw.toString()
        }
        row("هوية عملية Shizuku (id)", CheckStatus.INFO, id.out.trim())
        section("id", id.out)

        // البيئة
        val env = ShizukuShell.run(
            "echo enforce=\$(getenforce); echo sdk=\$(getprop ro.build.version.sdk); echo release=\$(getprop ro.build.version.release); " +
                "echo mfr=\$(getprop ro.product.manufacturer); echo model=\$(getprop ro.product.model); " +
                "echo incremental=\$(getprop ro.build.version.incremental); echo miui=\$(getprop ro.miui.ui.version.name); " +
                "echo hyperos=\$(getprop ro.mi.os.version.name); " +
                "dumpsys package moe.shizuku.privileged.api | grep -E 'versionName|versionCode' | head -2",
        )
        row("بيئة الجهاز وإصدار Shizuku", CheckStatus.INFO, env.out.trim().lines().joinToString(" | "))
        section("env", env.out)

        // ملف الـ APK
        val ls = ShizukuShell.run("ls -l '$apk'; ls -ld '${File(apk).parent}'; ls -l '${File(apk).parent}/lib' 2>&1 | head -5")
        row("قراءة مسار الـ APK من shell", if (ls.ok) CheckStatus.PASS else CheckStatus.FAIL, ls.out.trim().lines().joinToString(" | "))
        section("apk", ls.out)

        // 1) إعادة تنفيذ خطوات UserService.create يدوياً
        val userId = McPackages.userId()
        val replicaCmd = "CLASSPATH='$apk' app_process /system/bin com.herotoner.herobackup.shizuku.PingMain $pkg ${PingService::class.java.name} $userId 2>&1"
        row("إعادة تنفيذ خطوات UserService.create من shell…", CheckStatus.INFO, "قد تستغرق عدة ثوانٍ")
        val replica = ShizukuShell.run(replicaCmd, 90_000)
        val replicaLines = replica.out.lines().filter { it.isNotBlank() }
        section("PingMain (replica of UserService.create)", replica.out + (replica.error?.let { "\nERROR: $it" } ?: ""))
        if (replica.error != null && replicaLines.isEmpty()) row("PingMain", CheckStatus.FAIL, replica.error)
        for (l in replicaLines) {
            val m = Regex("^STEP (\\d+) (OK|FAIL): (.*)$").find(l)
            if (m != null) row("خطوة ${m.groupValues[1]}: ${m.groupValues[3]}", if (m.groupValues[2] == "OK") CheckStatus.PASS else CheckStatus.FAIL)
            else if (l.startsWith("RESULT")) row(l, CheckStatus.PASS)
            else if (l.startsWith("  ")) row("   ↳", CheckStatus.INFO, l.trim())
        }
        if (replicaLines.none { it.startsWith("STEP") }) {
            row("PingMain لم يطبع أي خطوة", CheckStatus.FAIL, replica.out.trim().take(600).ifBlank { "لا مخرجات" })
        }

        // 2) محاولة bindUserService حقيقية مع عينات ps
        val t0 = ShizukuShell.run("date '+%m-%d %H:%M:%S.000'").out.trim().lines().firstOrNull().orEmpty()
        ShizukuHelper.pingHandle.unbind(true)
        val start = SystemClock.elapsedRealtime()
        ShizukuHelper.pingHandle.bind(ctx, 0)
        val bindEx = ShizukuHelper.pingHandle.bindException
        if (bindEx != null) row("bindUserService", CheckStatus.FAIL, com.herotoner.herobackup.core.ErrorInfo.describe(bindEx))
        else row("bindUserService (PingService)", CheckStatus.PASS, "عاد دون استثناء؛ ننتظر حتى ${WAIT_MS / 1000} ثانية ولا نقتل المحاولة")
        val psSamples = ArrayList<String>()
        var connectedAfter: Long? = null
        val marks = listOf(1, 3, 6, 10, 15, 20, 25, 30, 35).map { it * 1000L }
        var next = 0
        while (bindEx == null && SystemClock.elapsedRealtime() - start < WAIT_MS) {
            if (ShizukuHelper.pingHandle.flow.value != null) { connectedAfter = SystemClock.elapsedRealtime() - start; break }
            if (ShizukuHelper.pingHandle.callbackSeen && ShizukuHelper.pingHandle.verifyError != null) break
            val el = SystemClock.elapsedRealtime() - start
            if (next < marks.size && el >= marks[next]) {
                val ps = ShizukuShell.run("ps -A | grep -E 'herotoner|shizuku|app_process' | grep -v grep", 10_000)
                val lines = ps.out.trim().lines().filter { it.isNotBlank() }
                for (l in lines) psSamples += "t=${el / 1000}s | $l"
                if (lines.isEmpty()) psSamples += "t=${el / 1000}s | (لا عمليات مطابقة)"
                next++
            }
            delay(200)
        }
        section("ps samples", psSamples.joinToString("\n"))
        row("نتيجة المحاولة الفعلية", if (connectedAfter != null) CheckStatus.PASS else CheckStatus.FAIL,
            if (connectedAfter != null) "وصل onServiceConnected بعد $connectedAfter مللي ثانية" else "لم يصل خلال ${WAIT_MS / 1000} ثانية")
        val procRows = psSamples.filter { it.contains("$pkg:") }
        row("عملية الخدمة في قائمة العمليات", if (procRows.isNotEmpty()) CheckStatus.PASS else CheckStatus.WARN,
            if (procRows.isNotEmpty()) procRows.first() else "لم تظهر عملية باسم $pkg:* في أي عينة")
        ShizukuHelper.pingHandle.unbind(true)

        // 3) Logcat من shell أثناء المحاولة
        var lc = ShizukuShell.run("logcat -b all -d -v threadtime -T '$t0' 2>&1 | tail -n 5000", 40_000)
        if (lc.out.isBlank() || lc.out.contains("Invalid") || lc.out.contains("usage:")) {
            lc = ShizukuShell.run("logcat -b all -d -v threadtime -t 5000 2>&1", 40_000)
        }
        val logLines = lc.out.lines()
        section("logcat since $t0", lc.out)
        val rel = ServiceStartAnalyzer.relevantLogLines(pkg, logLines)
        row("Logcat خلال المحاولة", if (logLines.size > 5) CheckStatus.INFO else CheckStatus.WARN,
            "${logLines.size} سطر مجموع، ${rel.size} سطر ذو صلة" + if (logLines.size <= 5) " (قد يحجب النظام السجل)" else "")
        for (l in rel.takeLast(80)) row("log", CheckStatus.INFO, l.take(300))

        // 4) التحليل
        val findings = ServiceStartAnalyzer.analyze(pkg, replicaLines, logLines, psSamples, connectedAfter)
        for (f in findings) row(f.title, f.severity, f.evidence.joinToString("\n"))
        val proven = findings.firstOrNull { it.title.startsWith("سبب مثبت") }
        row("الخلاصة", if (proven != null) CheckStatus.FAIL else if (connectedAfter != null) CheckStatus.PASS else CheckStatus.WARN,
            proven?.title ?: if (connectedAfter != null) "الخدمة اتصلت في هذه المحاولة (مهلة أطول من السابق كانت كافية)" else "لا سبب مثبت بالأدلة المتاحة؛ أرسل التقرير الكامل.")
        ShizukuHelper.log("FORENSICS", "انتهى التشخيص العميق: ${proven?.title ?: "بلا سبب مثبت"}")
        return raw.toString()
    }
}
