package com.herotoner.herobackup.core

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

/** يُرمى عند طلب المستخدم إلغاء العملية؛ يُلتقط داخل المحركات فقط. */
class OperationCancelled : RuntimeException("تم إلغاء العملية")

object Hashing {
    private val HEX = "0123456789abcdef".toCharArray()

    fun hex(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            out[i * 2] = HEX[v ushr 4]
            out[i * 2 + 1] = HEX[v and 0x0F]
        }
        return String(out)
    }

    fun sha256(bytes: ByteArray): String =
        hex(MessageDigest.getInstance("SHA-256").digest(bytes))

    /** يحسب SHA-256 على دفعات دون تحميل الملف كاملاً في الذاكرة. */
    fun sha256(file: File, bufferSize: Int = 64 * 1024, cancel: () -> Boolean = { false }): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(bufferSize)
            while (true) {
                if (cancel()) throw OperationCancelled()
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return hex(md.digest())
    }
}
