package com.herotoner.herobackup.shizuku

import android.content.Context
import android.os.SystemClock
import com.herotoner.herobackup.core.CheckResult
import com.herotoner.herobackup.core.CheckStatus
import com.herotoner.herobackup.core.ErrorInfo
import com.herotoner.herobackup.core.Remote
import com.herotoner.herobackup.core.RemoteProtocol
import kotlinx.coroutines.delay

/**
 * اختبار اتصال Binder مستقل: لا يلمس أي ملف من Minecraft. ينفّذ مراحل حقيقية ويعرض نتيجة كل مرحلة
 * والاستثناء الحقيقي إن وُجد. «Shizuku متصل» وحده ليس دليلاً على اتصال خدمة الملفات؛ هذا الاختبار يثبت ذلك أو ينفيه.
 */
object ShizukuDiag {
    const val G1 = "1) Shizuku (الخادم وصلاحية التطبيق)"
    const val G2 = "2) خدمة Binder بسيطة (PingService، Java خالصة)"
    const val G3 = "3) خدمة الملفات (FileService)"
    const val G4 = "الخلاصة"

    private enum class Wait { CONNECTED, NO_CALLBACK, UNUSABLE, BIND_FAILED }

    private suspend fun bindAndWait(
        ctx: Context, h: ShizukuHelper.Handle<*>, group: String, out: MutableList<CheckResult>,
    ): Wait {
        var last = Wait.NO_CALLBACK
        for (attempt in 0..1) {
            h.unbind(true) // ننظف أي سجل خدمة قديم عالق قبل كل محاولة
            val t0 = SystemClock.elapsedRealtime()
            h.bind(ctx, attempt)
            val ex = h.bindException
            if (ex != null) {
                out += CheckResult(group, "bindUserService (محاولة ${attempt + 1}، suffix=${h.currentSuffix})", CheckStatus.FAIL, "رمى استثناءً:\n" + ErrorInfo.describe(ex))
                last = Wait.BIND_FAILED
                continue
            }
            out += CheckResult(group, "bindUserService (محاولة ${attempt + 1}، suffix=${h.currentSuffix})", CheckStatus.PASS, "عاد دون استثناء")
            var result = Wait.NO_CALLBACK
            while (SystemClock.elapsedRealtime() - t0 < 8000) {
                if (h.flow.value != null) { result = Wait.CONNECTED; break }
                if (h.callbackSeen && h.verifyError != null) { result = Wait.UNUSABLE; break }
                delay(100)
            }
            val ms = SystemClock.elapsedRealtime() - t0
            when (result) {
                Wait.CONNECTED -> {
                    out += CheckResult(group, "onServiceConnected", CheckStatus.PASS, "وصل بعد $ms مللي ثانية\n${h.binderInfo}")
                    if (attempt > 0) out += CheckResult(group, "ملاحظة", CheckStatus.WARN, "نجح الربط بعد إعادته بمعرّف عملية جديد: كان هناك سجل خدمة قديم عالق في Shizuku")
                    return Wait.CONNECTED
                }
                Wait.UNUSABLE -> out += CheckResult(group, "onServiceConnected", CheckStatus.FAIL, "وصل لكن الخدمة غير صالحة:\n${h.verifyError}\n${h.binderInfo}")
                else -> out += CheckResult(group, "onServiceConnected", CheckStatus.FAIL,
                    "لم يصل خلال 8 ثوانٍ: لم تبدأ عملية الخدمة أو تعطلت عند البدء. بعد هذا الاختبار راجع Logcat (HeroShizuku وHeroPingService وHeroFileService) وسجل Shizuku نفسه.")
            }
            last = result
        }
        return last
    }

    suspend fun connectionTest(ctx: Context): List<CheckResult> {
        val out = ArrayList<CheckResult>()
        ShizukuHelper.init(ctx)
        ShizukuHelper.refresh()
        ShizukuHelper.log("TEST", "بدء اختبار اتصال Binder")
        val s = ShizukuHelper.snapshot(ctx)
        out += CheckResult(G1, "تطبيق Shizuku", if (s.installed || s.binderAlive) CheckStatus.PASS else CheckStatus.FAIL, if (s.installed || s.binderAlive) "مثبّت" else "غير مثبّت")
        out += CheckResult(G1, "خادم Shizuku (pingBinder)", if (s.binderAlive) CheckStatus.PASS else CheckStatus.FAIL,
            if (s.binderAlive) "يعمل، إصدار API ${s.serverVersion}" else "لا يستجيب (غير مشغّل)")
        out += CheckResult(G1, "صلاحية HERO BACKUP", if (s.permission == "GRANTED") CheckStatus.PASS else CheckStatus.FAIL, s.permission)
        if (!s.binderAlive || s.permission != "GRANTED") {
            out += CheckResult(G4, "النتيجة", CheckStatus.FAIL, "لا يمكن اختبار الخدمات قبل تشغيل Shizuku ومنح الصلاحية.")
            return out
        }

        // ---- الخدمة البسيطة ----
        var pingOk = false
        val pr = bindAndWait(ctx, ShizukuHelper.pingHandle, G2, out)
        if (pr == Wait.CONNECTED) {
            pingOk = true
            val p = ShizukuHelper.pingHandle.flow.value
            if (p != null) {
                try {
                    for (line in p.info().trim().lines()) out += CheckResult(G2, "داخل عملية الخدمة", CheckStatus.INFO, line)
                } catch (t: Throwable) {
                    out += CheckResult(G2, "info()", CheckStatus.FAIL, ErrorInfo.describe(t))
                }
                try {
                    for (line in p.checkClasses().trim().lines()) {
                        val parts = line.split('|')
                        if (parts[0] == "OK") out += CheckResult(G2, "تحميل صنف: " + parts.getOrElse(1) { "" }, CheckStatus.PASS, "")
                        else out += CheckResult(G2, "تحميل صنف: " + parts.getOrElse(1) { "" }, CheckStatus.FAIL, parts.drop(2).joinToString("|"))
                    }
                } catch (t: Throwable) {
                    out += CheckResult(G2, "checkClasses()", CheckStatus.FAIL, ErrorInfo.describe(t))
                }
            }
        }
        ShizukuHelper.pingHandle.unbind(true)

        // ---- خدمة الملفات ----
        var fileOk = false
        val fr = bindAndWait(ctx, ShizukuHelper.fileHandle, G3, out)
        if (fr == Wait.CONNECTED) {
            val f = ShizukuHelper.fileHandle.flow.value
            if (f != null) {
                try {
                    val uid = f.getUid()
                    out += CheckResult(G3, "getUid()", CheckStatus.PASS, "uid=$uid، apiVersion=${f.apiVersion()}")
                    val r = RemoteProtocol.decodeStat(f.probe("/"))
                    when (r) {
                        is Remote.Ok -> { out += CheckResult(G3, "probe(\"/\") (ليس مجلد Minecraft)", CheckStatus.PASS, "dir=${r.value.dir}"); fileOk = true }
                        is Remote.Err -> out += CheckResult(G3, "probe(\"/\")", CheckStatus.FAIL, "${r.code}: ${r.message}")
                    }
                } catch (t: Throwable) {
                    out += CheckResult(G3, "استدعاء الخدمة", CheckStatus.FAIL, ErrorInfo.describe(t))
                }
            }
        }

        val conclusion = when {
            pingOk && fileOk -> CheckResult(G4, "النتيجة", CheckStatus.PASS, "Binder وخدمة الملفات يعملان فعلاً. أي فشل لاحق يكون في مرحلة الوصول لمسارات Minecraft وليس في الاتصال.")
            pingOk && !fileOk -> CheckResult(G4, "النتيجة", CheckStatus.FAIL, "الخدمة البسيطة تعمل لكن خدمة الملفات لا تعمل: المشكلة في خدمة الملفات نفسها (تحميل أصنافها أو تعطلها عند البدء). راجع أسطر «تحميل صنف» أعلاه والاستثناء الظاهر.")
            !pingOk && !fileOk -> CheckResult(G4, "النتيجة", CheckStatus.FAIL, "حتى الخدمة البسيطة لا تعمل: المشكلة في تشغيل خدمات المستخدم عبر Shizuku على هذا الجهاز (وضع التشغيل، الإصدار، أو قيد من النظام) وليست في كود خدمة الملفات.")
            else -> CheckResult(G4, "النتيجة", CheckStatus.WARN, "نتيجة غير متوقعة: الخدمة البسيطة فشلت وخدمة الملفات نجحت.")
        }
        out += conclusion
        ShizukuHelper.log("TEST", "انتهى الاختبار: ${conclusion.status} — ${conclusion.detail}")
        return out
    }
}
