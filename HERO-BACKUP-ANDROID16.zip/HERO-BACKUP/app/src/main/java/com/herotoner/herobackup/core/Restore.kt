package com.herotoner.herobackup.core

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.security.MessageDigest

enum class OverwritePolicy { SKIP, RENAME, OVERWRITE }

/** وجهة الاستعادة (مجلد SAF أو File للاختبارات). المسار قائمة مكوّنات. */
interface RestoreTarget {
    fun exists(path: List<String>): Boolean

    /** ينشئ المجلدات الأب عند الحاجة. إن كان truncate=true يُفرَّغ الملف الموجود. */
    @Throws(IOException::class)
    fun openOutput(path: List<String>, truncate: Boolean): OutputStream

    fun delete(path: List<String>)
}

class FileRestoreTarget(private val root: File) : RestoreTarget {
    private fun file(path: List<String>) = path.fold(root) { acc, p -> File(acc, p) }
    override fun exists(path: List<String>) = file(path).exists()
    override fun openOutput(path: List<String>, truncate: Boolean): OutputStream {
        val f = file(path)
        f.parentFile?.mkdirs()
        return FileOutputStream(f, !truncate)
    }

    override fun delete(path: List<String>) { file(path).delete() }
}

data class RestoreReport(
    val restored: List<String>,
    val renamed: List<String>,
    val skipped: List<String>,
    val failed: List<FailureEntry>,
    val cancelled: Boolean,
) {
    fun toJson(): String = Json.stringify(
        linkedMapOf(
            "restored" to restored, "renamed" to renamed, "skipped" to skipped,
            "failed" to failed.map { linkedMapOf("path" to it.path, "code" to it.code, "detail" to it.detail) },
            "cancelled" to cancelled,
        )
    )

    companion object {
        fun fromJson(text: String): RestoreReport {
            val m = Json.parseObject(text)
            fun strs(k: String) = (m[k] as List<*>).map { it as String }
            return RestoreReport(
                restored = strs("restored"), renamed = strs("renamed"), skipped = strs("skipped"),
                failed = (m["failed"] as List<*>).map {
                    val f = it as Map<*, *>
                    FailureEntry(f["path"] as String, f["code"] as String, (f["detail"] as? String) ?: "")
                },
                cancelled = m["cancelled"] as Boolean,
            )
        }
    }
}

class RestoreEngine(private val repo: BackupRepository, private val bufferSize: Int = 64 * 1024) {

    private fun renamedPath(path: List<String>, target: RestoreTarget): List<String> {
        val last = path.last()
        val dot = last.lastIndexOf('.')
        val base = if (dot > 0) last.substring(0, dot) else last
        val ext = if (dot > 0) last.substring(dot) else ""
        var n = 1
        while (true) {
            val label = if (n == 1) "(استعادة)" else "(استعادة $n)"
            val candidate = path.dropLast(1) + "$base $label$ext"
            if (!target.exists(candidate)) return candidate
            n++
        }
    }

    fun restore(
        manifest: Manifest,
        selected: Collection<FileEntry>,
        target: RestoreTarget,
        policy: OverwritePolicy,
        cancel: () -> Boolean = { false },
        onProgress: (Progress) -> Unit = {},
    ): RestoreReport {
        val restored = ArrayList<String>()
        val renamed = ArrayList<String>()
        val skipped = ArrayList<String>()
        val failed = ArrayList<FailureEntry>()
        val bytesTotal = selected.sumOf { it.size }
        var bytesDone = 0L
        var cancelled = false
        try {
            selected.forEachIndexed { index, entry ->
                if (cancel()) throw OperationCancelled()
                onProgress(Progress(index, selected.size, bytesDone, bytesTotal, entry.path.substringAfterLast('/')))
                val src = repo.dataFile(manifest.id, entry.stored)
                if (!src.isFile) {
                    failed += FailureEntry(entry.path, FailureCode.MISSING)
                    return@forEachIndexed
                }
                // 1) تحقق من سلامة الملف المحفوظ قبل أي كتابة
                val actual = try {
                    Hashing.sha256(src, bufferSize, cancel)
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: Exception) {
                    failed += FailureEntry(entry.path, FailureCode.IO_ERROR, e.message ?: "")
                    return@forEachIndexed
                }
                if (actual != entry.sha256) {
                    failed += FailureEntry(entry.path, FailureCode.CORRUPT)
                    return@forEachIndexed
                }
                // 2) سياسة عدم الكتابة فوق الموجود
                var path = entry.path.split('/')
                var truncate = false
                var wasRenamed = false
                if (target.exists(path)) {
                    when (policy) {
                        OverwritePolicy.SKIP -> {
                            skipped += entry.path
                            bytesDone += entry.size
                            return@forEachIndexed
                        }
                        OverwritePolicy.RENAME -> { path = renamedPath(path, target); wasRenamed = true }
                        OverwritePolicy.OVERWRITE -> truncate = true
                    }
                }
                // 3) النسخ مع حساب SHA-256 أثناء الكتابة
                val md = MessageDigest.getInstance("SHA-256")
                try {
                    FileInputStream(src).use { input ->
                        target.openOutput(path, truncate).use { os ->
                            val buf = ByteArray(bufferSize)
                            while (true) {
                                if (cancel()) throw OperationCancelled()
                                val n = input.read(buf)
                                if (n < 0) break
                                md.update(buf, 0, n)
                                os.write(buf, 0, n)
                                bytesDone += n
                            }
                            os.flush()
                        }
                    }
                    if (Hashing.hex(md.digest()) != entry.sha256) {
                        if (!truncate) target.delete(path)
                        failed += FailureEntry(entry.path, FailureCode.VERIFY_FAILED)
                    } else if (wasRenamed) renamed += entry.path else restored += entry.path
                } catch (e: OperationCancelled) {
                    if (!truncate) target.delete(path)
                    throw e
                } catch (e: SecurityException) {
                    if (!truncate) target.delete(path)
                    failed += FailureEntry(entry.path, FailureCode.PERMISSION_DENIED, e.message ?: "")
                } catch (e: Exception) {
                    if (!truncate) target.delete(path)
                    failed += FailureEntry(entry.path, FailureCode.TARGET_ERROR, e.message ?: "")
                }
            }
        } catch (e: OperationCancelled) {
            cancelled = true
        }
        onProgress(Progress(restored.size + renamed.size + skipped.size + failed.size, selected.size, bytesDone, bytesTotal, ""))
        return RestoreReport(restored, renamed, skipped, failed, cancelled)
    }
}

data class VerifyReport(val checked: Int, val corrupted: List<String>, val missing: List<String>) {
    val ok: Boolean get() = corrupted.isEmpty() && missing.isEmpty()
}

object Verifier {
    fun verify(
        repo: BackupRepository,
        manifest: Manifest,
        cancel: () -> Boolean = { false },
        onProgress: (Progress) -> Unit = {},
    ): VerifyReport? {
        val corrupted = ArrayList<String>()
        val missing = ArrayList<String>()
        val total = manifest.totalBytes
        var done = 0L
        try {
            manifest.files.forEachIndexed { i, e ->
                onProgress(Progress(i, manifest.files.size, done, total, e.path.substringAfterLast('/')))
                val f = repo.dataFile(manifest.id, e.stored)
                if (!f.isFile) missing += e.path
                else if (Hashing.sha256(f, cancel = cancel) != e.sha256) corrupted += e.path
                done += e.size
            }
        } catch (e: OperationCancelled) {
            return null
        } catch (e: IOException) {
            return VerifyReport(manifest.files.size, corrupted + "؟", missing)
        }
        return VerifyReport(manifest.files.size, corrupted, missing)
    }
}
