package com.herotoner.herobackup.core

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

data class ExportReport(val alreadyExported: Boolean, val failed: List<FailureEntry>, val cancelled: Boolean) {
    val ok: Boolean get() = !cancelled && failed.isEmpty()
}

data class ImportReport(
    val imported: List<String>,
    val skippedExisting: List<String>,
    val failed: List<FailureEntry>,
    val cancelled: Boolean,
)

/** تصدير نسخة إلى مجلد خارجي واستيرادها من جديد (حتى لا تضيع عند حذف التطبيق). */
class TransferEngine(private val repo: BackupRepository, private val bufferSize: Int = 64 * 1024) {
    companion object { const val EXPORT_DIR = "HERO-BACKUP" }

    fun export(
        manifest: Manifest,
        target: RestoreTarget,
        cancel: () -> Boolean = { false },
        onProgress: (Progress) -> Unit = {},
    ): ExportReport {
        val base = listOf(EXPORT_DIR, manifest.id)
        if (target.exists(base + BackupRepository.MANIFEST)) return ExportReport(true, emptyList(), false)
        val failed = ArrayList<FailureEntry>()
        var done = 0L
        val total = manifest.totalBytes
        try {
            manifest.files.forEachIndexed { i, e ->
                if (cancel()) throw OperationCancelled()
                onProgress(Progress(i, manifest.files.size, done, total, e.path.substringAfterLast('/')))
                val src = repo.dataFile(manifest.id, e.stored)
                val path = base + BackupRepository.DATA + e.stored.split('/')
                if (!src.isFile) { failed += FailureEntry(e.path, FailureCode.MISSING); return@forEachIndexed }
                val md = MessageDigest.getInstance("SHA-256")
                try {
                    FileInputStream(src).use { input ->
                        target.openOutput(path, true).use { os ->
                            val buf = ByteArray(bufferSize)
                            while (true) {
                                if (cancel()) throw OperationCancelled()
                                val n = input.read(buf)
                                if (n < 0) break
                                md.update(buf, 0, n); os.write(buf, 0, n); done += n
                            }
                            os.flush()
                        }
                    }
                    if (Hashing.hex(md.digest()) != e.sha256) {
                        target.delete(path)
                        failed += FailureEntry(e.path, FailureCode.CORRUPT)
                    }
                } catch (c: OperationCancelled) {
                    target.delete(path); throw c
                } catch (x: SecurityException) {
                    target.delete(path); failed += FailureEntry(e.path, FailureCode.PERMISSION_DENIED, x.message ?: "")
                } catch (x: Exception) {
                    target.delete(path); failed += FailureEntry(e.path, FailureCode.TARGET_ERROR, x.message ?: "")
                }
            }
            // manifest يُكتب أخيراً: التصدير غير المكتمل لا يمكن استيراده
            if (failed.isEmpty()) {
                target.openOutput(base + BackupRepository.MANIFEST, true).use {
                    it.write(manifest.toJson().toByteArray(Charsets.UTF_8)); it.flush()
                }
            }
        } catch (c: OperationCancelled) {
            return ExportReport(false, failed, true)
        } catch (x: Exception) {
            failed += FailureEntry("", FailureCode.TARGET_ERROR, x.message ?: "")
        }
        return ExportReport(false, failed, false)
    }

    /** يجد مجلدات النسخ داخل عقدة: إما هي نفسها أو أبناؤها المباشرون. */
    fun findBackupRoots(node: SourceNode): List<SourceNode> {
        val kids = node.children()
        if (kids.any { it.name == BackupRepository.MANIFEST && !it.isDirectory }) return listOf(node)
        val result = ArrayList<SourceNode>()
        for (k in kids.filter { it.isDirectory }) {
            val inner = try { k.children() } catch (e: Exception) { continue }
            if (inner.any { it.name == BackupRepository.MANIFEST && !it.isDirectory }) result += k
            else if (k.name == EXPORT_DIR) {
                for (kk in inner.filter { it.isDirectory }) {
                    val i2 = try { kk.children() } catch (e: Exception) { continue }
                    if (i2.any { it.name == BackupRepository.MANIFEST }) result += kk
                }
            }
        }
        return result
    }

    fun importFrom(
        folder: SourceNode,
        cancel: () -> Boolean = { false },
        onProgress: (Progress) -> Unit = {},
    ): ImportReport {
        val imported = ArrayList<String>()
        val skipped = ArrayList<String>()
        val failed = ArrayList<FailureEntry>()
        val roots = try { findBackupRoots(folder) } catch (e: Exception) {
            return ImportReport(emptyList(), emptyList(), listOf(FailureEntry(folder.name, FailureCode.IO_ERROR, e.message ?: "")), false)
        }
        if (roots.isEmpty()) {
            return ImportReport(emptyList(), emptyList(), listOf(FailureEntry(folder.name, FailureCode.INVALID, "no manifest")), false)
        }
        repo.root.mkdirs()
        for (r in roots) {
            var tmp: File? = null
            try {
                val kids = r.children()
                val mNode = kids.first { it.name == BackupRepository.MANIFEST }
                val manifest = Manifest.fromJson(mNode.openInput().use { String(it.readBytes(), Charsets.UTF_8) })
                if (!BackupRepository.isValidId(manifest.id)) {
                    failed += FailureEntry(r.name, FailureCode.INVALID, "bad id"); continue
                }
                if (repo.exists(manifest.id)) { skipped += manifest.id; continue }
                val dataNode = kids.firstOrNull { it.name == BackupRepository.DATA && it.isDirectory }
                if (dataNode == null) { failed += FailureEntry(manifest.id, FailureCode.MISSING, "data"); continue }
                val nodes = HashMap<String, SourceNode>()
                Scanner.walk(dataNode, "data", object : WalkVisitor {
                    override fun onFile(parts: List<String>, node: SourceNode) { nodes[parts.drop(1).joinToString("/")] = node }
                    override fun onEmptyDir(parts: List<String>) {}
                    override fun onFailure(path: String, code: String, detail: String) {}
                }, cancel)
                val t = File(repo.root, BackupRepository.TMP_PREFIX + "import-" + manifest.id)
                tmp = t
                t.deleteRecursively()
                var ok = true
                var done = 0L
                manifest.files.forEachIndexed { i, e ->
                    if (!ok) return@forEachIndexed
                    if (cancel()) throw OperationCancelled()
                    onProgress(Progress(i, manifest.files.size, done, manifest.totalBytes, e.path.substringAfterLast('/')))
                    val n = nodes[e.stored]
                    if (n == null) { failed += FailureEntry(e.path, FailureCode.MISSING); ok = false; return@forEachIndexed }
                    val out = File(File(t, BackupRepository.DATA), e.stored)
                    out.parentFile?.mkdirs()
                    val md = MessageDigest.getInstance("SHA-256")
                    n.openInput().use { input ->
                        FileOutputStream(out).use { os ->
                            val buf = ByteArray(bufferSize)
                            while (true) {
                                if (cancel()) throw OperationCancelled()
                                val c = input.read(buf)
                                if (c < 0) break
                                md.update(buf, 0, c); os.write(buf, 0, c); done += c
                            }
                            os.flush(); os.fd.sync()
                        }
                    }
                    if (Hashing.hex(md.digest()) != e.sha256) {
                        failed += FailureEntry(e.path, FailureCode.CORRUPT); ok = false
                    }
                }
                if (ok) {
                    repo.commit(t, manifest)
                    imported += manifest.id
                } else {
                    t.deleteRecursively()
                }
            } catch (c: OperationCancelled) {
                tmp?.deleteRecursively()
                return ImportReport(imported, skipped, failed, true)
            } catch (x: SecurityException) {
                tmp?.deleteRecursively(); failed += FailureEntry(r.name, FailureCode.PERMISSION_DENIED, x.message ?: "")
            } catch (x: Exception) {
                tmp?.deleteRecursively(); failed += FailureEntry(r.name, FailureCode.IO_ERROR, x.message ?: "")
            }
        }
        return ImportReport(imported, skipped, failed, false)
    }
}
