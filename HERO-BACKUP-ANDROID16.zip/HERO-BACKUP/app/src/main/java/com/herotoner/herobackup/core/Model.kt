package com.herotoner.herobackup.core

object BackupStatus {
    const val COMPLETE = "COMPLETE"
    const val PARTIAL = "PARTIAL"
}

object FailureCode {
    const val PERMISSION_DENIED = "PERMISSION_DENIED"
    const val IO_ERROR = "IO_ERROR"
    const val VERIFY_FAILED = "VERIFY_FAILED"
    const val CORRUPT = "CORRUPT"
    const val MISSING = "MISSING"
    const val TARGET_ERROR = "TARGET_ERROR"
    const val NO_SPACE = "NO_SPACE"
    const val INVALID = "INVALID"
}

data class FileEntry(
    val path: String,
    val stored: String,
    val size: Long,
    val sha256: String,
    val lastModified: Long,
)

data class FailureEntry(val path: String, val code: String, val detail: String = "")

data class Progress(
    val filesDone: Int,
    val filesTotal: Int,
    val bytesDone: Long,
    val bytesTotal: Long,
    val current: String,
) {
    val fraction: Float
        get() = when {
            bytesTotal > 0 -> (bytesDone.toDouble() / bytesTotal).coerceIn(0.0, 1.0).toFloat()
            filesTotal > 0 -> (filesDone.toDouble() / filesTotal).coerceIn(0.0, 1.0).toFloat()
            else -> 0f
        }
}

data class BackupInfo(
    val id: String,
    val name: String,
    val createdAt: Long,
    val status: String,
    val fileCount: Int,
    val totalBytes: Long,
    val failureCount: Int,
) {
    fun toJson(): String = Json.stringify(
        linkedMapOf(
            "id" to id, "name" to name, "createdAt" to createdAt, "status" to status,
            "fileCount" to fileCount, "totalBytes" to totalBytes, "failureCount" to failureCount,
        )
    )

    companion object {
        fun fromJson(text: String): BackupInfo {
            val m = Json.parseObject(text)
            return BackupInfo(
                id = m["id"] as String,
                name = m["name"] as String,
                createdAt = (m["createdAt"] as Number).toLong(),
                status = m["status"] as String,
                fileCount = (m["fileCount"] as Number).toInt(),
                totalBytes = (m["totalBytes"] as Number).toLong(),
                failureCount = (m["failureCount"] as Number).toInt(),
            )
        }
    }
}

data class Manifest(
    val formatVersion: Int,
    val id: String,
    val name: String,
    val createdAt: Long,
    val appVersion: String,
    val status: String,
    val roots: List<String>,
    val files: List<FileEntry>,
    val emptyDirs: List<String>,
    val failures: List<FailureEntry>,
) {
    val totalBytes: Long get() = files.sumOf { it.size }

    fun info() = BackupInfo(id, name, createdAt, status, files.size, totalBytes, failures.size)

    fun toJson(): String = Json.stringify(
        linkedMapOf(
            "formatVersion" to formatVersion,
            "app" to "HERO BACKUP",
            "id" to id,
            "name" to name,
            "createdAt" to createdAt,
            "appVersion" to appVersion,
            "status" to status,
            "roots" to roots,
            "emptyDirs" to emptyDirs,
            "failures" to failures.map { linkedMapOf("path" to it.path, "code" to it.code, "detail" to it.detail) },
            "files" to files.map {
                linkedMapOf(
                    "path" to it.path, "stored" to it.stored, "size" to it.size,
                    "sha256" to it.sha256, "lastModified" to it.lastModified,
                )
            },
        )
    )

    companion object {
        fun fromJson(text: String): Manifest {
            val m = Json.parseObject(text)
            val files = (m["files"] as List<*>).map { e ->
                val f = e as Map<*, *>
                FileEntry(
                    path = f["path"] as String,
                    stored = f["stored"] as String,
                    size = (f["size"] as Number).toLong(),
                    sha256 = f["sha256"] as String,
                    lastModified = (f["lastModified"] as Number).toLong(),
                )
            }
            val failures = (m["failures"] as List<*>).map { e ->
                val f = e as Map<*, *>
                FailureEntry(f["path"] as String, f["code"] as String, (f["detail"] as? String) ?: "")
            }
            return Manifest(
                formatVersion = (m["formatVersion"] as Number).toInt(),
                id = m["id"] as String,
                name = m["name"] as String,
                createdAt = (m["createdAt"] as Number).toLong(),
                appVersion = (m["appVersion"] as? String) ?: "",
                status = m["status"] as String,
                roots = (m["roots"] as List<*>).map { it as String },
                files = files,
                emptyDirs = (m["emptyDirs"] as List<*>).map { it as String },
                failures = failures,
            )
        }
    }
}

enum class Kind { WORLD, ADDON, PACK, RESOURCE_PACK, BEHAVIOR_PACK, SKIN_PACK, ZIP, OTHER }

object FileKinds {
    fun of(path: String): Kind {
        val lower = path.lowercase()
        val ext = lower.substringAfterLast('.', "")
        when (ext) {
            "mcworld" -> return Kind.WORLD
            "mcaddon" -> return Kind.ADDON
            "mcpack" -> return Kind.PACK
            "mctemplate" -> return Kind.WORLD
            "zip" -> return Kind.ZIP
        }
        val parts = lower.split('/')
        return when {
            parts.any { it == "minecraftworlds" } -> Kind.WORLD
            parts.any { it == "resource_packs" || it == "development_resource_packs" } -> Kind.RESOURCE_PACK
            parts.any { it == "behavior_packs" || it == "development_behavior_packs" } -> Kind.BEHAVIOR_PACK
            parts.any { it == "skin_packs" || it == "development_skin_packs" } -> Kind.SKIN_PACK
            else -> Kind.OTHER
        }
    }

    /** الملفات التي يمكن فتحها في Minecraft عبر Intent. */
    fun isImportable(path: String): Boolean =
        path.substringAfterLast('.', "").lowercase() in setOf("mcworld", "mcaddon", "mcpack", "mctemplate")
}
