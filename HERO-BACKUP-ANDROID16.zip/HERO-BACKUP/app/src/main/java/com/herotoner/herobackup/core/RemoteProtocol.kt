package com.herotoner.herobackup.core

import java.io.FileNotFoundException
import java.io.IOException

data class RemoteEntry(val name: String, val dir: Boolean, val size: Long, val mtime: Long)
data class RemoteListing(val entries: List<RemoteEntry>, val more: Boolean)
data class RemoteStat(val dir: Boolean, val size: Long, val uid: Int, val mtime: Long)

sealed interface Remote<out T> {
    data class Ok<T>(val value: T) : Remote<T>
    data class Err(val code: String, val message: String) : Remote<Nothing>
}

/**
 * بروتوكول بسيط (JSON) بين التطبيق وخدمة الملفات التي تعمل عبر Shizuku.
 * بدون أي اعتماد على Android كي يمكن اختباره على JVM.
 */
object RemoteProtocol {
    private val ERRNO = Regex("\\bE[A-Z][A-Z0-9]{2,}\\b")

    fun errnoOf(message: String?): String = message?.let { ERRNO.find(it)?.value } ?: "EIO"

    fun encodeError(code: String, message: String): String =
        Json.stringify(linkedMapOf("ok" to false, "code" to code, "msg" to message))

    fun encodeList(entries: List<RemoteEntry>, more: Boolean): String = Json.stringify(
        linkedMapOf(
            "ok" to true, "more" to more,
            "entries" to entries.map { linkedMapOf("n" to it.name, "d" to it.dir, "s" to it.size, "m" to it.mtime) },
        )
    )

    fun encodeStat(dir: Boolean, size: Long, uid: Int, mtime: Long): String =
        Json.stringify(linkedMapOf("ok" to true, "d" to dir, "s" to size, "u" to uid, "m" to mtime))

    private fun err(m: Map<String, Any?>) = Remote.Err((m["code"] as? String) ?: "EIO", (m["msg"] as? String) ?: "")

    fun decodeList(json: String): Remote<RemoteListing> {
        val m = try { Json.parseObject(json) } catch (e: Exception) { return Remote.Err("EIO", "رد غير صالح من الخدمة") }
        if (m["ok"] != true) return err(m)
        val entries = (m["entries"] as List<*>).map {
            val e = it as Map<*, *>
            RemoteEntry(e["n"] as String, e["d"] as Boolean, (e["s"] as Number).toLong(), (e["m"] as Number).toLong())
        }
        return Remote.Ok(RemoteListing(entries, m["more"] == true))
    }

    fun decodeStat(json: String): Remote<RemoteStat> {
        val m = try { Json.parseObject(json) } catch (e: Exception) { return Remote.Err("EIO", "رد غير صالح من الخدمة") }
        if (m["ok"] != true) return err(m)
        return Remote.Ok(
            RemoteStat(m["d"] as Boolean, (m["s"] as Number).toLong(), (m["u"] as Number).toInt(), (m["m"] as Number).toLong())
        )
    }

    /** رفض النظام الوصول → SecurityException، عدم وجود المسار → FileNotFoundException، وغيرها IOException. */
    fun toException(code: String, message: String): Exception {
        val text = if (message.isBlank()) code else message
        return when (code) {
            "EACCES", "EPERM", "EROFS" -> SecurityException(text)
            "ENOENT", "ENOTDIR" -> FileNotFoundException(text)
            else -> IOException(text)
        }
    }
}
