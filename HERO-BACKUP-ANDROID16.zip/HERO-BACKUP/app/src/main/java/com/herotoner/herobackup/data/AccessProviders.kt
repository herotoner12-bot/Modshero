package com.herotoner.herobackup.data

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import com.herotoner.herobackup.core.AccessMethod
import com.herotoner.herobackup.core.AccessProvider
import com.herotoner.herobackup.core.ApiSupport
import com.herotoner.herobackup.core.DirectFilesKind
import com.herotoner.herobackup.core.DirectFilesProvider
import com.herotoner.herobackup.core.DiscoverResult
import com.herotoner.herobackup.core.MinecraftPaths
import com.herotoner.herobackup.core.Precheck
import com.herotoner.herobackup.core.SourceNode
import com.herotoner.herobackup.core.StorageEngine
import com.herotoner.herobackup.shizuku.ShizukuHelper
import com.herotoner.herobackup.shizuku.ShizukuNode
import com.herotoner.herobackup.shizuku.ShizukuStatus

/** 1) SAF: المجلدات التي اختارها المستخدم (الوصول الرسمي). */
class SafAccess(private val ctx: Context, private val store: SourceStore) : AccessProvider {
    override val method = AccessMethod.SAF

    private fun trees() = store.list().filter {
        it.isTree && !store.isFileItem(it) && !store.isShizukuItem(it) && store.hasPermission(it)
    }

    override fun precheck(): Precheck {
        val hasPicker = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).resolveActivity(ctx.packageManager) != null
        if (!hasPicker) return Precheck(false, false, "لا يوجد منتقي مجلدات (DocumentsUI) على هذا الجهاز")
        return if (trees().isEmpty()) Precheck(true, false, "لم تختر أي مجلد عبر SAF بعد")
        else Precheck(true, true, "")
    }

    override fun candidates(paths: List<String>): List<Pair<String, SourceNode>> =
        trees().map { it.name to store.toNode(it) }
}

/** 2) جميع الملفات (أو الصلاحية التقليدية على Android 8–9). */
object FilesAccess {
    fun provider(ctx: Context): AccessProvider {
        val kind = ApiSupport.directFilesKind(Build.VERSION.SDK_INT)
        return DirectFilesProvider(
            granted = {
                if (AllFilesAccess.isGranted()) true to ""
                else false to (if (kind == DirectFilesKind.ALL_FILES) "صلاحية «جميع الملفات» غير مفعّلة" else "صلاحية التخزين غير ممنوحة")
            },
            available = kind != DirectFilesKind.NONE,
        )
    }
}

/** 3) Shizuku (اختياري، بعد موافقة المستخدم). */
class ShizukuAccess : AccessProvider {
    override val method = AccessMethod.SHIZUKU

    override fun precheck(): Precheck = when (ShizukuHelper.status.value) {
        ShizukuStatus.NOT_INSTALLED -> Precheck(false, false, "Shizuku غير مثبّت")
        ShizukuStatus.NOT_RUNNING -> Precheck(true, false, "Shizuku غير مشغّل")
        ShizukuStatus.NEEDS_PERMISSION -> Precheck(true, false, "لم تمنح HERO BACKUP صلاحية Shizuku")
        ShizukuStatus.DENIED -> Precheck(true, false, "رُفضت صلاحية Shizuku")
        ShizukuStatus.CONNECTED -> Precheck(true, true, "")
    }

    override fun candidates(paths: List<String>): List<Pair<String, SourceNode>> {
        val svc = ShizukuHelper.awaitServiceBlocking(6000) ?: return emptyList()
        return paths.filter { !it.startsWith("/data/media") }.map { it to (ShizukuNode.root(svc, it) as SourceNode) }
    }
}

object AccessDiscovery {
    fun paths(ctx: Context): List<String> {
        val pkgs = McPackages.installed(ctx).map { it.pkg }.ifEmpty { listOf(MinecraftPaths.PACKAGES[0]) }
        val roots = (listOf(Environment.getExternalStorageDirectory().absolutePath) + MinecraftPaths.roots(McPackages.userId())).distinct()
        return MinecraftPaths.candidates(pkgs, roots)
    }

    fun providers(ctx: Context, store: SourceStore): List<AccessProvider> =
        listOf(SafAccess(ctx, store), FilesAccess.provider(ctx), ShizukuAccess())

    /** يجرّب SAF ثم جميع الملفات ثم Shizuku، ويرجع للبديل الرسمي إن فشلت كلها. */
    fun run(ctx: Context, store: SourceStore, cancel: () -> Boolean = { false }): DiscoverResult {
        ShizukuHelper.init(ctx)
        AllFilesAccess.init(ctx)
        return StorageEngine.discover(providers(ctx, store), paths(ctx), cancel)
    }
}
