package com.herotoner.herobackup.core

import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

class BackupRepository(val root: File) {
    companion object {
        const val MANIFEST = "manifest.json"
        const val INFO = "info.json"
        const val DATA = "data"
        const val TMP_PREFIX = ".tmp-"
        private val ID_REGEX = Regex("^[A-Za-z0-9_-]{1,80}$")

        fun isValidId(id: String) = ID_REGEX.matches(id)

        /** يكتب نصاً إلى ملف ثم يضمن وصوله للقرص. */
        fun writeTextSynced(file: File, text: String) {
            FileOutputStream(file).use { os ->
                os.write(text.toByteArray(Charsets.UTF_8))
                os.flush()
                os.fd.sync()
            }
        }

        fun atomicMove(from: File, to: File) {
            try {
                Files.move(from.toPath(), to.toPath(), StandardCopyOption.ATOMIC_MOVE)
            } catch (e: java.nio.file.AtomicMoveNotSupportedException) {
                Files.move(from.toPath(), to.toPath())
            }
        }
    }

    fun dir(id: String): File = File(root, id)

    fun dataFile(id: String, stored: String): File = File(File(dir(id), DATA), stored)

    fun exists(id: String): Boolean = isValidId(id) && File(dir(id), MANIFEST).isFile

    /** النسخ المكتملة فقط؛ مجلدات .tmp- (غير المكتملة) لا تظهر أبداً. */
    fun list(): List<BackupInfo> {
        val dirs = root.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: return emptyList()
        val result = ArrayList<BackupInfo>()
        for (d in dirs) {
            if (!isValidId(d.name) || !File(d, MANIFEST).isFile) continue
            val info = try {
                val infoFile = File(d, INFO)
                if (infoFile.isFile) BackupInfo.fromJson(infoFile.readText()) else loadManifest(d.name)?.info()
            } catch (e: Exception) {
                try { loadManifest(d.name)?.info() } catch (e2: Exception) { null }
            }
            if (info != null && info.id == d.name) result += info
        }
        return result.sortedByDescending { it.createdAt }
    }

    fun loadManifest(id: String): Manifest? {
        if (!isValidId(id)) return null
        val f = File(dir(id), MANIFEST)
        if (!f.isFile) return null
        return try { Manifest.fromJson(f.readText()) } catch (e: Exception) { null }
    }

    fun delete(id: String): Boolean {
        if (!isValidId(id)) return false
        val d = dir(id)
        return d.exists() && d.deleteRecursively()
    }

    fun usedBytes(): Long = list().sumOf { it.totalBytes }

    /** يحذف بقايا عمليات نسخ توقفت فجأة (لا يمس النسخ المكتملة). */
    fun cleanupIncomplete(): Int {
        val dirs = root.listFiles { f -> f.isDirectory && f.name.startsWith(TMP_PREFIX) } ?: return 0
        var n = 0
        for (d in dirs) if (d.deleteRecursively()) n++
        return n
    }

    fun incompleteCount(): Int =
        root.listFiles { f -> f.isDirectory && f.name.startsWith(TMP_PREFIX) }?.size ?: 0

    /** يُنهي النسخة: manifest ثم info ثم إعادة تسمية ذرّية لتصبح مرئية. */
    fun commit(tmpDir: File, manifest: Manifest) {
        writeTextSynced(File(tmpDir, MANIFEST + ".tmp"), manifest.toJson())
        atomicMove(File(tmpDir, MANIFEST + ".tmp"), File(tmpDir, MANIFEST))
        writeTextSynced(File(tmpDir, INFO), manifest.info().toJson())
        atomicMove(tmpDir, dir(manifest.id))
    }
}
