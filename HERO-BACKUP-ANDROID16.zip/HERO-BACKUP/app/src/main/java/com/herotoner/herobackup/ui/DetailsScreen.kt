package com.herotoner.herobackup.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.BackupStatus
import com.herotoner.herobackup.core.FileKinds
import com.herotoner.herobackup.core.Manifest
import com.herotoner.herobackup.data.PickTree

@Composable
fun DetailsScreen(
    vm: MainViewModel,
    id: String,
    onBack: () -> Unit,
    onRestore: (String) -> Unit,
    onJob: () -> Unit,
) {
    val ctx = LocalContext.current
    val loaded by produceState<Pair<Boolean, Manifest?>>(false to null, id) { value = true to vm.manifest(id) }
    val verify by vm.verify.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf(false) }
    val pickExport = rememberLauncherForActivityResult(PickTree()) { uri ->
        if (uri != null && vm.startExport(id, uri)) onJob()
    }
    DisposableEffect(id) { onDispose { vm.cancelVerify() } }

    ScreenScaffold(stringResource(R.string.title_details), onBack) { inner ->
        val m = loaded.second
        if (m == null) {
            LazyColumn(Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp)) {
                item { Muted(stringResource(if (loaded.first) R.string.backup_not_found else R.string.loading)) }
            }
            return@ScreenScaffold
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroCard {
                    Text(m.name, color = HeroColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Muted(formatDate(m.createdAt))
                    Muted(stringResource(R.string.backup_meta, formatBytes(ctx, m.totalBytes), m.files.size))
                    Muted(stringResource(R.string.sources_label, m.roots.joinToString("، ")))
                    if (m.status == BackupStatus.PARTIAL) {
                        Text(stringResource(R.string.badge_partial, m.failures.size), color = HeroColors.Warning, fontSize = 13.sp)
                    }
                }
            }
            item { InfoBanner(stringResource(R.string.private_storage_warning), warning = true) }
            item {
                BigButton(
                    stringResource(R.string.export_backup), { pickExport.launch(true) },
                    iconRes = R.drawable.ic_export, enabled = job?.active != true,
                )
            }
            item { BigButton(stringResource(R.string.restore), { onRestore(id) }, iconRes = R.drawable.ic_restore, primary = false) }
            item {
                BigButton(
                    stringResource(R.string.verify_backup), { vm.startVerify(id) },
                    icon = Icons.Filled.CheckCircle, primary = false,
                    enabled = verify !is VerifyState.Running,
                )
            }
            item {
                when (val v = verify) {
                    VerifyState.Idle -> {}
                    is VerifyState.Running -> HeroCard {
                        Text(stringResource(R.string.verifying), color = HeroColors.Text)
                        LinearProgressIndicator(
                            progress = { v.progress?.fraction ?: 0f },
                            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                            color = HeroColors.Primary, trackColor = HeroColors.Bg,
                        )
                        TextButton(onClick = { vm.cancelVerify() }) { Text(stringResource(R.string.cancel), color = HeroColors.Danger) }
                    }
                    is VerifyState.Done -> HeroCard {
                        if (v.report.ok) {
                            Text(
                                stringResource(R.string.verify_ok, v.report.checked),
                                color = HeroColors.Primary, fontWeight = FontWeight.Bold,
                            )
                        } else {
                            Text(stringResource(R.string.verify_bad), color = HeroColors.Danger, fontWeight = FontWeight.Bold)
                            v.report.corrupted.take(20).forEach {
                                Text(stringResource(R.string.verify_corrupt_item, it), color = HeroColors.Warning, fontSize = 12.sp)
                            }
                            v.report.missing.take(20).forEach {
                                Text(stringResource(R.string.verify_missing_item, it), color = HeroColors.Warning, fontSize = 12.sp)
                            }
                        }
                        TextButton(onClick = { vm.resetVerify() }) { Text(stringResource(R.string.close)) }
                    }
                }
            }
            item {
                BigButton(
                    stringResource(R.string.delete_backup), { confirmDelete = true },
                    icon = Icons.Filled.Delete, primary = false, danger = true,
                )
            }
            if (m.failures.isNotEmpty()) {
                item { HeroCard { SectionTitle(stringResource(R.string.failed_files)); FailureList(m.failures) } }
            }
            item { SectionTitle(stringResource(R.string.files_preview, m.files.size)) }
            items(m.files.size) { i ->
                val f = m.files[i]
                Column(Modifier.fillMaxWidth()) {
                    Text(f.path, color = HeroColors.Text, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Muted(
                        stringResource(kindLabel(FileKinds.of(f.path))) + " • " + formatBytes(ctx, f.size)
                    )
                    if (FileKinds.isImportable(f.path)) {
                        Row {
                            TextButton(onClick = { ctx.launchFileIntent(vm.fileUri(id, f), share = false) }) {
                                Text(stringResource(R.string.open_in_minecraft), color = HeroColors.Primary)
                            }
                            TextButton(onClick = { ctx.launchFileIntent(vm.fileUri(id, f), share = true) }) {
                                Text(stringResource(R.string.share), color = HeroColors.Primary)
                            }
                        }
                    }
                    HorizontalDivider(color = HeroColors.Card, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text(stringResource(R.string.delete_confirm_title)) },
                text = { Text(stringResource(R.string.delete_confirm_text, m.name)) },
                confirmButton = {
                    TextButton(onClick = { confirmDelete = false; vm.deleteBackup(id); onBack() }) {
                        Text(stringResource(R.string.delete), color = HeroColors.Danger)
                    }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
                containerColor = HeroColors.Card,
                titleContentColor = HeroColors.Text,
                textContentColor = HeroColors.TextSecondary,
            )
        }
    }
}
