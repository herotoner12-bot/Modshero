package com.herotoner.herobackup.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.data.PickFiles
import com.herotoner.herobackup.data.PickTree

@Composable
fun SelectScreen(vm: MainViewModel, onBack: () -> Unit, onStarted: () -> Unit, onBrowse: () -> Unit, onPermission: () -> Unit, onShizuku: () -> Unit) {
    val ctx = LocalContext.current
    val sources by vm.sources.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    val allFiles by vm.allFiles.collectAsStateWithLifecycle()
    val defaultName = remember { ctx.getString(R.string.default_backup_name, formatDate(System.currentTimeMillis())) }
    var name by rememberSaveable { mutableStateOf(defaultName) }
    var replaceId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { vm.refreshSources() }

    val pickTree = rememberLauncherForActivityResult(PickTree()) { uri -> if (uri != null) vm.addTree(uri) }
    val pickFiles = rememberLauncherForActivityResult(PickFiles()) { uris -> if (uris.isNotEmpty()) vm.addFiles(uris) }
    val replaceTree = rememberLauncherForActivityResult(PickTree()) { uri ->
        val id = replaceId
        if (uri != null && id != null) vm.replaceTree(id, uri)
        replaceId = null
    }

    fun doStart() {
        if (vm.startBackup(name.trim())) onStarted()
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> doStart() }

    fun onStartClicked() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            doStart()
        }
    }

    val done = sources.map { it.scan }.filterIsInstance<Scan.Done>()
    val totalFiles = done.sumOf { it.files }
    val totalBytes = done.sumOf { it.bytes }
    val busy = job?.active == true

    ScreenScaffold(stringResource(R.string.title_select), onBack) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { InfoBanner(stringResource(R.string.info_android_data), warning = true) }
            item {
                BigButton(stringResource(R.string.pick_folder), { pickTree.launch(false) }, iconRes = R.drawable.ic_folder)
            }
            item {
                BigButton(
                    stringResource(R.string.pick_files), { pickFiles.launch(Unit) },
                    iconRes = R.drawable.ic_file, primary = false,
                )
            }
            item {
                BigButton(
                    stringResource(if (allFiles) R.string.browse_files else R.string.enable_all_files),
                    { if (allFiles) onBrowse() else onPermission() },
                    iconRes = R.drawable.ic_folder, primary = false,
                )
            }
            item {
                BigButton(
                    stringResource(R.string.shz_add_from), onShizuku,
                    iconRes = R.drawable.ic_folder, primary = false,
                )
            }
            item { SectionTitle(stringResource(R.string.selected_sources)) }
            if (sources.isEmpty()) {
                item { Muted(stringResource(R.string.no_sources)) }
            }
            items(sources, key = { it.item.id }) { s ->
                HeroCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painterResource(if (s.item.isTree) R.drawable.ic_folder else R.drawable.ic_file),
                            contentDescription = null, tint = HeroColors.Primary, modifier = Modifier.size(28.dp),
                        )
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(s.item.name, color = HeroColors.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            when (val sc = s.scan) {
                                Scan.Scanning -> Muted(stringResource(R.string.scanning))
                                is Scan.Done -> {
                                    Muted(
                                        stringResource(R.string.source_summary, sc.files, formatBytes(ctx, sc.bytes))
                                    )
                                    if (sc.failures > 0) {
                                        Text(
                                            stringResource(R.string.source_inaccessible, sc.failures),
                                            color = HeroColors.Warning, fontSize = 13.sp,
                                        )
                                    }
                                }
                                Scan.Expired -> Text(
                                    stringResource(
                                        when {
                                            s.item.uri.startsWith("file:") -> R.string.source_expired_files
                                            s.item.uri.startsWith("shizuku://") -> R.string.source_expired_shizuku
                                            else -> R.string.source_expired
                                        }
                                    ), color = HeroColors.Danger, fontSize = 13.sp,
                                )
                                Scan.Error -> Text(
                                    stringResource(R.string.source_error), color = HeroColors.Danger, fontSize = 13.sp,
                                )
                            }
                        }
                        IconButton(onClick = { vm.removeSource(s.item.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.remove), tint = HeroColors.TextSecondary)
                        }
                    }
                    if (s.scan == Scan.Expired && s.item.isTree && !s.item.uri.startsWith("file:") && !s.item.uri.startsWith("shizuku://")) {
                        TextButton(onClick = { replaceId = s.item.id; replaceTree.launch(false) }) {
                            Text(stringResource(R.string.repick_folder), color = HeroColors.Primary)
                        }
                    }
                }
            }
            if (sources.isNotEmpty()) {
                item {
                    HeroCard {
                        Text(stringResource(R.string.total_label), color = HeroColors.TextSecondary, fontSize = 13.sp)
                        Text(
                            stringResource(R.string.source_summary, totalFiles, formatBytes(ctx, totalBytes)),
                            color = HeroColors.Primary, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                        )
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.backup_name)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = HeroColors.Primary,
                        unfocusedBorderColor = HeroColors.TextSecondary,
                        focusedTextColor = HeroColors.Text,
                        unfocusedTextColor = HeroColors.Text,
                        cursorColor = HeroColors.Primary,
                        focusedLabelColor = HeroColors.Primary,
                        unfocusedLabelColor = HeroColors.TextSecondary,
                    ),
                )
            }
            item {
                BigButton(
                    stringResource(R.string.start_backup), { onStartClicked() },
                    icon = Icons.Filled.PlayArrow, enabled = totalFiles > 0 && !busy,
                )
            }
            if (busy) item { Muted(stringResource(R.string.job_running_banner)) }
        }
    }
}
