package com.herotoner.herobackup.shizuku

import android.content.Context
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.Hashing
import com.herotoner.herobackup.core.MinecraftPaths
import com.herotoner.herobackup.core.Remote
import com.herotoner.herobackup.core.RemoteProtocol
import com.herotoner.herobackup.core.SourceNode
import java.io.File
import java.security.MessageDigest

data class ProbeLine(val path: String, val ok: Boolean, val detail: String)
data class ProbeResult(val lines: List<ProbeLine>, val workingPath: String?, val folders: List<Pair<String, String>>)

/** يفحص فعلياً مجلد Minecraft عبر Shizuku، ويعرض سبب الرفض من النظام إن وُجد. لا يعدّل شيئاً. */
object MinecraftProbe {

    fun reasonText(ctx: Context, code: String, msg: String): String {
        val base = when (code) {
            "EACCES", "EPERM" -> ctx.getString(R.string.shz_reason_denied)
            "ENOENT" -> ctx.getString(R.string.shz_reason_missing)
            "ENOTDIR" -> ctx.getString(R.string.shz_reason_notdir)
            else -> ctx.getString(R.string.shz_reason_other)
        }
        return "$base [$code]" + if (msg.isNotBlank()) "\n$msg" else ""
    }

    private fun probeOne(ctx: Context, svc: IFileService, path: String): ProbeLine {
        val raw = try { svc.probe(path) } catch (e: Exception) {
            return ProbeLine(path, false, reasonText(ctx, "EIO", e.message ?: ""))
        }
        return when (val r = RemoteProtocol.decodeStat(raw)) {
            is Remote.Err -> ProbeLine(path, false, reasonText(ctx, r.code, r.message))
            is Remote.Ok ->
                if (r.value.dir) ProbeLine(path, true, ctx.getString(R.string.shz_probe_dir_ok, r.value.uid))
                else ProbeLine(path, false, ctx.getString(R.string.shz_reason_notdir))
        }
    }

    fun check(ctx: Context, svc: IFileService): ProbeResult {
        val lines = ArrayList<ProbeLine>()
        var working: String? = null
        val pkgs = com.herotoner.herobackup.data.McPackages.installed(ctx).map { it.pkg }
            .ifEmpty { listOf(MinecraftPaths.PACKAGES[0]) }
        val roots = MinecraftPaths.roots(com.herotoner.herobackup.data.McPackages.userId()).filter { !it.startsWith("/data/media") }
        val rels = pkgs.map { "Android/data/$it/files/games/com.mojang" } + "games/com.mojang"
        outer@ for (rel in rels) {
            val parts = rel.split('/')
            val chain = (1..parts.size).map { parts.take(it).joinToString("/") }
            for (root in roots) {
                var allOk = true
                for (c in chain) {
                    val line = probeOne(ctx, svc, "$root/$c")
                    lines += line
                    if (!line.ok) { allOk = false; break }
                }
                if (allOk) { working = "$root/$rel"; break@outer }
            }
        }
        val folders = ArrayList<Pair<String, String>>()
        if (working != null) {
            val node = ShizukuNode.root(svc, working)
            try {
                for (k in node.children().filter { it.isDirectory }.take(30)) {
                    val count = try { k.children().size.toString() } catch (e: Exception) { "?" }
                    folders += k.name to ctx.getString(R.string.shz_folder_items, count)
                }
                lines += ProbeLine(working, true, ctx.getString(R.string.shz_probe_listed, folders.size))
            } catch (e: Exception) {
                lines += ProbeLine(working, false, reasonText(ctx, RemoteProtocol.errnoOf(e.message), e.message ?: ""))
                working = null
            }
        }
        return ProbeResult(lines, working, folders)
    }

    private fun findTestFile(base: SourceNode): Pair<SourceNode, String>? {
        // نفضّل ملفاً صغيراً من عالم (level.dat / levelname.txt) ثم أي ملف صغير
        val queue = ArrayDeque<Pair<SourceNode, String>>()
        queue.addLast(base to base.name)
        var visited = 0
        var fallback: Pair<SourceNode, String>? = null
        while (queue.isNotEmpty() && visited < 300) {
            val (dir, p) = queue.removeFirst()
            visited++
            val kids = try { dir.children() } catch (e: Exception) { continue }
            for (k in kids) {
                if (k.isDirectory) queue.addLast(k to p + "/" + k.name)
                else if (k.name == "level.dat" || k.name == "levelname.txt") return k to p + "/" + k.name
                else if (fallback == null && k.size in 1..8_000_000) fallback = k to p + "/" + k.name
            }
        }
        return fallback
    }

    private fun sha(input: java.io.InputStream): Pair<Long, String> {
        val md = MessageDigest.getInstance("SHA-256")
        var total = 0L
        input.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                total += n
            }
        }
        return total to Hashing.hex(md.digest())
    }

    /** قراءة ونسخ ملف حقيقي من مجلد Minecraft إلى مجلد مؤقت للتطبيق، ثم مقارنة SHA-256. الأصل لا يُمَس. */
    fun selfTest(ctx: Context, svc: IFileService, workingPath: String): List<ProbeLine> {
        val lines = ArrayList<ProbeLine>()
        val base = ShizukuNode.root(svc, workingPath)
        val found = try { findTestFile(base) } catch (e: Exception) { null }
        if (found == null) {
            lines += ProbeLine(workingPath, false, ctx.getString(R.string.shz_test_nofile))
            return lines
        }
        val (node, rel) = found
        lines += ProbeLine(rel, true, ctx.getString(R.string.shz_test_chosen))
        val (readBytes, readHash) = try {
            sha(node.openInput())
        } catch (e: Exception) {
            lines += ProbeLine(rel, false, reasonText(ctx, RemoteProtocol.errnoOf(e.message), e.message ?: ""))
            return lines
        }
        lines += ProbeLine(rel, true, ctx.getString(R.string.shz_test_read_ok, readBytes, readHash.take(16)))

        val dir = File(ctx.cacheDir, "shizuku-test").also { it.mkdirs() }
        val copy = File(dir, "copy.bin")
        try {
            node.openInput().use { ins -> copy.outputStream().use { os -> ins.copyTo(os, 64 * 1024) } }
            val copyHash = Hashing.sha256(copy)
            lines += if (copyHash == readHash) ProbeLine(rel, true, ctx.getString(R.string.shz_test_copy_ok))
            else ProbeLine(rel, false, ctx.getString(R.string.shz_test_copy_bad))
        } catch (e: Exception) {
            lines += ProbeLine(rel, false, reasonText(ctx, RemoteProtocol.errnoOf(e.message), e.message ?: ""))
        } finally {
            copy.delete() // ننظف نسختنا المؤقتة فقط
        }
        return lines
    }
}
