package com.herotoner.herobackup.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.herotoner.herobackup.R

/**
 * الوصول المباشر للملفات (File API):
 * - Android 11+ : «الوصول إلى جميع الملفات» (MANAGE_EXTERNAL_STORAGE) من إعدادات النظام.
 * - Android 8–9 : صلاحية التخزين التقليدية (READ/WRITE_EXTERNAL_STORAGE) عبر طلب وقت التشغيل.
 * - Android 10 : لا تُطلب أي صلاحية شاملة؛ تُستخدم الطرق الأخرى (SAF/Shizuku).
 * لا تضمن أي منها الوصول إلى Android/data.
 */
object AllFilesAccess {
    private var appCtx: Context? = null

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    val applicable: Boolean get() = Build.VERSION.SDK_INT != Build.VERSION_CODES.Q
    val isLegacy: Boolean get() = Build.VERSION.SDK_INT <= Build.VERSION_CODES.P

    fun isGranted(): Boolean = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
            try { Environment.isExternalStorageManager() } catch (e: Exception) { false }
        Build.VERSION.SDK_INT <= Build.VERSION_CODES.P ->
            appCtx?.let { ContextCompat.checkSelfPermission(it, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED } ?: false
        else -> false
    }

    /** يفتح إعدادات «جميع الملفات» (Android 11+ فقط). */
    fun open(ctx: Context) {
        val appIntent = Intent(
            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:" + ctx.packageName),
        )
        try {
            ctx.startActivity(appIntent)
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                Toast.makeText(ctx, R.string.perm_cannot_open, Toast.LENGTH_LONG).show()
            }
        }
    }
}
