package com.herotoner.herobackup.shizuku

import android.os.ParcelFileDescriptor
import android.os.RemoteException
import com.herotoner.herobackup.core.Remote
import com.herotoner.herobackup.core.RemoteProtocol
import com.herotoner.herobackup.core.SourceNode
import java.io.IOException
import java.io.InputStream

/** عقدة مصدر تقرأ عبر خدمة Shizuku (قراءة فقط). تعمل مع BackupEngine دون أي تعديل عليه. */
class ShizukuNode(
    private val svc: IFileService,
    val path: String,
    override val name: String,
    override val isDirectory: Boolean,
    override val size: Long,
    override val lastModified: Long,
) : SourceNode {

    private inline fun <T> remote(block: () -> T): T {
        try {
            return block()
        } catch (e: IllegalStateException) {
            val msg = e.message ?: ""
            throw RemoteProtocol.toException(RemoteProtocol.errnoOf(msg), msg)
        } catch (e: RemoteException) {
            throw IOException("توقفت خدمة Shizuku", e)
        }
    }

    override fun children(): List<SourceNode> {
        if (!isDirectory) return emptyList()
        val out = ArrayList<SourceNode>()
        var offset = 0
        while (true) {
            val raw = remote { svc.list(path, offset, 500) }
            when (val r = RemoteProtocol.decodeList(raw)) {
                is Remote.Err -> throw RemoteProtocol.toException(r.code, r.message)
                is Remote.Ok -> {
                    for (e in r.value.entries) {
                        out += ShizukuNode(svc, join(path, e.name), e.name, e.dir, e.size, e.mtime)
                    }
                    if (!r.value.more || r.value.entries.isEmpty()) return out
                    offset += r.value.entries.size
                }
            }
        }
    }

    override fun openInput(): InputStream {
        val pfd: ParcelFileDescriptor = remote { svc.openRead(path) } ?: throw IOException("تعذر فتح الملف")
        return ParcelFileDescriptor.AutoCloseInputStream(pfd)
    }

    companion object {
        fun join(dir: String, name: String) = dir.trimEnd('/') + "/" + name

        fun root(svc: IFileService, path: String, name: String? = null): ShizukuNode =
            ShizukuNode(svc, path, name ?: path.trimEnd('/').substringAfterLast('/'), true, 0L, 0L)
    }
}
