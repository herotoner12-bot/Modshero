package com.herotoner.herobackup.work

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.BackupEngine
import com.herotoner.herobackup.core.BackupOutcome
import com.herotoner.herobackup.core.BackupRepository
import com.herotoner.herobackup.core.FailureCode
import com.herotoner.herobackup.core.Json
import com.herotoner.herobackup.core.OverwritePolicy
import com.herotoner.herobackup.core.Progress
import com.herotoner.herobackup.core.RestoreEngine
import com.herotoner.herobackup.core.SourceRoot
import com.herotoner.herobackup.core.TransferEngine
import com.herotoner.herobackup.data.AllFilesAccess
import com.herotoner.herobackup.data.SafNode
import com.herotoner.herobackup.data.SafRestoreTarget
import com.herotoner.herobackup.data.SourceStore
import com.herotoner.herobackup.work.Jobs.toData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.coroutineContext

object Notifications {
    const val CHANNEL = "hero_jobs"
    const val ID = 4711

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
    }

    fun build(ctx: Context, title: String, p: Progress?): Notification {
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_backup)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
        if (p != null && p.filesTotal > 0) {
            b.setContentText(ctx.getString(R.string.notif_progress, p.filesDone, p.filesTotal))
            b.setProgress(100, (p.fraction * 100).toInt(), false)
        } else {
            b.setProgress(0, 0, true)
        }
        return b.build()
    }
}

abstract class JobWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    abstract val title: String

    protected val repo: BackupRepository by lazy {
        BackupRepository(File(applicationContext.filesDir, "backups"))
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo(null)

    private fun foregroundInfo(p: Progress?): ForegroundInfo {
        Notifications.ensureChannel(applicationContext)
        val n = Notifications.build(applicationContext, title, p)
        return if (Build.VERSION.SDK_INT >= 29) {
            ForegroundInfo(Notifications.ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(Notifications.ID, n)
        }
    }

    /** يشغّل عملية طويلة على خيط IO مع نشر التقدم وتحديث الإشعار، ويحترم الإلغاء. */
    protected suspend fun <T> track(block: (cancel: () -> Boolean, onProgress: (Progress) -> Unit) -> T): T =
        coroutineScope {
            try { setForeground(foregroundInfo(null)) } catch (e: Exception) { /* قد يمنعه النظام في الخلفية */ }
            val job = coroutineContext.job
            val latest = AtomicReference<Progress?>(null)
            val nm = applicationContext.getSystemService(NotificationManager::class.java)
            val ticker = launch {
                while (isActive) {
                    latest.get()?.let { p ->
                        setProgress(p.toData())
                        try {
                            nm.notify(Notifications.ID, Notifications.build(applicationContext, title, p))
                        } catch (e: Exception) { }
                    }
                    delay(500)
                }
            }
            try {
                withContext(Dispatchers.IO) { block({ !job.isActive }, { latest.set(it) }) }
            } finally {
                ticker.cancel()
            }
        }

    protected fun release(uri: Uri) {
        try {
            applicationContext.contentResolver.releasePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (e: Exception) { }
    }

    protected fun fail(code: String) = Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_FAILED, Jobs.K_CODE to code))
}

class BackupWorker(ctx: Context, params: WorkerParameters) : JobWorker(ctx, params) {
    override val title: String get() = applicationContext.getString(R.string.notif_backup_title)

    override suspend fun doWork(): Result {
        val name = inputData.getString(Jobs.K_NAME) ?: ""
        val ids = inputData.getStringArray(Jobs.K_SOURCES)?.toSet() ?: emptySet()
        val store = SourceStore(applicationContext)
        val items = store.list().filter { it.id in ids }
        if (items.isEmpty()) return fail(FailureCode.INVALID)
        repo.cleanupIncomplete()
        com.herotoner.herobackup.shizuku.ShizukuHelper.init(applicationContext)
        val roots = withContext(Dispatchers.IO) { items.map { SourceRoot(it.name, store.toNode(it)) } }
        val version = try {
            applicationContext.packageManager.getPackageInfo(applicationContext.packageName, 0).versionName ?: ""
        } catch (e: Exception) { "" }

        val outcome = track { cancel, progress ->
            BackupEngine(repo).run(roots, name, version, cancel, progress)
        }
        return when (outcome) {
            is BackupOutcome.Success ->
                Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_SUCCESS, Jobs.K_BACKUP_ID to outcome.manifest.id))
            BackupOutcome.Cancelled -> Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_CANCELLED))
            BackupOutcome.EmptySource -> Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_EMPTY))
            is BackupOutcome.Failed -> fail(outcome.code)
        }
    }
}

class RestoreWorker(ctx: Context, params: WorkerParameters) : JobWorker(ctx, params) {
    override val title: String get() = applicationContext.getString(R.string.notif_restore_title)

    override suspend fun doWork(): Result {
        val id = inputData.getString(Jobs.K_BACKUP_ID) ?: return fail(FailureCode.INVALID)
        val destStr = inputData.getString(Jobs.K_DEST) ?: return fail(FailureCode.INVALID)
        val policy = try {
            OverwritePolicy.valueOf(inputData.getString(Jobs.K_POLICY) ?: "SKIP")
        } catch (e: Exception) { OverwritePolicy.SKIP }
        val manifest = repo.loadManifest(id) ?: return fail(FailureCode.MISSING)
        val wanted = JobFiles.readSelection(applicationContext).toSet()
        val selected = manifest.files.filter { it.path in wanted }
        val dest = Uri.parse(destStr)
        val target: com.herotoner.herobackup.core.RestoreTarget = try {
            if (dest.scheme == "file") {
                if (!AllFilesAccess.isGranted()) return fail(FailureCode.PERMISSION_DENIED)
                com.herotoner.herobackup.core.FileRestoreTarget(File(dest.path ?: return fail(FailureCode.INVALID)))
            } else {
                SafRestoreTarget(applicationContext.contentResolver, dest)
            }
        } catch (e: Exception) {
            return fail(FailureCode.PERMISSION_DENIED)
        }
        try {
            val report = track { cancel, progress ->
                RestoreEngine(repo).restore(manifest, selected, target, policy, cancel, progress)
            }
            JobFiles.writeReport(applicationContext, "restore", report.toJson())
            return Result.success(
                workDataOf(
                    Jobs.K_STATUS to if (report.cancelled) Jobs.ST_CANCELLED else Jobs.ST_SUCCESS,
                    Jobs.K_BACKUP_ID to id,
                )
            )
        } finally {
            release(dest)
        }
    }
}

class TransferWorker(ctx: Context, params: WorkerParameters) : JobWorker(ctx, params) {
    override val title: String get() = applicationContext.getString(R.string.notif_transfer_title)

    override suspend fun doWork(): Result {
        val mode = inputData.getString(Jobs.K_MODE) ?: return fail(FailureCode.INVALID)
        val uri = Uri.parse(inputData.getString(Jobs.K_URI) ?: return fail(FailureCode.INVALID))
        val engine = TransferEngine(repo)
        try {
            if (mode == "export") {
                val id = inputData.getString(Jobs.K_BACKUP_ID) ?: return fail(FailureCode.INVALID)
                val manifest = repo.loadManifest(id) ?: return fail(FailureCode.MISSING)
                val target = try {
                    SafRestoreTarget(applicationContext.contentResolver, uri)
                } catch (e: Exception) { return fail(FailureCode.PERMISSION_DENIED) }
                val rep = track { cancel, progress -> engine.export(manifest, target, cancel, progress) }
                JobFiles.writeReport(
                    applicationContext, "transfer",
                    Json.stringify(
                        linkedMapOf(
                            "mode" to "export", "already" to rep.alreadyExported, "cancelled" to rep.cancelled,
                            "imported" to emptyList<String>(), "skipped" to emptyList<String>(),
                            "failed" to rep.failed.map { linkedMapOf("path" to it.path, "code" to it.code) },
                        )
                    ),
                )
                return Result.success(workDataOf(Jobs.K_STATUS to if (rep.cancelled) Jobs.ST_CANCELLED else Jobs.ST_SUCCESS))
            } else {
                val node = try {
                    SafNode.root(applicationContext.contentResolver, uri)
                } catch (e: Exception) { return fail(FailureCode.PERMISSION_DENIED) }
                val rep = track { cancel, progress -> engine.importFrom(node, cancel, progress) }
                JobFiles.writeReport(
                    applicationContext, "transfer",
                    Json.stringify(
                        linkedMapOf(
                            "mode" to "import", "already" to false, "cancelled" to rep.cancelled,
                            "imported" to rep.imported, "skipped" to rep.skippedExisting,
                            "failed" to rep.failed.map { linkedMapOf("path" to it.path, "code" to it.code) },
                        )
                    ),
                )
                return Result.success(workDataOf(Jobs.K_STATUS to if (rep.cancelled) Jobs.ST_CANCELLED else Jobs.ST_SUCCESS))
            }
        } finally {
            release(uri)
        }
    }
}


/** يحوّل العوالم إلى MCWORLD والمودات إلى MCADDON/MCPACK ويحفظ كل ملف مستقلاً داخل نسخة في المستودع. */
class ConvertWorker(ctx: Context, params: WorkerParameters) : JobWorker(ctx, params) {
    override val title: String get() = applicationContext.getString(R.string.notif_convert_title)

    override suspend fun doWork(): Result {
        val mode = inputData.getString(Jobs.K_MODE) ?: return fail(FailureCode.INVALID)
        val name = inputData.getString(Jobs.K_NAME) ?: ""
        val keys = JobFiles.readSelection(applicationContext).toSet()
        if (keys.isEmpty()) return fail(FailureCode.INVALID)
        val store = SourceStore(applicationContext)
        val items = store.list()
        com.herotoner.herobackup.shizuku.ShizukuHelper.init(applicationContext)
        val roots = withContext(Dispatchers.IO) {
            items.filter { store.hasPermission(it) }.map { SourceRoot(it.name, store.toNode(it)) }
        }
        if (roots.isEmpty()) return fail(FailureCode.PERMISSION_DENIED)
        val version = try {
            applicationContext.packageManager.getPackageInfo(applicationContext.packageName, 0).versionName ?: ""
        } catch (e: Exception) { "" }
        repo.cleanupIncomplete()

        val outcome = track { cancel, progress ->
            progress(Progress(0, 0, 0, 0, ""))
            val jobs = ArrayList<com.herotoner.herobackup.core.ConvertJob>()
            if (mode == "worlds") {
                val scan = com.herotoner.herobackup.core.WorldScanner.scan(roots, cancel) { progress(Progress(0, 0, 0, 0, it)) }
                scan.worlds.filter { it.key in keys }.forEach { jobs += com.herotoner.herobackup.core.ConvertJob.World(it) }
            } else {
                val scan = com.herotoner.herobackup.core.PackScanner.scan(roots, cancel)
                val match = com.herotoner.herobackup.core.PackMatcher.match(scan.packs)
                match.pairs.filter { "pair:" + it.key in keys }.forEach { jobs += com.herotoner.herobackup.core.ConvertJob.Addon(it) }
                (match.rpOnly + match.bpOnly + match.others).filter { "pack:" + it.key in keys }
                    .forEach { jobs += com.herotoner.herobackup.core.ConvertJob.Pack(it) }
            }
            com.herotoner.herobackup.core.ConvertEngine(repo).run(jobs, name, version, cancel, progress)
        }
        fun report(f: List<com.herotoner.herobackup.core.FailureEntry>) = JobFiles.writeReport(
            applicationContext, "convert",
            Json.stringify(linkedMapOf("failed" to f.map { linkedMapOf("path" to it.path, "code" to it.code, "detail" to it.detail) })),
        )
        return when (outcome) {
            is com.herotoner.herobackup.core.ConvertOutcome.Success -> {
                report(outcome.manifest.failures)
                Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_SUCCESS, Jobs.K_BACKUP_ID to outcome.manifest.id))
            }
            com.herotoner.herobackup.core.ConvertOutcome.Cancelled -> Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_CANCELLED))
            com.herotoner.herobackup.core.ConvertOutcome.NothingToDo -> Result.success(workDataOf(Jobs.K_STATUS to Jobs.ST_EMPTY))
            is com.herotoner.herobackup.core.ConvertOutcome.Failed -> { report(outcome.failures); fail(outcome.code) }
        }
    }
}
