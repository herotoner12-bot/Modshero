package com.herotoner.herobackup.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.BackupInfo
import com.herotoner.herobackup.core.BackupStatus
import com.herotoner.herobackup.data.PickTree

@Composable
fun BackupsScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    onDetails: (String) -> Unit,
    onRestore: (String) -> Unit,
    onJob: () -> Unit,
) {
    val ctx = LocalContext.current
    val backups by vm.backups.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<BackupInfo?>(null) }
    val pickImport = rememberLauncherForActivityResult(PickTree()) { uri ->
        if (uri != null && vm.startImport(uri)) onJob()
    }

    ScreenScaffold(stringResource(R.string.title_backups), onBack) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (job?.active == true) {
                item {
                    InfoBanner(stringResource(R.string.job_running_banner), modifier = Modifier.clickable(onClick = onJob))
                }
            }
            if (backups.isNotEmpty()) {
                item { InfoBanner(stringResource(R.string.private_storage_warning), warning = true) }
            }
            item {
                BigButton(
                    stringResource(R.string.import_backup), { pickImport.launch(false) },
                    iconRes = R.drawable.ic_import, primary = false, enabled = job?.active != true,
                )
            }
            if (backups.isEmpty()) {
                item { Muted(stringResource(R.string.no_backups)) }
            }
            items(backups, key = { it.id }) { b ->
                HeroCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(b.name, color = HeroColors.Text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Muted(formatDate(b.createdAt))
                        }
                        IconButton(onClick = { toDelete = b }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete), tint = HeroColors.Danger)
                        }
                    }
                    Muted(stringResource(R.string.backup_meta, formatBytes(ctx, b.totalBytes), b.fileCount))
                    if (b.status == BackupStatus.PARTIAL) {
                        Text(
                            stringResource(R.string.badge_partial, b.failureCount),
                            color = HeroColors.Warning, fontSize = 13.sp,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onDetails(b.id) }, modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                        ) { Text(stringResource(R.string.details), color = HeroColors.Primary) }
                        OutlinedButton(
                            onClick = { onRestore(b.id) }, modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                        ) { Text(stringResource(R.string.restore), color = HeroColors.Primary) }
                    }
                }
            }
        }
    }

    toDelete?.let { b ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_text, b.name)) },
            confirmButton = {
                TextButton(onClick = { vm.deleteBackup(b.id); toDelete = null }) {
                    Text(stringResource(R.string.delete), color = HeroColors.Danger)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(stringResource(R.string.cancel)) } },
            containerColor = HeroColors.Card,
            titleContentColor = HeroColors.Text,
            textContentColor = HeroColors.TextSecondary,
        )
    }
}
