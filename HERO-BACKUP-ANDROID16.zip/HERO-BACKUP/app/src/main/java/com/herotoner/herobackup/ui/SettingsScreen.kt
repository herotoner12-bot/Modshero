package com.herotoner.herobackup.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onBackups: () -> Unit, onPermission: () -> Unit, onShizuku: () -> Unit) {
    val ctx = LocalContext.current
    val stats by vm.stats.collectAsStateWithLifecycle()
    val allFiles by vm.allFiles.collectAsStateWithLifecycle()
    val shz by com.herotoner.herobackup.shizuku.ShizukuHelper.status.collectAsStateWithLifecycle()
    val version = remember(ctx) {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    LaunchedEffect(Unit) { vm.refreshBackups() }

    ScreenScaffold(stringResource(R.string.settings), onBack) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroCard {
                    SectionTitle(stringResource(R.string.set_language))
                    Text(stringResource(R.string.set_language_value), color = HeroColors.Primary, fontWeight = FontWeight.Bold)
                    SectionTitle(stringResource(R.string.set_theme))
                    Text(stringResource(R.string.set_theme_value), color = HeroColors.Primary, fontWeight = FontWeight.Bold)
                }
            }
            item {
                HeroCard {
                    SectionTitle(stringResource(R.string.title_permission))
                    Text(
                        stringResource(
                            when {
                                !com.herotoner.herobackup.data.AllFilesAccess.applicable -> R.string.perm_status_na
                                allFiles -> R.string.perm_status_on
                                else -> R.string.perm_status_off
                            }
                        ),
                        color = if (allFiles) HeroColors.Primary else HeroColors.Warning, fontWeight = FontWeight.Bold,
                    )
                    BigButton(stringResource(R.string.perm_page_open), onPermission, primary = false)
                }
            }
            item {
                HeroCard {
                    SectionTitle(stringResource(R.string.title_shizuku))
                    Text(
                        stringResource(shizukuStatusRes(shz)),
                        color = if (shz == com.herotoner.herobackup.shizuku.ShizukuStatus.CONNECTED) HeroColors.Primary else HeroColors.Warning,
                        fontWeight = FontWeight.Bold,
                    )
                    BigButton(stringResource(R.string.shz_open_page), onShizuku, primary = false)
                }
            }
            item {
                HeroCard {
                    SectionTitle(stringResource(R.string.set_location))
                    Text(vm.repo.root.absolutePath, color = HeroColors.Text, fontSize = 12.sp)
                    Muted(stringResource(R.string.set_location_note))
                }
            }
            item { InfoBanner(stringResource(R.string.private_storage_warning), warning = true) }
            item {
                HeroCard {
                    SectionTitle(stringResource(R.string.set_manage))
                    Muted(stringResource(R.string.backup_meta, formatBytes(ctx, stats.usedBytes), stats.count))
                    if (stats.incomplete > 0) {
                        Text(stringResource(R.string.incomplete_found, stats.incomplete), color = HeroColors.Warning, fontSize = 13.sp)
                        BigButton(stringResource(R.string.cleanup_incomplete), { vm.cleanupIncomplete() }, primary = false)
                    }
                    BigButton(stringResource(R.string.show_backups), onBackups, primary = false)
                }
            }
            item {
                HeroCard {
                    SectionTitle(stringResource(R.string.set_about))
                    Text("HERO BACKUP", color = HeroColors.Text, fontWeight = FontWeight.Bold)
                    Muted(stringResource(R.string.about_developer))
                    Muted(ctx.packageName)
                    Muted(stringResource(R.string.set_version, version))
                }
            }
        }
    }
}
