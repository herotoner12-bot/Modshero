package com.herotoner.herobackup.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.ImportEnv
import com.herotoner.herobackup.core.ImportItem
import com.herotoner.herobackup.core.ImportKind
import com.herotoner.herobackup.core.Remote
import com.herotoner.herobackup.core.RemoteProtocol
import com.herotoner.herobackup.shizuku.ShizukuHelper
import com.herotoner.herobackup.shizuku.ShizukuNode
import com.herotoner.herobackup.shizuku.ShizukuStatus

/** يفتح الملفات في Minecraft عبر Intent رسمي (FileProvider + Content URI)، ويتحقق من النتيجة عبر Shizuku إن كان متصلاً. */
class AndroidImportEnv(private val ctx: Context) : ImportEnv {
    companion object { const val MC = "com.mojang.minecraftpe" }

    private var base: String? = null
    private var baseChecked = false

    override fun launch(item: ImportItem): String? {
        val mc = com.herotoner.herobackup.data.McPackages.primary(ctx) ?: return ctx.getString(R.string.mc_not_installed)
        val uri = try {
            FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", item.file)
        } catch (e: Exception) {
            return ctx.getString(R.string.mc_uri_failed) + " " + (e.message ?: "")
        }
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.clipData = ClipData.newRawUri("", uri)
        ctx.grantUriPermission(mc, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try {
            ctx.startActivity(Intent(intent).setPackage(mc))
            null
        } catch (e: ActivityNotFoundException) {
            try {
                ctx.startActivity(Intent.createChooser(intent, ctx.getString(R.string.open_title)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                null
            } catch (e2: Exception) {
                ctx.getString(R.string.mc_cannot_open)
            }
        } catch (e: Exception) {
            ctx.getString(R.string.mc_cannot_open) + " " + (e.message ?: "")
        }
    }

    private fun service() = if (ShizukuHelper.status.value == ShizukuStatus.CONNECTED) ShizukuHelper.awaitServiceBlocking(3000) else null

    private fun mcBase(svc: com.herotoner.herobackup.shizuku.IFileService): String? {
        if (baseChecked) return base
        baseChecked = true
        val pkg = com.herotoner.herobackup.data.McPackages.primary(ctx) ?: return null
        val roots = com.herotoner.herobackup.core.MinecraftPaths.roots(com.herotoner.herobackup.data.McPackages.userId())
            .filter { !it.startsWith("/data/media") }
        for (p in com.herotoner.herobackup.core.MinecraftPaths.candidates(listOf(pkg), roots)) {
            val r = try { RemoteProtocol.decodeStat(svc.probe(p)) } catch (e: Exception) { null }
            if (r is Remote.Ok && r.value.dir) { base = p; break }
        }
        return base
    }

    override fun snapshot(kind: ImportKind): Set<String>? {
        val svc = service() ?: return null
        val b = mcBase(svc) ?: return null
        val dirs = if (kind == ImportKind.WORLD) listOf("minecraftWorlds") else listOf("resource_packs", "behavior_packs")
        val out = HashSet<String>()
        for (d in dirs) {
            val kids = try { ShizukuNode.root(svc, "$b/$d").children() } catch (e: Exception) { return null }
            for (k in kids) if (k.isDirectory) out += "$d/${k.name}"
        }
        return out
    }

    override fun levelName(folder: String): String? {
        val svc = service() ?: return null
        val b = mcBase(svc) ?: return null
        return try {
            val node = ShizukuNode(svc, "$b/$folder/levelname.txt", "levelname.txt", false, 0L, 0L)
            node.openInput().use { String(it.readBytes(), Charsets.UTF_8) }.lineSequence().firstOrNull()?.trim()?.removePrefix("\uFEFF")
        } catch (e: Exception) { null }
    }
}
