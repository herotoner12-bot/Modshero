package com.herotoner.herobackup.ui

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import com.herotoner.herobackup.core.*
import com.herotoner.herobackup.data.AccessDiscovery
import com.herotoner.herobackup.data.AllFilesAccess
import com.herotoner.herobackup.data.McPackages
import com.herotoner.herobackup.data.SourceStore
import com.herotoner.herobackup.shizuku.MinecraftProbe
import com.herotoner.herobackup.shizuku.ShizukuHelper
import java.io.File
import java.security.MessageDigest

data class Quick(val android: String, val device: String, val minecraft: String, val methods: String)

/** فحص توافق الجهاز: كل اختبار هنا ينفّذ عملية حقيقية على هذا الجهاز، لا محاكاة. */
object CompatChecks {
    const val G_DEVICE = "الجهاز"
    const val G_MC = "Minecraft"
    const val G_STORAGE = "صلاحيات التخزين"
    const val G_SHIZUKU = "Shizuku"
    const val G_ACCESS = "طرق الوصول لملفات Minecraft"
    const val G_ENGINES = "اختبار المحركات على هذا الجهاز"
    const val G_BG = "الخلفية والشركة المصنّعة"
    const val G_SUMMARY = "الخلاصة"

    private fun oemAdvice(f: OemFamily): String = when (f) {
        OemFamily.XIAOMI -> "Xiaomi/Redmi/POCO (MIUI أو HyperOS): فعّل «التشغيل التلقائي» للتطبيق، واجعل توفير البطارية «بلا قيود»، وثبّت التطبيق في قائمة التطبيقات الأخيرة أثناء العمليات الطويلة."
        OemFamily.SAMSUNG -> "Samsung (One UI): أزل التطبيق من «التطبيقات النائمة» و«النائمة العميقة»، واجعل استخدام البطارية «غير مقيّد»."
        OemFamily.OPPO -> "OPPO/Realme/OnePlus (ColorOS/OxygenOS/Realme UI): اسمح بـ«التشغيل التلقائي» و«النشاط في الخلفية» وبلا قيود بطارية."
        OemFamily.TRANSSION -> "TECNO/Infinix (HiOS/XOS): أضف التطبيق إلى «بدء التشغيل التلقائي» وفي إدارة الطاقة استثنِه من التحسين."
        OemFamily.GOOGLE -> "Google Pixel: قيود قياسية؛ استثنِ التطبيق من تحسين البطارية فقط إن توقفت العمليات الطويلة."
        OemFamily.MOTOROLA -> "Motorola: قيود قريبة من Android الأصلي؛ استثنِ التطبيق من تحسين البطارية إن لزم."
        OemFamily.OTHER -> "شركة غير معروفة: إن أُغلقت العمليات الطويلة، استثنِ التطبيق من تحسين البطارية وفعّل التشغيل في الخلفية من إعدادات النظام."
    } + " (قد تختلف أسماء القوائم حسب الإصدار.)"

    private fun deviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim()

    fun quick(ctx: Context, store: SourceStore): Quick {
        AllFilesAccess.init(ctx)
        ShizukuHelper.init(ctx)
        val mc = McPackages.installed(ctx)
        val providers = AccessDiscovery.providers(ctx, store)
        val ready = providers.filter { runCatching { it.precheck().ready }.getOrDefault(false) }.map { methodLabel(it.method) }
        return Quick(
            ApiSupport.androidName(Build.VERSION.SDK_INT) + " (API ${Build.VERSION.SDK_INT})",
            deviceName(),
            if (mc.isEmpty()) "Minecraft غير مثبّت" else mc.joinToString("، ") { "${it.pkg.substringAfterLast('.')} ${it.versionName}" },
            if (ready.isEmpty()) "لا توجد طريقة وصول مباشرة جاهزة؛ البديل الرسمي (استيراد/تصدير عبر Minecraft)" else ready.joinToString("، "),
        )
    }

    private fun w(f: File, bytes: ByteArray) { f.parentFile?.mkdirs(); f.writeBytes(bytes) }
    private fun w(f: File, t: String) = w(f, t.toByteArray())
    private fun sha(f: File) = Hashing.sha256(f)

    private fun readSample(node: SourceNode): Triple<String, Long, String>? {
        val queue = ArrayDeque<Pair<SourceNode, String>>()
        queue.addLast(node to "")
        var seen = 0
        while (queue.isNotEmpty() && seen < 250) {
            val (d, p) = queue.removeFirst(); seen++
            val kids = try { d.children() } catch (e: Exception) { continue }
            for (k in kids) {
                if (k.isDirectory) { if (p.count { it == '/' } < 4) queue.addLast(k to "$p/${k.name}") }
                else if (k.name == "level.dat" || k.name == "levelname.txt" || k.name == "manifest.json") {
                    val md = MessageDigest.getInstance("SHA-256"); var n = 0L
                    k.openInput().use { ins -> val b = ByteArray(8192); while (true) { val r = ins.read(b); if (r < 0) break; md.update(b, 0, r); n += r } }
                    return Triple("$p/${k.name}".trimStart('/'), n, Hashing.hex(md.digest()).take(16))
                }
            }
        }
        return null
    }

    fun run(ctx: Context, store: SourceStore, emit: (CheckResult) -> Unit) {
        AllFilesAccess.init(ctx)
        ShizukuHelper.init(ctx)
        val sdk = Build.VERSION.SDK_INT
        fun r(g: String, t: String, s: CheckStatus, d: String = "") = emit(CheckResult(g, t, s, d))
        fun guard(g: String, t: String, block: () -> Unit) {
            try { block() } catch (e: Throwable) { r(g, t, CheckStatus.FAIL, "خطأ غير متوقع: " + (e.message ?: e.javaClass.simpleName)) }
        }

        // ---- الجهاز ----
        guard(G_DEVICE, "إصدار Android") {
            r(G_DEVICE, "إصدار Android", if (ApiSupport.supported(sdk)) CheckStatus.PASS else CheckStatus.FAIL,
                "${ApiSupport.androidName(sdk)} (API $sdk، ${Build.VERSION.RELEASE})" + if (!ApiSupport.supported(sdk)) " — أقل من الحد الأدنى ${ApiSupport.androidName(ApiSupport.MIN_SDK)}" else "")
        }
        r(G_DEVICE, "الشركة والجهاز", CheckStatus.INFO, "${Build.MANUFACTURER} / ${Build.BRAND} / ${Build.MODEL} (${Build.DEVICE})")
        r(G_DEVICE, "إصدار النظام (ROM)", CheckStatus.INFO, Build.DISPLAY ?: "")
        r(G_DEVICE, "المعمارية", CheckStatus.INFO, Build.SUPPORTED_ABIS.joinToString())

        // ---- Minecraft ----
        val mc = McPackages.installed(ctx)
        if (mc.isEmpty()) r(G_MC, "Minecraft Bedrock", CheckStatus.WARN, "غير مثبّت. يمكنك مع ذلك نسخ وتحويل الملفات التي تختارها.")
        else mc.forEach { r(G_MC, it.pkg, CheckStatus.PASS, "الإصدار ${it.versionName} (${it.versionCode})") }

        // ---- صلاحيات التخزين ----
        guard(G_STORAGE, "الوصول المباشر للملفات") {
            when (ApiSupport.directFilesKind(sdk)) {
                DirectFilesKind.ALL_FILES -> r(G_STORAGE, "جميع الملفات (MANAGE_EXTERNAL_STORAGE)",
                    if (AllFilesAccess.isGranted()) CheckStatus.PASS else CheckStatus.WARN,
                    if (AllFilesAccess.isGranted()) "مفعّلة" else "غير مفعّلة (اختيارية)")
                DirectFilesKind.LEGACY_PERMISSION -> r(G_STORAGE, "صلاحية التخزين التقليدية",
                    if (AllFilesAccess.isGranted()) CheckStatus.PASS else CheckStatus.WARN,
                    if (AllFilesAccess.isGranted()) "ممنوحة" else "غير ممنوحة (اختيارية)")
                DirectFilesKind.NONE -> r(G_STORAGE, "الوصول المباشر للملفات", CheckStatus.SKIP, "Android 10: لا توجد صلاحية شاملة، تُستخدم SAF وShizuku")
            }
        }
        guard(G_STORAGE, "SAF") {
            val picker = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).resolveActivity(ctx.packageManager) != null
            r(G_STORAGE, "منتقي المجلدات (SAF)", if (picker) CheckStatus.PASS else CheckStatus.FAIL,
                if (picker) "متوفر" else "غير متوفر على هذا الجهاز")
            val persisted = ctx.contentResolver.persistedUriPermissions.size
            r(G_STORAGE, "مجلدات SAF الممنوحة", CheckStatus.INFO, "$persisted")
            r(G_STORAGE, "وصول SAF إلى Android/data", CheckStatus.INFO,
                if (ApiSupport.safMayReachAndroidData(sdk)) "قد يسمح به هذا الإصدار" else "محجوب غالباً من Android 11 فما فوق")
        }
        if (sdk >= 33) r(G_STORAGE, "إشعارات التقدم", if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) CheckStatus.PASS else CheckStatus.WARN,
            if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) "مفعّلة" else "معطّلة: تعمل العمليات لكن دون إشعار تقدم")

        // ---- Shizuku (كل طبقة مستقلة) ----
        guard(G_SHIZUKU, "Shizuku") {
            val s = ShizukuHelper.snapshot(ctx)
            r(G_SHIZUKU, "تطبيق Shizuku", if (s.installed || s.binderAlive) CheckStatus.PASS else CheckStatus.INFO,
                if (s.installed || s.binderAlive) "مثبّت" else "غير مثبّت (اختياري)")
            r(G_SHIZUKU, "خادم Shizuku", if (s.binderAlive) CheckStatus.PASS else CheckStatus.INFO,
                if (s.binderAlive) "يعمل، إصدار API ${s.serverVersion}" else "غير مشغّل")
            val permStatus = when (s.permission) { "GRANTED" -> CheckStatus.PASS; "UNKNOWN" -> CheckStatus.SKIP; else -> CheckStatus.WARN }
            r(G_SHIZUKU, "صلاحية التطبيق", permStatus, when (s.permission) {
                "GRANTED" -> "ممنوحة"; "ASK" -> "لم تُطلب بعد"; "DENIED" -> "مرفوضة"
                "UNSUPPORTED" -> "إصدار Shizuku قديم (قبل v11)"; else -> "غير معروفة لأن الخادم غير مشغّل" })
            if (s.permission == "GRANTED") {
                val svc = kotlinx.coroutines.runBlocking { ShizukuHelper.awaitService(8000) }
                if (svc == null) r(G_SHIZUKU, "خدمة الملفات (UserService)", CheckStatus.FAIL, "تعذر ربط الخدمة: " + (ShizukuHelper.lastError.value ?: "سبب غير معروف") + "\nشغّل «اختبار اتصال Binder» من صفحة Shizuku للتشخيص المفصل.")
                else {
                    val uid = try { svc.getUid() } catch (e: Exception) { -1 }
                    r(G_SHIZUKU, "خدمة الملفات (UserService)", if (uid >= 0) CheckStatus.PASS else CheckStatus.FAIL,
                        if (uid >= 0) "تستجيب، هوية uid=$uid" + (if (uid == 0) " (root)" else if (uid == 2000) " (shell)" else "") else "لا تستجيب")
                    val pr = MinecraftProbe.check(ctx, svc)
                    r(G_SHIZUKU, "قراءة مجلد Minecraft عبر Shizuku", if (pr.workingPath != null) CheckStatus.PASS else CheckStatus.FAIL,
                        pr.workingPath ?: pr.lines.lastOrNull()?.detail ?: "")
                }
            } else r(G_SHIZUKU, "خدمة الملفات (UserService)", CheckStatus.SKIP, "تحتاج صلاحية Shizuku أولاً")
        }

        // ---- طرق الوصول لملفات Minecraft ----
        var readResult: CheckResult? = null
        guard(G_ACCESS, "اكتشاف الطرق") {
            val d = AccessDiscovery.run(ctx, store)
            val seen = HashSet<String>()
            for (a in d.attempts) {
                val st = when (a.result) {
                    AttemptResult.FOUND -> CheckStatus.PASS
                    AttemptResult.NOT_READY -> CheckStatus.WARN
                    AttemptResult.UNAVAILABLE -> CheckStatus.SKIP
                    else -> CheckStatus.FAIL
                }
                val key = a.method.name + a.result.name + a.detail
                if (a.result == AttemptResult.MISSING && !seen.add(key)) continue // لا نكرر نفس الرسالة لكل مسار
                r(G_ACCESS, methodLabel(a.method) + (if (a.label.isNotBlank()) " — ${a.label}" else ""), st, attemptLabel(a.result) + (if (a.detail.isNotBlank()) ": ${a.detail}" else ""))
            }
            val f = d.found
            if (f != null) {
                r(G_ACCESS, "أفضل طريقة متاحة", CheckStatus.PASS, methodLabel(f.method))
                val sample = try { readSample(f.node) } catch (e: Exception) { null }
                readResult = if (sample != null)
                    CheckResult(G_ACCESS, "قراءة ملف فعلي من Minecraft", CheckStatus.PASS, "${sample.first} (${sample.second} بايت، SHA-256 ${sample.third}…)")
                else CheckResult(G_ACCESS, "قراءة ملف فعلي من Minecraft", CheckStatus.WARN, "المجلد متاح لكن لم يُعثر على ملف صغير للاختبار")
                emit(readResult!!)
            } else {
                r(G_ACCESS, "أفضل طريقة متاحة", CheckStatus.WARN, "لا توجد طريقة مباشرة تعمل؛ البديل الرسمي: صدّر العالم من Minecraft وشاركه إلى HERO BACKUP، أو اختر المجلدات/الملفات بنفسك")
                readResult = CheckResult(G_ACCESS, "قراءة ملفات Minecraft مباشرة", CheckStatus.FAIL, "لا توجد طريقة وصول مباشرة تعمل حالياً")
                emit(readResult!!)
            }
        }
        guard(G_ACCESS, "الاستيراد الرسمي") {
            val pm = ctx.packageManager
            val pkg = McPackages.primary(ctx)
            if (pkg == null) r(G_ACCESS, "فتح الملفات في Minecraft (استيراد رسمي)", CheckStatus.FAIL, "Minecraft غير مثبّت")
            else {
                val probe = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse("content://${ctx.packageName}.fileprovider/backups/x/data/mcworld/test.mcworld"), "application/octet-stream")
                    .setPackage(pkg)
                val n = pm.queryIntentActivities(probe, 0).size
                r(G_ACCESS, "فتح الملفات في Minecraft (استيراد رسمي)", if (n > 0) CheckStatus.PASS else CheckStatus.WARN,
                    if (n > 0) "$pkg يقبل ملفات mcworld/mcpack/mcaddon" else "لم يُرصد مرشّح مباشر؛ سيُستخدم منتقي التطبيقات")
            }
            val recv = pm.queryIntentActivities(Intent(Intent.ACTION_SEND).setType("application/octet-stream").setPackage(ctx.packageName), 0).size
            r(G_ACCESS, "الاستلام من Minecraft (مشاركة/تصدير رسمي)", if (recv > 0) CheckStatus.PASS else CheckStatus.FAIL,
                if (recv > 0) "HERO BACKUP يظهر كوجهة مشاركة" else "غير مسجّل")
        }

        // ---- محركات النسخ والاستعادة والتحويل (تنفيذ حقيقي بملفات مؤقتة على هذا الجهاز) ----
        val tmp = File(ctx.cacheDir, "compat-" + System.nanoTime())
        var backupRes: CheckResult? = null
        var restoreRes: CheckResult? = null
        try {
            guard(G_ENGINES, "مساحة التخزين") {
                val free = ctx.filesDir.usableSpace
                r(G_ENGINES, "المساحة الحرة لمساحة التطبيق", if (free > 200L * 1024 * 1024) CheckStatus.PASS else CheckStatus.WARN,
                    "${free / (1024 * 1024)} م.ب")
            }
            val src = File(tmp, "src")
            w(File(src, "ملف عربي ١.txt"), "بيانات اختبار")
            w(File(src, "مجلد/ملف داخلي.bin"), ByteArray(300_000) { (it * 7).toByte() })
            w(File(src, "big.bin"), ByteArray(2_000_000) { (it * 13 + 5).toByte() })
            File(src, "فارغ").mkdirs()
            val repo = BackupRepository(File(tmp, "backups"))
            var manifest: Manifest? = null
            guard(G_ENGINES, "إنشاء نسخة احتياطية") {
                val t0 = System.nanoTime()
                val o = BackupEngine(repo).run(listOf(SourceRoot("src", FileSourceNode(src))), "compat", "3.0.0")
                val ms = (System.nanoTime() - t0) / 1_000_000
                if (o is BackupOutcome.Success) {
                    manifest = o.manifest
                    val v = Verifier.verify(repo, o.manifest)
                    val ok = v != null && v.ok && o.manifest.files.size == 3
                    backupRes = CheckResult(G_ENGINES, "إنشاء نسخة احتياطية (SHA-256 + أسماء عربية)", if (ok) CheckStatus.PASS else CheckStatus.FAIL,
                        "${o.manifest.files.size} ملف في $ms مللي ثانية، التحقق: " + if (ok) "سليم" else "فشل")
                } else backupRes = CheckResult(G_ENGINES, "إنشاء نسخة احتياطية", CheckStatus.FAIL, o.toString())
                emit(backupRes!!)
            }
            guard(G_ENGINES, "الاستعادة") {
                val m = manifest
                if (m == null) { restoreRes = CheckResult(G_ENGINES, "استعادة نسخة", CheckStatus.SKIP, "تعذر إنشاء نسخة للاختبار") }
                else {
                    val dest = File(tmp, "restore")
                    val rep = RestoreEngine(repo).restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.SKIP)
                    val same = m.files.all { e -> File(dest, e.path).let { it.isFile && sha(it) == e.sha256 } }
                    val again = RestoreEngine(repo).restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.SKIP)
                    val ok = rep.failed.isEmpty() && rep.restored.size == m.files.size && same && again.skipped.size == m.files.size
                    restoreRes = CheckResult(G_ENGINES, "استعادة نسخة (دون الكتابة فوق الموجود)", if (ok) CheckStatus.PASS else CheckStatus.FAIL,
                        "استُعيد ${rep.restored.size}، وتخطّى الثاني ${again.skipped.size} موجود، تطابق المحتوى: $same")
                }
                emit(restoreRes!!)
            }
            guard(G_ENGINES, "MCWORLD") {
                val wd = File(tmp, "mc/minecraftWorlds/w1")
                w(File(wd, "level.dat"), ByteArray(400) { it.toByte() }); w(File(wd, "levelname.txt"), "عالم الاختبار")
                w(File(wd, "db/CURRENT"), "MANIFEST-000001\n"); w(File(wd, "db/MANIFEST-000001"), ByteArray(100)); w(File(wd, "db/000003.log"), ByteArray(500))
                w(File(wd, "ملفات/ملف عربي.txt"), "ع"); File(wd, "empty").mkdirs()
                val ws = WorldScanner.scan(listOf(SourceRoot("mc", FileSourceNode(File(tmp, "mc")))))
                val repo2 = BackupRepository(File(tmp, "b2"))
                val o = if (ws.worlds.size == 1) ConvertEngine(repo2).run(listOf(ConvertJob.World(ws.worlds[0])), "w", "3.0.0") else null
                val ok = o is ConvertOutcome.Success && McArchives.inspectWorld(repo2.dataFile(o.manifest.id, o.manifest.files[0].stored)).ok
                r(G_ENGINES, "محرك MCWORLD (اكتشاف + تحويل + تحقق)", if (ok) CheckStatus.PASS else CheckStatus.FAIL,
                    if (ok) "عالم تجريبي مؤقت تحوّل وتحقق منه (ليس عالمك)" else "فشل: " + (o?.toString() ?: "لم يُكتشف العالم التجريبي"))
            }
            guard(G_ENGINES, "MCADDON") {
                val a = "11111111-1111-4111-8111-111111111111"; val b = "22222222-2222-4222-8222-222222222222"
                val c = "33333333-3333-4333-8333-333333333333"; val d = "44444444-4444-4444-8444-444444444444"
                fun mf(n: String, u: String, m: String, mt: String, deps: String) =
                    """{"format_version":2,"header":{"name":"$n","description":"d","uuid":"$u","version":[1,0,0],"min_engine_version":[1,20,0]},"modules":[{"type":"$mt","uuid":"$m","version":[1,0,0]}]$deps}"""
                val pk = File(tmp, "packs")
                w(File(pk, "اختبار.rp/manifest.json"), mf("RP", a, b, "resources", "")); w(File(pk, "اختبار.rp/texts/ar.lang"), "x=y")
                w(File(pk, "اختبار.bp/manifest.json"), mf("BP", c, d, "data", ""","dependencies":[{"uuid":"$a","version":[1,0,0]}]"""))
                val ps = PackScanner.scan(listOf(SourceRoot("packs", FileSourceNode(pk))))
                val mr = PackMatcher.match(ps.packs)
                val repo3 = BackupRepository(File(tmp, "b3"))
                val o = if (mr.pairs.size == 1) ConvertEngine(repo3).run(listOf(ConvertJob.Addon(mr.pairs[0])), "a", "3.0.0") else null
                val ok = o is ConvertOutcome.Success && McArchives.inspectPack(repo3.dataFile(o.manifest.id, o.manifest.files[0].stored), true).ok
                r(G_ENGINES, "محرك MCADDON (مطابقة RP/BP + دمج + تحقق)", if (ok) CheckStatus.PASS else CheckStatus.FAIL,
                    if (ok) "زوج تجريبي مؤقت اندمج وتحقق منه (ليس مودّك)" else "فشل: " + (o?.toString() ?: "لم تتطابق الحزمتان"))
            }
        } finally {
            tmp.deleteRecursively()
        }

        // ---- الخلفية والشركة ----
        guard(G_BG, "تحسين البطارية") {
            val pm = ctx.getSystemService(PowerManager::class.java)
            val ignoring = pm?.isIgnoringBatteryOptimizations(ctx.packageName) == true
            r(G_BG, "استثناء من تحسين البطارية", if (ignoring) CheckStatus.PASS else CheckStatus.INFO,
                if (ignoring) "مستثنى" else "غير مستثنى (قد تتوقف العمليات الطويلة على بعض الأجهزة)")
        }
        if (sdk >= 28) guard(G_BG, "قيود الخلفية") {
            val restricted = ctx.getSystemService(ActivityManager::class.java)?.isBackgroundRestricted == true
            r(G_BG, "تقييد النشاط في الخلفية", if (restricted) CheckStatus.WARN else CheckStatus.PASS,
                if (restricted) "التطبيق مقيّد في الخلفية من إعدادات النظام" else "غير مقيّد")
        }
        val fam = Oem.detect(Build.MANUFACTURER, Build.BRAND)
        r(G_BG, "نصيحة للشركة المصنّعة", CheckStatus.INFO, oemAdvice(fam))

        // ---- الخلاصة ----
        emit(readResult?.copy(group = G_SUMMARY, title = "إمكانية قراءة ملفات Minecraft")
            ?: CheckResult(G_SUMMARY, "إمكانية قراءة ملفات Minecraft", CheckStatus.SKIP, ""))
        emit(backupRes?.copy(group = G_SUMMARY, title = "إمكانية إنشاء نسخة احتياطية")
            ?: CheckResult(G_SUMMARY, "إمكانية إنشاء نسخة احتياطية", CheckStatus.SKIP, ""))
        emit(restoreRes?.copy(group = G_SUMMARY, title = "إمكانية الاستعادة")
            ?: CheckResult(G_SUMMARY, "إمكانية الاستعادة", CheckStatus.SKIP, ""))
    }
}
