package com.herotoner.herobackup.core

data class WorldInfo(
    val key: String,
    val name: String,
    val folderName: String,
    val rootName: String,
    val node: SourceNode,
    val sizeBytes: Long,
    val fileCount: Int,
    val lastModified: Long,
)

class IncompleteWorld(val path: String, val reason: String)

data class WorldScanResult(
    val worlds: List<WorldInfo>,
    val incomplete: List<IncompleteWorld>,
    val failures: List<FailureEntry>,
    val truncated: Boolean,
)

/** يكتشف مجلدات العوالم الحقيقية فقط: level.dat + مجلد db فيه CURRENT وMANIFEST. أي مجلد عشوائي لا يُعدّ عالماً. */
object WorldScanner {
    private const val MAX_DIRS = 20000

    private fun readLevelName(kids: List<SourceNode>): String? {
        val n = kids.firstOrNull { !it.isDirectory && it.name == "levelname.txt" } ?: return null
        return try {
            val bytes = PackScanner.readCapped(n, 4096)
            String(bytes, Charsets.UTF_8).lineSequence().firstOrNull()?.trim()?.removePrefix("\uFEFF")?.ifBlank { null }
        } catch (e: Exception) { null }
    }

    fun scan(
        roots: List<SourceRoot>,
        cancel: () -> Boolean = { false },
        onProgress: (String) -> Unit = {},
    ): WorldScanResult {
        val worlds = ArrayList<WorldInfo>()
        val incomplete = ArrayList<IncompleteWorld>()
        val failures = ArrayList<FailureEntry>()
        var dirs = 0
        var truncated = false
        val rootNames = Names.uniqueRootNames(roots.map { it.displayName })
        roots.forEachIndexed { i, r ->
            val stack = ArrayDeque<Pair<List<String>, SourceNode>>()
            stack.addLast(listOf(rootNames[i]) to r.node)
            while (stack.isNotEmpty()) {
                if (cancel()) throw OperationCancelled()
                if (dirs++ > MAX_DIRS) { truncated = true; break }
                val (parts, dir) = stack.removeLast()
                if (!dir.isDirectory) continue
                val kids = try { dir.children() } catch (e: OperationCancelled) { throw e } catch (e: Exception) {
                    failures += FailureEntry(parts.joinToString("/"), if (e is SecurityException) FailureCode.PERMISSION_DENIED else FailureCode.IO_ERROR, e.message ?: "")
                    continue
                }
                val levelDat = kids.firstOrNull { !it.isDirectory && it.name == "level.dat" }
                val db = kids.firstOrNull { it.isDirectory && it.name == "db" }
                if (levelDat != null) {
                    val path = parts.joinToString("/")
                    if (db == null) { incomplete += IncompleteWorld(path, "يوجد level.dat لكن مجلد db مفقود"); continue }
                    val dbKids = try { db.children() } catch (e: OperationCancelled) { throw e } catch (e: Exception) {
                        failures += FailureEntry("$path/db", if (e is SecurityException) FailureCode.PERMISSION_DENIED else FailureCode.IO_ERROR, e.message ?: "")
                        continue
                    }
                    val hasCurrent = dbKids.any { !it.isDirectory && it.name == "CURRENT" }
                    val hasManifest = dbKids.any { !it.isDirectory && it.name.startsWith("MANIFEST-") }
                    if (!hasCurrent || !hasManifest) {
                        incomplete += IncompleteWorld(path, "مجلد db ناقص (" + (if (!hasCurrent) "CURRENT " else "") + (if (!hasManifest) "MANIFEST" else "") + " مفقود)")
                        continue
                    }
                    onProgress(parts.last())
                    val sum = try { Scanner.summarize(dir, parts.last(), cancel) } catch (e: OperationCancelled) { throw e } catch (e: Exception) {
                        failures += FailureEntry(path, FailureCode.IO_ERROR, e.message ?: ""); continue
                    }
                    for (f in sum.failures) failures += f
                    val name = readLevelName(kids) ?: parts.last()
                    worlds += WorldInfo(path, name, parts.last(), parts.first(), dir, sum.bytes, sum.files, levelDat.lastModified)
                    continue
                }
                for (k in kids.reversed()) if (k.isDirectory) stack.addLast((parts + k.name) to k)
            }
        }
        return WorldScanResult(worlds.sortedBy { it.name.lowercase() }, incomplete, failures, truncated)
    }
}
