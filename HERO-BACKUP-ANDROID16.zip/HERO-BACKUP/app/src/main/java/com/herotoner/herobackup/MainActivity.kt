package com.herotoner.herobackup

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.herotoner.herobackup.ui.AppRoot
import com.herotoner.herobackup.ui.HeroColors
import com.herotoner.herobackup.ui.HeroTheme
import com.herotoner.herobackup.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val mgr: com.herotoner.herobackup.ui.ManagerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        setContent {
            HeroTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = HeroColors.Bg) { AppRoot(vm, mgr) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshBackups()
        vm.refreshPermission()
        mgr.onAppResumed()
    }
}
