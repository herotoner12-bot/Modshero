package com.herotoner.herobackup.ui

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun AppRoot(vm: MainViewModel, mgr: ManagerViewModel, compat: CompatViewModel) {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val msg by vm.message.collectAsStateWithLifecycle()
    LaunchedEffect(msg) {
        msg?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.message.value = null
        }
    }
    val idArg = listOf(navArgument("id") { type = NavType.StringType })

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                vm,
                onBackup = { nav.navigate("select") },
                onRestore = { nav.navigate("backups") },
                onSettings = { nav.navigate("settings") },
                onJob = { nav.navigate("progress") },
                onPermission = { nav.navigate("permission") },
                onShizuku = { nav.navigate("shizuku") },
                onHub = { nav.navigate("hub") },
                mgr = mgr, compat = compat,
                onCompat = { nav.navigate("compat") },
            )
        }
        composable("select") {
            SelectScreen(
                vm,
                onBack = { nav.popBackStack() },
                onStarted = { nav.navigate("progress") { popUpTo("select") { inclusive = true } } },
                onBrowse = { nav.navigate("browse/source") },
                onPermission = { nav.navigate("permission") },
                onShizuku = { nav.navigate("shizuku") },
            )
        }
        composable("progress") {
            ProgressScreen(
                vm,
                onHome = { if (!nav.popBackStack("home", false)) nav.navigate("home") },
                onBackups = { nav.navigate("backups") { popUpTo("home") } },
            )
        }
        composable("backups") {
            BackupsScreen(
                vm,
                onBack = { nav.popBackStack() },
                onDetails = { nav.navigate("details/$it") },
                onRestore = { nav.navigate("restore/$it") },
                onJob = { nav.navigate("progress") },
            )
        }
        composable("details/{id}", arguments = idArg) { entry ->
            DetailsScreen(
                vm, entry.arguments?.getString("id") ?: "",
                onBack = { nav.popBackStack() },
                onRestore = { nav.navigate("restore/$it") },
                onJob = { nav.navigate("progress") },
            )
        }
        composable("restore/{id}", arguments = idArg) { entry ->
            RestoreScreen(
                vm, entry.arguments?.getString("id") ?: "",
                onBack = { nav.popBackStack() },
                onJob = { nav.navigate("progress") },
                onBrowseDest = { nav.navigate("browse/dest") },
                onPermission = { nav.navigate("permission") },
            )
        }
        composable("settings") {
            SettingsScreen(
                vm, onBack = { nav.popBackStack() }, onBackups = { nav.navigate("backups") },
                onPermission = { nav.navigate("permission") },
                onShizuku = { nav.navigate("shizuku") },
            )
        }
        composable("compat") { CompatScreen(compat, onBack = { nav.popBackStack() }) }
        composable("hub") {
            HubScreen(
                onBack = { nav.popBackStack() },
                onWorlds = { nav.navigate("worlds/$it") },
                onMods = { nav.navigate("mods/$it") },
                onRestoreWorlds = { nav.navigate("restoreall/world") },
                onRestoreMods = { nav.navigate("restoreall/mod") },
                onLog = { nav.navigate("importlog") },
            )
        }
        composable("worlds/{auto}", arguments = listOf(navArgument("auto") { type = NavType.IntType })) { entry ->
            WorldsScreen(
                vm, mgr, entry.arguments?.getInt("auto") ?: 0,
                onBack = { nav.popBackStack() }, onJob = { nav.navigate("progress") },
                onAddSource = { nav.navigate("select") }, onShizuku = { nav.navigate("shizuku") },
            )
        }
        composable("mods/{auto}", arguments = listOf(navArgument("auto") { type = NavType.IntType })) { entry ->
            ModsScreen(
                vm, mgr, entry.arguments?.getInt("auto") ?: 0,
                onBack = { nav.popBackStack() }, onJob = { nav.navigate("progress") },
                onAddSource = { nav.navigate("select") }, onShizuku = { nav.navigate("shizuku") },
            )
        }
        composable("restoreall/{kind}", arguments = listOf(navArgument("kind") { type = NavType.StringType })) { entry ->
            RestoreAllScreen(
                vm, mgr,
                if (entry.arguments?.getString("kind") == "world") com.herotoner.herobackup.core.ImportKind.WORLD else com.herotoner.herobackup.core.ImportKind.MOD,
                onBack = { nav.popBackStack() }, onLog = { nav.navigate("importlog") },
            )
        }
        composable("importlog") { ImportLogScreen(mgr, onBack = { nav.popBackStack() }) }
        composable("shizuku") {
            ShizukuScreen(vm, onBack = { nav.popBackStack() })
        }
        composable("permission") {
            PermissionScreen(vm, onBack = { nav.popBackStack() }, onBrowse = { nav.navigate("browse/source") })
        }
        composable("browse/{mode}", arguments = listOf(navArgument("mode") { type = NavType.StringType })) { entry ->
            BrowseScreen(
                vm, entry.arguments?.getString("mode") ?: "source",
                onBack = { nav.popBackStack() },
                onPermission = { nav.navigate("permission") },
            )
        }
    }
}
