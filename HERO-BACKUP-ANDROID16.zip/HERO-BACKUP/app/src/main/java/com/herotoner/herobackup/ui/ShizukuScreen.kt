package com.herotoner.herobackup.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.shizuku.MinecraftProbe
import com.herotoner.herobackup.shizuku.ProbeLine
import com.herotoner.herobackup.shizuku.ShizukuHelper
import com.herotoner.herobackup.shizuku.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ShizukuScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val status by ShizukuHelper.status.collectAsStateWithLifecycle()
    val uid by ShizukuHelper.serviceUid.collectAsStateWithLifecycle()
    var busy by remember { mutableStateOf(false) }
    var lines by remember { mutableStateOf<List<ProbeLine>>(emptyList()) }
    var testLines by remember { mutableStateOf<List<ProbeLine>>(emptyList()) }
    var working by remember { mutableStateOf<String?>(null) }
    var folders by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    LaunchedEffect(Unit) { ShizukuHelper.refresh() }

    fun runCheck(thenTest: Boolean) {
        scope.launch {
            busy = true
            testLines = emptyList()
            val svc = ShizukuHelper.awaitService(10_000)
            if (svc == null) {
                lines = listOf(ProbeLine("", false, ctx.getString(R.string.shz_no_service)))
            } else {
                val r = withContext(Dispatchers.IO) { MinecraftProbe.check(ctx, svc) }
                lines = r.lines
                working = r.workingPath
                folders = r.folders
                val w = r.workingPath
                if (thenTest && w != null) {
                    testLines = withContext(Dispatchers.IO) { MinecraftProbe.selfTest(ctx, svc, w) }
                }
            }
            busy = false
        }
    }

    ScreenScaffold(stringResource(R.string.title_shizuku), onBack) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroCard {
                    Icon(
                        if (status == ShizukuStatus.CONNECTED) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (status == ShizukuStatus.CONNECTED) HeroColors.Primary else HeroColors.Warning,
                    )
                    Text(
                        stringResource(shizukuStatusRes(status)),
                        color = HeroColors.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    )
                    if (status == ShizukuStatus.CONNECTED && uid >= 0) {
                        Muted(
                            stringResource(
                                when (uid) {
                                    0 -> R.string.shz_mode_root
                                    2000 -> R.string.shz_mode_shell
                                    else -> R.string.shz_mode_other
                                },
                                uid,
                            )
                        )
                    }
                }
            }
            item { InfoBanner(stringResource(R.string.shz_explain)) }
            item { InfoBanner(stringResource(R.string.shz_not_guaranteed), warning = true) }

            when (status) {
                ShizukuStatus.NOT_INSTALLED -> {
                    item { BigButton(stringResource(R.string.shz_download), { ShizukuHelper.openDownloadPage(ctx) }) }
                }
                ShizukuStatus.NOT_RUNNING -> {
                    item { InfoBanner(stringResource(R.string.shz_start_hint)) }
                    item { BigButton(stringResource(R.string.shz_open_app), { ShizukuHelper.openShizukuApp(ctx) }) }
                }
                ShizukuStatus.NEEDS_PERMISSION -> {
                    item { BigButton(stringResource(R.string.shz_request), { ShizukuHelper.requestPermission() }) }
                }
                ShizukuStatus.DENIED -> {
                    item { InfoBanner(stringResource(R.string.shz_denied_hint), warning = true) }
                    item { BigButton(stringResource(R.string.shz_open_app), { ShizukuHelper.openShizukuApp(ctx) }) }
                }
                ShizukuStatus.CONNECTED -> {
                    item {
                        BigButton(
                            stringResource(R.string.shz_check_minecraft), { runCheck(false) },
                            enabled = !busy,
                        )
                    }
                    item {
                        BigButton(
                            stringResource(R.string.shz_run_test), { runCheck(true) },
                            primary = false, enabled = !busy,
                        )
                    }
                }
            }
            item {
                BigButton(
                    stringResource(R.string.shz_recheck), { ShizukuHelper.refresh() },
                    icon = Icons.Filled.Refresh, primary = false,
                )
            }
            if (busy) item { Muted(stringResource(R.string.shz_working)) }

            if (lines.isNotEmpty()) {
                item { SectionTitle(stringResource(R.string.shz_results)) }
                item { ProbeCard(lines) }
            }
            val w = working
            if (w != null && folders.isNotEmpty()) {
                item { SectionTitle(stringResource(R.string.shz_folders)) }
                item {
                    HeroCard {
                        folders.forEach { (name, count) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(name, color = HeroColors.Text, fontSize = 14.sp)
                                    Muted(count)
                                }
                                TextButton(onClick = { vm.addShizukuPath(w + "/" + name, name) }) {
                                    Text(stringResource(R.string.shz_add_source), color = HeroColors.Primary)
                                }
                            }
                        }
                    }
                }
            }
            if (w != null) {
                item {
                    BigButton(
                        stringResource(R.string.shz_add_all), { vm.addShizukuPath(w, "com.mojang") },
                        iconRes = R.drawable.ic_folder, primary = false,
                    )
                }
            }
            if (testLines.isNotEmpty()) {
                item { SectionTitle(stringResource(R.string.shz_test_results)) }
                item { ProbeCard(testLines) }
            }
        }
    }
}

@Composable
private fun ProbeCard(lines: List<ProbeLine>) {
    HeroCard {
        lines.forEach {
            Column {
                if (it.path.isNotBlank()) {
                    Text(it.path, color = HeroColors.TextSecondary, fontSize = 11.sp)
                }
                Text(
                    (if (it.ok) "✔ " else "✘ ") + it.detail,
                    color = if (it.ok) HeroColors.Primary else HeroColors.Danger,
                    fontSize = 13.sp,
                )
            }
        }
    }
}
