package com.herotoner.herobackup.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.Confidence
import com.herotoner.herobackup.core.FailureEntry
import com.herotoner.herobackup.core.ImportKind
import com.herotoner.herobackup.core.ImportStatus
import com.herotoner.herobackup.core.PackInfo
import com.herotoner.herobackup.core.Versions

private fun statusRes(s: ImportStatus) = when (s) {
    ImportStatus.PENDING -> R.string.st_pending
    ImportStatus.READY -> R.string.st_ready
    ImportStatus.OPENED -> R.string.st_opened
    ImportStatus.VERIFIED -> R.string.st_verified
    ImportStatus.NEEDS_CONFIRM -> R.string.st_needs_confirm
    ImportStatus.CONFIRMED -> R.string.st_confirmed
    ImportStatus.FAILED -> R.string.st_failed
    ImportStatus.SKIPPED -> R.string.st_skipped
}

@Composable
private fun statusColor(s: ImportStatus) = when (s) {
    ImportStatus.VERIFIED, ImportStatus.CONFIRMED -> HeroColors.Primary
    ImportStatus.FAILED -> HeroColors.Danger
    ImportStatus.NEEDS_CONFIRM, ImportStatus.OPENED -> HeroColors.Warning
    else -> HeroColors.TextSecondary
}

@Composable
private fun CheckRow(checked: Boolean, onChecked: (Boolean) -> Unit, title: String, lines: List<Pair<String, Boolean>>) {
    Row(verticalAlignment = Alignment.Top) {
        Checkbox(
            checked = checked, onCheckedChange = onChecked,
            colors = CheckboxDefaults.colors(checkedColor = HeroColors.Primary, checkmarkColor = HeroColors.OnPrimary),
        )
        Column(Modifier.weight(1f).padding(top = 12.dp)) {
            Text(title, color = HeroColors.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            lines.forEach { (t, warn) ->
                Text(t, color = if (warn) HeroColors.Warning else HeroColors.TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun DiscoverCard(mgr: ManagerViewModel) {
    val ui by mgr.discover.collectAsStateWithLifecycle()
    val r = ui.result
    if (ui.running) {
        HeroCard { Text(stringResource(R.string.disc_running), color = HeroColors.Text); LinearProgressIndicator(Modifier.fillMaxWidth(), color = HeroColors.Primary, trackColor = HeroColors.Bg) }
    }
    if (r != null) {
        HeroCard {
            SectionTitle(stringResource(R.string.disc_title))
            ui.noteRes?.let { Text(stringResource(it), color = HeroColors.Primary, fontWeight = FontWeight.Bold) }
            r.attempts.forEach { a ->
                Text(
                    methodLabel(a.method) + if (a.label.isNotBlank()) " — " + a.label else "",
                    color = HeroColors.Text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    attemptLabel(a.result) + if (a.detail.isNotBlank()) ": " + a.detail else "",
                    color = if (a.result == com.herotoner.herobackup.core.AttemptResult.FOUND) HeroColors.Primary else HeroColors.Warning,
                    fontSize = 12.sp,
                )
            }
            if (r.useOfficial) Text(stringResource(R.string.disc_official), color = HeroColors.Text, fontSize = 13.sp)
        }
    }
}

@Composable
private fun FailuresCard(items: List<FailureEntry>) {
    HeroCard { SectionTitle(stringResource(R.string.mgr_inaccessible)); FailureList(items) }
}

// ====================== المركز ======================
@Composable
fun HubScreen(
    onBack: () -> Unit, onWorlds: (Int) -> Unit, onMods: (Int) -> Unit,
    onRestoreWorlds: () -> Unit, onRestoreMods: () -> Unit, onLog: () -> Unit,
) {
    ScreenScaffold(stringResource(R.string.title_hub), onBack) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { InfoBanner(stringResource(R.string.hub_intro)) }
            item { BigButton(stringResource(R.string.hub_find_worlds), { onWorlds(1) }, iconRes = R.drawable.ic_folder) }
            item { BigButton(stringResource(R.string.hub_convert_worlds), { onWorlds(2) }, iconRes = R.drawable.ic_export, primary = false) }
            item { BigButton(stringResource(R.string.hub_find_mods), { onMods(1) }, iconRes = R.drawable.ic_folder) }
            item { BigButton(stringResource(R.string.hub_merge_mods), { onMods(2) }, iconRes = R.drawable.ic_export, primary = false) }
            item { BigButton(stringResource(R.string.hub_restore_worlds), onRestoreWorlds, iconRes = R.drawable.ic_restore) }
            item { BigButton(stringResource(R.string.hub_restore_mods), onRestoreMods, iconRes = R.drawable.ic_restore) }
            item { BigButton(stringResource(R.string.hub_log), onLog, primary = false) }
        }
    }
}

// ====================== العوالم ======================
@Composable
fun WorldsScreen(
    vm: MainViewModel, mgr: ManagerViewModel, auto: Int,
    onBack: () -> Unit, onJob: () -> Unit, onAddSource: () -> Unit, onShizuku: () -> Unit,
) {
    val ctx = LocalContext.current
    val scan by mgr.worldScan.collectAsStateWithLifecycle()
    val sel by mgr.selectedWorlds.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    val convName = stringResource(R.string.conv_worlds_name, formatDate(System.currentTimeMillis()))
    var pendingAll by remember { mutableStateOf(auto == 2) }
    var info by remember { mutableStateOf<String?>(null) }
    val res = scan.result

    LaunchedEffect(Unit) { if (auto >= 1) mgr.scanWorlds() }
    LaunchedEffect(scan.done, pendingAll) {
        if (pendingAll && scan.done) {
            pendingAll = false
            val ws = res?.worlds ?: emptyList()
            if (ws.isNotEmpty() && vm.startConvert("worlds", ws.map { it.key }, convName)) onJob()
        }
    }

    ScreenScaffold(stringResource(R.string.title_worlds), onBack) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { InfoBanner(stringResource(R.string.worlds_intro)) }
            item { DiscoverCard(mgr) }
            item {
                BigButton(
                    stringResource(R.string.search_worlds), { mgr.scanWorlds() },
                    icon = Icons.Filled.Refresh, enabled = !scan.running,
                )
            }
            info?.let { t -> item { InfoBanner(t, warning = true) } }
            if (scan.running) {
                item {
                    HeroCard {
                        Text(stringResource(R.string.scanning_worlds), color = HeroColors.Text)
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = HeroColors.Primary, trackColor = HeroColors.Bg)
                        if (scan.current.isNotBlank()) Muted(scan.current)
                        TextButton(onClick = { mgr.cancelScan() }) { Text(stringResource(R.string.cancel), color = HeroColors.Danger) }
                    }
                }
            }
            if (scan.done && scan.sourceCount == 0) {
                item { InfoBanner(stringResource(R.string.mgr_no_sources), warning = true) }
                item { BigButton(stringResource(R.string.mgr_add_source), onAddSource, iconRes = R.drawable.ic_folder) }
                item {
                    BigButton(
                        stringResource(R.string.mgr_auto_discover),
                        { mgr.autoDiscover { mgr.scanWorlds() } },
                        iconRes = R.drawable.ic_folder, primary = false,
                    )
                }
                item { BigButton(stringResource(R.string.shz_open_page), onShizuku, primary = false) }
            }
            if (res != null) {
                item {
                    HeroCard {
                        Text(stringResource(R.string.worlds_found, res.worlds.size), color = HeroColors.Primary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (res.truncated) Text(stringResource(R.string.scan_truncated), color = HeroColors.Warning, fontSize = 12.sp)
                        Row {
                            TextButton(onClick = { mgr.setAllWorlds(true) }) { Text(stringResource(R.string.select_all), color = HeroColors.Primary) }
                            TextButton(onClick = { mgr.setAllWorlds(false) }) { Text(stringResource(R.string.select_none), color = HeroColors.Primary) }
                        }
                    }
                }
                items(res.worlds, key = { it.key }) { w ->
                    HeroCard {
                        CheckRow(
                            w.key in sel, { mgr.toggleWorld(w.key, it) }, w.name,
                            listOf(
                                stringResource(R.string.world_line1, formatBytes(ctx, w.sizeBytes), w.fileCount) to false,
                                (if (w.lastModified > 0) formatDate(w.lastModified) else "—") to false,
                                w.key to false,
                            ),
                        )
                    }
                }
                if (res.incomplete.isNotEmpty()) {
                    item {
                        HeroCard {
                            SectionTitle(stringResource(R.string.worlds_incomplete))
                            res.incomplete.take(30).forEach {
                                Text(it.path, color = HeroColors.Text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(it.reason, color = HeroColors.Warning, fontSize = 12.sp)
                            }
                        }
                    }
                }
                if (res.failures.isNotEmpty()) item { FailuresCard(res.failures) }
                if (res.worlds.isNotEmpty()) {
                    item {
                        BigButton(
                            stringResource(R.string.convert_selected_worlds, sel.size),
                            { if (vm.startConvert("worlds", sel, convName)) onJob() },
                            icon = Icons.Filled.PlayArrow, enabled = sel.isNotEmpty() && job?.active != true,
                        )
                    }
                    item {
                        BigButton(
                            stringResource(R.string.convert_all_worlds),
                            { if (vm.startConvert("worlds", res.worlds.map { it.key }, convName)) onJob() },
                            primary = false, enabled = job?.active != true,
                        )
                    }
                    item { InfoBanner(stringResource(R.string.convert_note)) }
                }
            }
        }
    }
}

// ====================== المودات ======================
private fun packLine(p: PackInfo): String {
    val m = p.manifest
    return if (m == null) p.key else p.folderName + " • v" + Versions.text(m.version)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModsScreen(
    vm: MainViewModel, mgr: ManagerViewModel, auto: Int,
    onBack: () -> Unit, onJob: () -> Unit, onAddSource: () -> Unit, onShizuku: () -> Unit,
) {
    val ctx = LocalContext.current
    val scan by mgr.modScan.collectAsStateWithLifecycle()
    val sel by mgr.selectedMods.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    val convName = stringResource(R.string.conv_mods_name, formatDate(System.currentTimeMillis()))
    var pendingAll by remember { mutableStateOf(auto == 2) }
    var tab by remember { mutableStateOf(0) }
    var info by remember { mutableStateOf<String?>(null) }
    val match = scan.match

    LaunchedEffect(Unit) { if (auto >= 1) mgr.scanMods() }
    LaunchedEffect(scan.done, pendingAll) {
        if (pendingAll && scan.done) {
            pendingAll = false
            val pairs = match?.pairs ?: emptyList()
            if (pairs.isNotEmpty() && vm.startConvert("mods", pairs.map { "pair:" + it.key }, convName)) onJob()
        }
    }

    ScreenScaffold(stringResource(R.string.title_mods), onBack) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { InfoBanner(stringResource(R.string.mods_intro)) }
            item { DiscoverCard(mgr) }
            item {
                BigButton(stringResource(R.string.search_mods), { mgr.scanMods() }, icon = Icons.Filled.Refresh, enabled = !scan.running)
            }
            info?.let { t -> item { InfoBanner(t, warning = true) } }
            if (scan.running) {
                item {
                    HeroCard {
                        Text(stringResource(R.string.scanning_mods), color = HeroColors.Text)
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = HeroColors.Primary, trackColor = HeroColors.Bg)
                        TextButton(onClick = { mgr.cancelScan() }) { Text(stringResource(R.string.cancel), color = HeroColors.Danger) }
                    }
                }
            }
            if (scan.done && scan.sourceCount == 0) {
                item { InfoBanner(stringResource(R.string.mgr_no_sources), warning = true) }
                item { BigButton(stringResource(R.string.mgr_add_source), onAddSource, iconRes = R.drawable.ic_folder) }
                item {
                    BigButton(
                        stringResource(R.string.mgr_auto_discover),
                        { mgr.autoDiscover { mgr.scanMods() } },
                        iconRes = R.drawable.ic_folder, primary = false,
                    )
                }
                item { BigButton(stringResource(R.string.shz_open_page), onShizuku, primary = false) }
            }
            if (match != null) {
                val allPacks = scan.scan?.packs ?: emptyList()
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            R.string.tab_pairs to match.pairs.size, R.string.tab_rp_only to match.rpOnly.size,
                            R.string.tab_bp_only to match.bpOnly.size, R.string.tab_unmatched to match.unmatched.size,
                            R.string.tab_other to match.others.size,
                        ).forEachIndexed { i, (label, n) ->
                            FilterChip(
                                selected = tab == i, onClick = { tab = i },
                                label = { Text(stringResource(label) + " (" + n + ")") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = HeroColors.Primary, selectedLabelColor = HeroColors.OnPrimary,
                                    containerColor = HeroColors.Card, labelColor = HeroColors.Text,
                                ),
                            )
                        }
                    }
                }
                when (tab) {
                    0 -> {
                        if (match.pairs.isEmpty()) item { Muted(stringResource(R.string.none_found)) }
                        items(match.pairs, key = { "pair:" + it.key }) { p ->
                            HeroCard {
                                CheckRow(
                                    ("pair:" + p.key) in sel, { mgr.toggleMod("pair:" + p.key, it) }, p.base,
                                    listOf(
                                        "RP: " + packLine(p.rp) to false, "BP: " + packLine(p.bp) to false,
                                        stringResource(
                                            when (p.confidence) {
                                                Confidence.NAME_AND_DEPENDENCY -> R.string.conf_both
                                                Confidence.DEPENDENCY -> R.string.conf_dep
                                                Confidence.NAME_ONLY -> R.string.conf_name
                                            }
                                        ) to (p.confidence != Confidence.NAME_AND_DEPENDENCY),
                                    ) + p.warnings.map { it to true },
                                )
                            }
                        }
                        if (match.pairs.isNotEmpty()) {
                            item {
                                BigButton(
                                    stringResource(R.string.merge_selected), {
                                        if (vm.startConvert("mods", sel, convName)) onJob()
                                    },
                                    icon = Icons.Filled.PlayArrow, enabled = sel.isNotEmpty() && job?.active != true,
                                )
                            }
                            item {
                                BigButton(
                                    stringResource(R.string.merge_all),
                                    { if (vm.startConvert("mods", match.pairs.map { "pair:" + it.key }, convName)) onJob() },
                                    primary = false, enabled = job?.active != true,
                                )
                            }
                        }
                    }
                    1, 2, 4 -> {
                        val list = when (tab) { 1 -> match.rpOnly; 2 -> match.bpOnly; else -> match.others }
                        if (list.isEmpty()) item { Muted(stringResource(R.string.none_found)) }
                        items(list, key = { "pack:" + it.key }) { p ->
                            HeroCard {
                                val miss = com.herotoner.herobackup.core.PackMatcher.missingDependencyWarning(p, allPacks)
                                CheckRow(
                                    ("pack:" + p.key) in sel, { mgr.toggleMod("pack:" + p.key, it) }, p.folderName,
                                    listOfNotNull(
                                        p.manifest?.let { it.name + " • v" + Versions.text(it.version) }?.let { it to false },
                                        (formatBytes(ctx, p.sizeBytes) + " • " + p.fileCount) to false,
                                        p.key to false,
                                        miss?.let { it to true },
                                    ) + p.warnings.map { it to true },
                                )
                            }
                        }
                        if (list.isNotEmpty()) {
                            item {
                                BigButton(
                                    stringResource(R.string.convert_packs),
                                    { if (vm.startConvert("mods", sel, convName)) onJob() },
                                    icon = Icons.Filled.PlayArrow, enabled = sel.any { it.startsWith("pack:") } && job?.active != true,
                                )
                            }
                        }
                    }
                    3 -> {
                        if (match.unmatched.isEmpty()) item { Muted(stringResource(R.string.none_found)) }
                        items(match.unmatched, key = { "u:" + it.pack.key }) { u ->
                            HeroCard {
                                Text(u.pack.key, color = HeroColors.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(u.reason, color = HeroColors.Warning, fontSize = 12.sp)
                            }
                        }
                    }
                }
                val sf = scan.scan?.failures ?: emptyList()
                if (sf.isNotEmpty()) item { FailuresCard(sf) }
                item { InfoBanner(stringResource(R.string.mods_structure_note)) }
            }
        }
    }
}

// ====================== استعادة العوالم / المودات ======================
@Composable
fun RestoreAllScreen(vm: MainViewModel, mgr: ManagerViewModel, kind: ImportKind, onBack: () -> Unit, onLog: () -> Unit) {
    val backups by vm.backups.collectAsStateWithLifecycle()
    val ui by mgr.importUi.collectAsStateWithLifecycle()
    var confirmStop by remember { mutableStateOf(false) }
    val title = if (kind == ImportKind.WORLD) R.string.title_restore_worlds else R.string.title_restore_mods

    LaunchedEffect(kind) { mgr.resetImport(); vm.refreshBackups() }

    ScreenScaffold(stringResource(title), { mgr.resetImport(); onBack() }) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                InfoBanner(
                    stringResource(if (kind == ImportKind.WORLD) R.string.restore_worlds_intro else R.string.restore_mods_intro)
                )
            }
            if (ui.phase == ImportPhase.IDLE) {
                item { SectionTitle(stringResource(R.string.pick_backup)) }
                if (ui.emptyNote) item { InfoBanner(stringResource(R.string.backup_no_items), warning = true) }
                if (backups.isEmpty()) item { Muted(stringResource(R.string.no_backups)) }
                items(backups, key = { it.id }) { b ->
                    HeroCard {
                        Text(b.name, color = HeroColors.Text, fontWeight = FontWeight.Bold)
                        Muted(formatDate(b.createdAt))
                        BigButton(
                            stringResource(R.string.use_this_backup), { mgr.prepareImport(b.id, kind) },
                            primary = false,
                        )
                    }
                }
            } else {
                item {
                    HeroCard {
                        Text(ui.backupName, color = HeroColors.Text, fontWeight = FontWeight.Bold)
                        if (ui.phase == ImportPhase.PREPARING) {
                            Muted(stringResource(R.string.verifying_files, ui.progress.first, ui.progress.second))
                            LinearProgressIndicator(Modifier.fillMaxWidth(), color = HeroColors.Primary, trackColor = HeroColors.Bg)
                        }
                        val ready = ui.rows.count { it.status == ImportStatus.READY }
                        val failed = ui.rows.count { it.status == ImportStatus.FAILED }
                        Muted(stringResource(R.string.import_counts, ui.rows.size, ready, failed))
                    }
                }
                if (ui.phase == ImportPhase.READY) {
                    item {
                        BigButton(
                            stringResource(R.string.start_import), { mgr.startImport() },
                            icon = Icons.Filled.PlayArrow, enabled = ui.rows.any { it.status == ImportStatus.READY },
                        )
                    }
                    item { InfoBanner(stringResource(R.string.import_how)) }
                }
                if (ui.phase == ImportPhase.RUNNING) {
                    item { InfoBanner(stringResource(R.string.import_running_note), warning = true) }
                    item { BigButton(stringResource(R.string.stop_import), { confirmStop = true }, primary = false, danger = true) }
                }
                items(ui.rows, key = { it.id }) { r ->
                    HeroCard {
                        Text(r.name, color = HeroColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(stringResource(statusRes(r.status)), color = statusColor(r.status), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (r.detail.isNotBlank()) Muted(r.detail)
                        if (r.status == ImportStatus.NEEDS_CONFIRM) {
                            TextButton(onClick = { mgr.confirmImport(r.id) }) {
                                Text(stringResource(R.string.confirm_imported), color = HeroColors.Primary)
                            }
                        }
                    }
                }
                if (ui.phase == ImportPhase.DONE) {
                    item { BigButton(stringResource(R.string.open_log), onLog, primary = false) }
                    item { BigButton(stringResource(R.string.back), { mgr.resetImport() }, primary = false) }
                }
            }
        }
    }
    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            title = { Text(stringResource(R.string.stop_import)) },
            text = { Text(stringResource(R.string.stop_import_text)) },
            confirmButton = { TextButton(onClick = { confirmStop = false; mgr.stopImport() }) { Text(stringResource(R.string.yes_cancel), color = HeroColors.Danger) } },
            dismissButton = { TextButton(onClick = { confirmStop = false }) { Text(stringResource(R.string.continue_op)) } },
            containerColor = HeroColors.Card, titleContentColor = HeroColors.Text, textContentColor = HeroColors.TextSecondary,
        )
    }
}

// ====================== السجل ======================
@Composable
fun ImportLogScreen(mgr: ManagerViewModel, onBack: () -> Unit) {
    val entries by mgr.logEntries.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { mgr.refreshLog() }
    ScreenScaffold(stringResource(R.string.title_import_log), onBack) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (entries.isEmpty()) item { Muted(stringResource(R.string.log_empty)) }
            items(entries.size) { i ->
                val e = entries[i]
                val st = runCatching { ImportStatus.valueOf(e.status) }.getOrDefault(ImportStatus.PENDING)
                HeroCard {
                    Text(e.item, color = HeroColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(stringResource(statusRes(st)), color = statusColor(st), fontSize = 13.sp)
                    if (e.detail.isNotBlank()) Muted(e.detail)
                    Muted(formatDate(e.time) + " • " + e.source)
                }
            }
            if (entries.isNotEmpty()) {
                item { BigButton(stringResource(R.string.log_clear), { confirm = true }, primary = false, danger = true) }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.log_clear)) },
            text = { Text(stringResource(R.string.log_clear_text)) },
            confirmButton = { TextButton(onClick = { confirm = false; mgr.clearLog() }) { Text(stringResource(R.string.delete), color = HeroColors.Danger) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } },
            containerColor = HeroColors.Card, titleContentColor = HeroColors.Text, textContentColor = HeroColors.TextSecondary,
        )
    }
}
