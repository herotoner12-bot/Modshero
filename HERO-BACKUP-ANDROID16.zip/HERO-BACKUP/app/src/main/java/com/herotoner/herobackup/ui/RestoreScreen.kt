package com.herotoner.herobackup.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.FileKinds
import com.herotoner.herobackup.core.Manifest
import com.herotoner.herobackup.core.OverwritePolicy
import com.herotoner.herobackup.data.PickTree

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RestoreScreen(vm: MainViewModel, id: String, onBack: () -> Unit, onJob: () -> Unit, onBrowseDest: () -> Unit, onPermission: () -> Unit) {
    val loaded by produceState<Pair<Boolean, Manifest?>>(false to null, id) { value = true to vm.manifest(id) }
    val job by vm.job.collectAsStateWithLifecycle()
    val allFiles by vm.allFiles.collectAsStateWithLifecycle()
    val picked by vm.pickedDest.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showFiles by rememberSaveable { mutableStateOf(false) }
    var dest by rememberSaveable { mutableStateOf<String?>(null) }
    var policyName by rememberSaveable { mutableStateOf(OverwritePolicy.SKIP.name) }
    var confirm by remember { mutableStateOf(false) }
    val policy = OverwritePolicy.valueOf(policyName)

    val pickDest = rememberLauncherForActivityResult(PickTree()) { uri -> if (uri != null) dest = uri.toString() }
    val m = loaded.second
    LaunchedEffect(picked) { picked?.let { dest = it; vm.pickedDest.value = null } }
    LaunchedEffect(m?.id) { if (m != null) selected = m.files.map { it.path }.toSet() }

    ScreenScaffold(stringResource(R.string.title_restore), onBack) { inner ->
        if (m == null) {
            LazyColumn(Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp)) {
                item { Muted(stringResource(if (loaded.first) R.string.backup_not_found else R.string.loading)) }
            }
            return@ScreenScaffold
        }
        val byKind = m.files.groupBy { FileKinds.of(it.path) }
        val chosen = m.files.filter { it.path in selected }
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroCard {
                    Text(m.name, color = HeroColors.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Muted(formatDate(m.createdAt))
                }
            }
            item { InfoBanner(stringResource(R.string.restore_import_hint)) }
            item { SectionTitle(stringResource(R.string.restore_types)) }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    byKind.entries.sortedBy { it.key.ordinal }.forEach { (kind, files) ->
                        val all = files.all { it.path in selected }
                        FilterChip(
                            selected = all,
                            onClick = {
                                val paths = files.map { it.path }
                                selected = if (all) selected - paths.toSet() else selected + paths
                            },
                            label = { Text(stringResource(kindLabel(kind)) + " (" + files.size + ")") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = HeroColors.Primary,
                                selectedLabelColor = HeroColors.OnPrimary,
                                containerColor = HeroColors.Card,
                                labelColor = HeroColors.Text,
                            ),
                        )
                    }
                }
            }
            item { SectionTitle(stringResource(R.string.restore_dest)) }
            item {
                HeroCard {
                    Text(
                        dest?.let { if (it.startsWith("file:")) (Uri.parse(it).path ?: it) else Uri.decode(Uri.parse(it).lastPathSegment ?: it) } ?: stringResource(R.string.dest_none),
                        color = if (dest == null) HeroColors.TextSecondary else HeroColors.Primary,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                    BigButton(stringResource(R.string.pick_dest), { pickDest.launch(true) }, iconRes = R.drawable.ic_folder, primary = false)
                    BigButton(
                        stringResource(if (allFiles) R.string.pick_dest_browse else R.string.enable_all_files),
                        { if (allFiles) onBrowseDest() else onPermission() },
                        iconRes = R.drawable.ic_folder, primary = false,
                    )
                }
            }
            item { SectionTitle(stringResource(R.string.restore_policy)) }
            item {
                HeroCard {
                    listOf(
                        OverwritePolicy.SKIP to R.string.policy_skip,
                        OverwritePolicy.RENAME to R.string.policy_rename,
                        OverwritePolicy.OVERWRITE to R.string.policy_overwrite,
                    ).forEach { (p, label) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { policyName = p.name },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = policy == p, onClick = { policyName = p.name },
                                colors = RadioButtonDefaults.colors(selectedColor = HeroColors.Primary),
                            )
                            Text(
                                stringResource(label),
                                color = if (p == OverwritePolicy.OVERWRITE) HeroColors.Warning else HeroColors.Text,
                                fontSize = 15.sp,
                            )
                        }
                    }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().clickable { showFiles = !showFiles },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        stringResource(if (showFiles) R.string.hide_files else R.string.show_files, chosen.size, m.files.size),
                        color = HeroColors.Primary, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            if (showFiles) {
                items(m.files.size) { i ->
                    val f = m.files[i]
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = f.path in selected,
                            onCheckedChange = { c -> selected = if (c) selected + f.path else selected - f.path },
                            colors = CheckboxDefaults.colors(checkedColor = HeroColors.Primary, checkmarkColor = HeroColors.OnPrimary),
                        )
                        Text(f.path, color = HeroColors.Text, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            item {
                BigButton(
                    stringResource(R.string.start_restore), { confirm = true },
                    icon = Icons.Filled.Check,
                    enabled = dest != null && chosen.isNotEmpty() && job?.active != true,
                )
            }
        }
        if (confirm) {
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text(stringResource(R.string.restore_confirm_title)) },
                text = {
                    Text(
                        stringResource(R.string.restore_confirm_text, chosen.size, stringResource(
                            when (policy) {
                                OverwritePolicy.SKIP -> R.string.policy_skip
                                OverwritePolicy.RENAME -> R.string.policy_rename
                                OverwritePolicy.OVERWRITE -> R.string.policy_overwrite
                            }
                        )) + if (policy == OverwritePolicy.OVERWRITE) "\n\n" + stringResource(R.string.restore_overwrite_warning) else ""
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        confirm = false
                        val d = dest
                        if (d != null && vm.startRestore(id, Uri.parse(d), policy, chosen)) onJob()
                    }) { Text(stringResource(R.string.confirm_restore), color = HeroColors.Primary) }
                },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } },
                containerColor = HeroColors.Card,
                titleContentColor = HeroColors.Text,
                textContentColor = HeroColors.TextSecondary,
            )
        }
    }
}
