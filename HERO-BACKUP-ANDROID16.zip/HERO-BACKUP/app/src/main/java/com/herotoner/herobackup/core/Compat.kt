package com.herotoner.herobackup.core

import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

/** معلومات إصدارات Android المدعومة (الحد الأدنى الفعلي 26 = Android 8.0). */
object ApiSupport {
    const val MIN_SDK = 26

    fun androidName(sdk: Int): String = when (sdk) {
        26 -> "Android 8.0"; 27 -> "Android 8.1"; 28 -> "Android 9"; 29 -> "Android 10"
        30 -> "Android 11"; 31 -> "Android 12"; 32 -> "Android 12L"; 33 -> "Android 13"
        34 -> "Android 14"; 35 -> "Android 15"; 36 -> "Android 16"
        else -> if (sdk > 36) "Android (API $sdk)" else "Android (API $sdk)"
    }

    fun supported(sdk: Int) = sdk >= MIN_SDK

    /** صلاحية التخزين المباشر: تقليدية حتى 28، غير متاحة 29، «جميع الملفات» من 30. */
    fun directFilesKind(sdk: Int): DirectFilesKind = when {
        sdk <= 28 -> DirectFilesKind.LEGACY_PERMISSION
        sdk == 29 -> DirectFilesKind.NONE
        else -> DirectFilesKind.ALL_FILES
    }

    /** هل يُتوقع أن يسمح SAF باختيار Android/data؟ (الحظر بدأ من Android 11). */
    fun safMayReachAndroidData(sdk: Int) = sdk <= 29
}

enum class DirectFilesKind { LEGACY_PERMISSION, NONE, ALL_FILES }

enum class OemFamily { XIAOMI, SAMSUNG, OPPO, GOOGLE, MOTOROLA, TRANSSION, OTHER }

object Oem {
    fun detect(manufacturer: String?, brand: String?): OemFamily {
        val t = ((manufacturer ?: "") + " " + (brand ?: "")).lowercase()
        return when {
            listOf("xiaomi", "redmi", "poco", "blackshark").any { t.contains(it) } -> OemFamily.XIAOMI
            t.contains("samsung") -> OemFamily.SAMSUNG
            listOf("oppo", "realme", "oneplus").any { t.contains(it) } -> OemFamily.OPPO
            t.contains("google") -> OemFamily.GOOGLE
            t.contains("motorola") -> OemFamily.MOTOROLA
            listOf("tecno", "infinix", "itel", "transsion").any { t.contains(it) } -> OemFamily.TRANSSION
            else -> OemFamily.OTHER
        }
    }
}

object MinecraftPaths {
    val PACKAGES = listOf("com.mojang.minecraftpe", "com.mojang.minecraftpe.preview", "com.mojang.minecraftedu")

    /** جذور التخزين الممكنة. userId يختلف في الملفات الثانية/Dual apps (مثل /storage/emulated/10). */
    fun roots(userId: Int): List<String> =
        (listOf("/storage/emulated/$userId", "/storage/emulated/0", "/sdcard", "/data/media/$userId")).distinct()

    /** لا يُفترض مسار واحد: مسار بيانات التطبيق، ومسار التخزين الخارجي التقليدي (games/com.mojang). */
    fun candidates(packages: List<String>, roots: List<String>): List<String> {
        val out = LinkedHashSet<String>()
        for (r in roots) for (p in packages) out += "$r/Android/data/$p/files/games/com.mojang"
        for (r in roots) out += "$r/games/com.mojang"
        return out.toList()
    }
}

class LayoutInfo(val names: List<String>) {
    val hasWorlds get() = "minecraftWorlds" in names
    val hasResourcePacks get() = "resource_packs" in names || "development_resource_packs" in names
    val hasBehaviorPacks get() = "behavior_packs" in names || "development_behavior_packs" in names
}

object MinecraftLayout {
    private val MARKERS = setOf(
        "minecraftWorlds", "resource_packs", "behavior_packs", "development_resource_packs",
        "development_behavior_packs", "skin_packs",
    )

    fun looksLikeMojang(names: Collection<String>) = names.any { it in MARKERS }
}

enum class AccessMethod { SAF, FILES, SHIZUKU, OFFICIAL }

data class Precheck(val available: Boolean, val ready: Boolean, val reason: String)

/** طريقة وصول: الأندرويد ينفّذ SAF وFILES وSHIZUKU، والـ core ينسّقها ويختبرها بالتبديل عند الفشل. */
interface AccessProvider {
    val method: AccessMethod
    fun precheck(): Precheck

    /** عقد قابلة للفحص: لطرق المسارات تُبنى من المسارات المرشّحة، وSAF يعيد المصادر التي اختارها المستخدم. */
    fun candidates(paths: List<String>): List<Pair<String, SourceNode>>
}

enum class AttemptResult { FOUND, NOT_READY, UNAVAILABLE, DENIED, MISSING, NOT_MINECRAFT, ERROR }

data class Attempt(val method: AccessMethod, val label: String, val result: AttemptResult, val detail: String)
class Found(val method: AccessMethod, val label: String, val node: SourceNode, val layout: LayoutInfo)
class DiscoverResult(val attempts: List<Attempt>, val found: Found?, val useOfficial: Boolean)

object StorageEngine {
    private val ORDER = listOf(AccessMethod.SAF, AccessMethod.FILES, AccessMethod.SHIZUKU)

    /**
     * يجرّب الطرق بالترتيب (SAF ثم جميع الملفات ثم Shizuku). يتوقف عند أول نجاح، وينتقل للتالية عند الفشل.
     * إن فشلت كلها فالبديل الرسمي: الاستيراد/التصدير عبر Minecraft نفسه (useOfficial).
     */
    fun discover(providers: List<AccessProvider>, paths: List<String>, cancel: () -> Boolean = { false }): DiscoverResult {
        val attempts = ArrayList<Attempt>()
        for (m in ORDER) {
            val p = providers.firstOrNull { it.method == m } ?: continue
            if (cancel()) throw OperationCancelled()
            val pre = try { p.precheck() } catch (e: Exception) { Precheck(true, false, e.message ?: "") }
            if (!pre.available) { attempts += Attempt(m, "", AttemptResult.UNAVAILABLE, pre.reason); continue }
            if (!pre.ready) { attempts += Attempt(m, "", AttemptResult.NOT_READY, pre.reason); continue }
            val cands = try { p.candidates(paths) } catch (e: Exception) {
                attempts += Attempt(m, "", AttemptResult.ERROR, e.message ?: ""); continue
            }
            if (cands.isEmpty()) { attempts += Attempt(m, "", AttemptResult.NOT_READY, pre.reason.ifBlank { "لا توجد عناصر للفحص" }); continue }
            for ((label, node) in cands) {
                if (cancel()) throw OperationCancelled()
                try {
                    val names = node.children().map { it.name }
                    if (MinecraftLayout.looksLikeMojang(names)) {
                        attempts += Attempt(m, label, AttemptResult.FOUND, "${names.size} عنصر")
                        return DiscoverResult(attempts, Found(m, label, node, LayoutInfo(names)), false)
                    }
                    attempts += Attempt(m, label, AttemptResult.NOT_MINECRAFT, if (names.isEmpty()) "المجلد فارغ" else "ليس مجلد com.mojang")
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: SecurityException) {
                    attempts += Attempt(m, label, AttemptResult.DENIED, e.message ?: "رفض النظام الوصول")
                } catch (e: FileNotFoundException) {
                    attempts += Attempt(m, label, AttemptResult.MISSING, e.message ?: "المسار غير موجود أو محجوب")
                } catch (e: IOException) {
                    attempts += Attempt(m, label, AttemptResult.ERROR, e.message ?: "")
                } catch (e: Exception) {
                    attempts += Attempt(m, label, AttemptResult.ERROR, e.message ?: e.javaClass.simpleName)
                }
            }
        }
        return DiscoverResult(attempts, null, true)
    }
}

/** طريقة المسارات المباشرة (File): تُستخدم لـ«جميع الملفات» والصلاحية التقليدية. */
class DirectFilesProvider(private val granted: () -> Pair<Boolean, String>, private val available: Boolean = true) : AccessProvider {
    override val method = AccessMethod.FILES
    override fun precheck(): Precheck {
        if (!available) return Precheck(false, false, "غير متاحة على هذا الإصدار من Android")
        val (ok, why) = granted()
        return Precheck(true, ok, why)
    }

    override fun candidates(paths: List<String>): List<Pair<String, SourceNode>> =
        paths.map { it to (FileSourceNode(File(it)) as SourceNode) }
}

enum class CheckStatus { PASS, FAIL, WARN, INFO, SKIP }

data class CheckResult(val group: String, val title: String, val status: CheckStatus, val detail: String)

object CompatReport {
    fun text(appVersion: String, time: String, results: List<CheckResult>): String {
        val sb = StringBuilder()
        sb.append("HERO BACKUP $appVersion — تقرير توافق الجهاز\n")
        sb.append("التاريخ: $time\n")
        var g = ""
        for (r in results) {
            if (r.group != g) { g = r.group; sb.append("\n## $g\n") }
            val tag = when (r.status) {
                CheckStatus.PASS -> "نجح"; CheckStatus.FAIL -> "فشل"; CheckStatus.WARN -> "تحذير"
                CheckStatus.INFO -> "معلومة"; CheckStatus.SKIP -> "لم يُختبر"
            }
            sb.append("[$tag] ${r.title}")
            if (r.detail.isNotBlank()) sb.append(" — ").append(r.detail.replace("\n", " | "))
            sb.append('\n')
        }
        return sb.toString()
    }
}
