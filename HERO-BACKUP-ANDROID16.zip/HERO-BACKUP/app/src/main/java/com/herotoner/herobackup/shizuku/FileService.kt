package com.herotoner.herobackup.shizuku

import android.os.ParcelFileDescriptor
import android.system.ErrnoException
import android.util.Log
import android.system.Os
import android.system.OsConstants
import com.herotoner.herobackup.core.RemoteEntry
import com.herotoner.herobackup.core.RemoteProtocol
import java.io.File
import java.nio.file.AccessDeniedException
import java.nio.file.Files
import java.nio.file.NoSuchFileException
import java.nio.file.NotDirectoryException
import java.nio.file.Paths
import kotlin.system.exitProcess

/**
 * تعمل هذه الخدمة داخل عملية يشغّلها Shizuku (هوية shell أو root)، لا داخل عملية التطبيق.
 * القراءة فقط: stat وقائمة مجلد وفتح ملف للقراءة. لا توجد أي دالة كتابة أو حذف.
 */
class FileService : IFileService.Stub() {
    companion object {
        const val TAG = "HeroFileService"
        /** يجب أن يتطابق مع الثابت المتوقع في ShizukuHelper؛ يكشف خدمة قديمة ما زالت تعمل. */
        const val API_VERSION = 3
    }

    private var cachePath: String? = null
    private var cacheNames: List<String> = emptyList()

    init {
        Log.i(TAG, "created: uid=${Os.getuid()} pid=${android.os.Process.myPid()} loader=${javaClass.classLoader}")
    }

    override fun apiVersion(): Int = API_VERSION

    override fun destroy() {
        Log.i(TAG, "destroy requested")
        exitProcess(0)
    }

    override fun getUid(): Int = Os.getuid()

    private fun codeOf(e: Throwable): String = when (e) {
        is ErrnoException -> OsConstants.errnoName(e.errno) ?: "EIO"
        is AccessDeniedException -> "EACCES"
        is NoSuchFileException -> "ENOENT"
        is NotDirectoryException -> "ENOTDIR"
        else -> RemoteProtocol.errnoOf(e.message)
    }

    private fun fail(e: Throwable): String = RemoteProtocol.encodeError(codeOf(e), e.message ?: e.javaClass.simpleName)

    override fun probe(path: String): String = try {
        val st = Os.stat(path)
        RemoteProtocol.encodeStat(OsConstants.S_ISDIR(st.st_mode), st.st_size, Os.getuid(), st.st_mtime * 1000L)
    } catch (e: Throwable) {
        fail(e)
    }

    @Synchronized
    override fun list(path: String, offset: Int, limit: Int): String = try {
        if (offset == 0 || cachePath != path) {
            val names = ArrayList<String>()
            Files.newDirectoryStream(Paths.get(path)).use { ds -> for (p in ds) names.add(p.fileName.toString()) }
            names.sort()
            cachePath = path
            cacheNames = names
        }
        val total = cacheNames.size
        val end = minOf(total, offset + limit)
        val entries = if (offset >= total) emptyList() else cacheNames.subList(offset, end).map { n ->
            val f = File(path, n)
            RemoteEntry(n, f.isDirectory, if (f.isFile) f.length() else 0L, f.lastModified())
        }
        RemoteProtocol.encodeList(entries, end < total)
    } catch (e: Throwable) {
        fail(e)
    }

    override fun openRead(path: String): ParcelFileDescriptor {
        try {
            return ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
        } catch (e: Throwable) {
            // Binder ينقل IllegalStateException مع رسالته، فيصل سبب الرفض كاملاً للتطبيق
            throw IllegalStateException(codeOf(e) + ": " + (e.message ?: ""))
        }
    }
}
