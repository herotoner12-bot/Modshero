package com.herotoner.herobackup.core

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ZipEntryInfo(val size: Long, val sha256: String)
class ZipPart(val prefix: String, val root: SourceNode)
data class ZipBuildResult(val files: Map<String, ZipEntryInfo>, val dirs: Set<String>, val failures: List<FailureEntry>)

object ZipBuilder {
    /**
     * يبني ZIP بالبث (بدون تحميل الملفات في الذاكرة). محتوى جذر كل ZipPart يوضع مباشرة تحت prefix
     * (prefix فارغ = جذر الأرشيف، دون مجلد خارجي). الأسماء UTF-8 فتُحفظ العربية كما هي.
     */
    fun build(
        out: File,
        parts: List<ZipPart>,
        cancel: () -> Boolean = { false },
        onBytes: (Long) -> Unit = {},
        bufferSize: Int = 64 * 1024,
    ): ZipBuildResult {
        val files = LinkedHashMap<String, ZipEntryInfo>()
        val dirs = LinkedHashSet<String>()
        val failures = ArrayList<FailureEntry>()
        out.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out), bufferSize), Charsets.UTF_8).use { zos ->
            zos.setLevel(Deflater.DEFAULT_COMPRESSION)
            fun ensureDir(name: String, time: Long) {
                // name بدون / في النهاية
                if (name.isEmpty() || !dirs.add(name)) return
                val parent = name.substringBeforeLast('/', "")
                if (parent.isNotEmpty()) ensureDir(parent, time)
                val e = ZipEntry("$name/")
                if (time > 0) e.time = time
                zos.putNextEntry(e)
                zos.closeEntry()
            }
            for (part in parts) {
                val prefix = part.prefix.trimEnd('/')
                if (prefix.isNotEmpty()) ensureDir(prefix, 0L)
                Scanner.walk(part.root, "r", object : WalkVisitor {
                    private fun rel(parts: List<String>): String {
                        val r = parts.drop(1).joinToString("/")
                        return if (prefix.isEmpty()) r else if (r.isEmpty()) prefix else "$prefix/$r"
                    }

                    override fun onFile(parts: List<String>, node: SourceNode) {
                        val name = rel(parts)
                        ensureDir(name.substringBeforeLast('/', ""), 0L)
                        val entry = ZipEntry(name)
                        if (node.lastModified > 0) entry.time = node.lastModified
                        val md = MessageDigest.getInstance("SHA-256")
                        var size = 0L
                        zos.putNextEntry(entry)
                        try {
                            node.openInput().use { ins ->
                                val buf = ByteArray(bufferSize)
                                while (true) {
                                    if (cancel()) throw OperationCancelled()
                                    val n = ins.read(buf)
                                    if (n < 0) break
                                    md.update(buf, 0, n)
                                    zos.write(buf, 0, n)
                                    size += n
                                    onBytes(n.toLong())
                                }
                            }
                            files[name] = ZipEntryInfo(size, Hashing.hex(md.digest()))
                        } catch (e: OperationCancelled) {
                            throw e
                        } catch (e: SecurityException) {
                            failures += FailureEntry(name, FailureCode.PERMISSION_DENIED, e.message ?: "")
                        } catch (e: Exception) {
                            failures += FailureEntry(name, FailureCode.IO_ERROR, e.message ?: "")
                        } finally {
                            zos.closeEntry()
                        }
                    }

                    override fun onEmptyDir(parts: List<String>) {
                        val n = rel(parts)
                        if (n.isNotEmpty()) ensureDir(n, 0L)
                    }

                    override fun onFailure(path: String, code: String, detail: String) {
                        failures += FailureEntry(path, code, detail)
                    }
                }, cancel)
            }
        }
        return ZipBuildResult(files, dirs, failures)
    }
}

data class ZipReport(val ok: Boolean, val problems: List<String>, val entryCount: Int)

object ZipVerifier {
    /** يعيد قراءة الأرشيف كاملاً (يتحقق من CRC) ويقارن كل ملف بالمصدر (الحجم وSHA-256) ويكشف الناقص والزائد. */
    fun verify(zip: File, expected: Map<String, ZipEntryInfo>, cancel: () -> Boolean = { false }): ZipReport {
        val problems = ArrayList<String>()
        var count = 0
        try {
            ZipFile(zip, Charsets.UTF_8).use { zf ->
                val seen = HashSet<String>()
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    if (cancel()) throw OperationCancelled()
                    val e = en.nextElement()
                    count++
                    if (e.isDirectory) continue
                    seen += e.name
                    val exp = expected[e.name]
                    if (exp == null) { problems += "ملف زائد في الأرشيف: ${e.name}"; continue }
                    val md = MessageDigest.getInstance("SHA-256")
                    var size = 0L
                    try {
                        zf.getInputStream(e).use { ins ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                md.update(buf, 0, n)
                                size += n
                            }
                        }
                    } catch (x: java.util.zip.ZipException) {
                        problems += "ملف تالف داخل الأرشيف: ${e.name}"
                        continue
                    }
                    if (size != exp.size || Hashing.hex(md.digest()) != exp.sha256) problems += "محتوى مختلف عن المصدر: ${e.name}"
                }
                for (k in expected.keys) if (k !in seen) problems += "ملف مفقود من الأرشيف: $k"
            }
        } catch (e: OperationCancelled) {
            throw e
        } catch (e: Exception) {
            problems += "تعذر فتح الأرشيف: " + (e.message ?: "")
        }
        return ZipReport(problems.isEmpty(), problems, count)
    }
}

data class ArchiveReport(
    val ok: Boolean,
    val problems: List<String>,
    val levelName: String? = null,
    val packs: List<PackManifest> = emptyList(),
)

/** فحص بنية ملفات mcworld / mcpack / mcaddon كما سيراها Minecraft. */
object McArchives {
    private fun readEntry(zf: ZipFile, name: String, max: Int): ByteArray? {
        val e = zf.getEntry(name) ?: return null
        val bos = java.io.ByteArrayOutputStream()
        zf.getInputStream(e).use { ins ->
            val buf = ByteArray(8192)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                bos.write(buf, 0, n)
                if (bos.size() > max) throw java.io.IOException("ملف كبير")
            }
        }
        return bos.toByteArray()
    }

    fun inspectWorld(file: File): ArchiveReport {
        val problems = ArrayList<String>()
        try {
            ZipFile(file, Charsets.UTF_8).use { zf ->
                val names = zf.entries().asSequence().map { it.name }.toList()
                if (names.none { it == "level.dat" }) {
                    problems += if (names.any { it.endsWith("/level.dat") }) "ملفات العالم داخل مجلد خارجي: يجب أن يكون level.dat في جذر الأرشيف"
                    else "level.dat غير موجود في جذر الأرشيف"
                }
                if (names.none { it == "db/CURRENT" }) problems += "db/CURRENT غير موجود في الأرشيف"
                if (names.none { it.startsWith("db/MANIFEST-") }) problems += "db/MANIFEST غير موجود في الأرشيف"
                val lvl = readEntry(zf, "levelname.txt", 4096)?.let {
                    String(it, Charsets.UTF_8).lineSequence().firstOrNull()?.trim()?.removePrefix("\uFEFF")?.ifBlank { null }
                }
                return ArchiveReport(problems.isEmpty(), problems, lvl)
            }
        } catch (e: Exception) {
            return ArchiveReport(false, listOf("تعذر فتح الأرشيف: " + (e.message ?: "")))
        }
    }

    /** mcpack: manifest.json في الجذر. mcaddon: مجلد أو أكثر في الجذر، وفي كل منها manifest.json. */
    fun inspectPack(file: File, isAddon: Boolean): ArchiveReport {
        val problems = ArrayList<String>()
        val packs = ArrayList<PackManifest>()
        try {
            ZipFile(file, Charsets.UTF_8).use { zf ->
                val names = zf.entries().asSequence().map { it.name }.toList()
                val manifests: List<String> = if (!isAddon) {
                    if ("manifest.json" in names) listOf("manifest.json")
                    else { problems += "manifest.json غير موجود في جذر الأرشيف"; emptyList() }
                } else {
                    val tops = names.filter { it.contains('/') }.map { it.substringBefore('/') }.toSortedSet()
                    val loose = names.filter { !it.contains('/') && !it.endsWith("/") }
                    if (loose.isNotEmpty()) problems += "ملفات في جذر الـ mcaddon خارج مجلدات الحزم: " + loose.take(3).joinToString("، ")
                    val found = tops.filter { "$it/manifest.json" in names }.map { "$it/manifest.json" }
                    for (t in tops) if ("$t/manifest.json" !in names) problems += "المجلد «$t» لا يحتوي manifest.json"
                    if (found.isEmpty()) problems += "لا توجد أي حزمة صالحة داخل الـ mcaddon"
                    found
                }
                for (m in manifests) {
                    val bytes = readEntry(zf, m, 2_000_000)
                    if (bytes == null) { problems += "تعذر قراءة $m"; continue }
                    val r = PackManifestParser.parse(String(bytes, Charsets.UTF_8))
                    if (r.manifest == null) problems += r.problems.map { "$m: $it" } else packs += r.manifest
                }
                if (isAddon && packs.isNotEmpty()) {
                    val all = packs.flatMap { listOf(it.uuid) + it.moduleUuids }
                    if (all.size != all.toSet().size) problems += "UUID مكرر بين حزم الـ mcaddon"
                }
            }
        } catch (e: Exception) {
            return ArchiveReport(false, listOf("تعذر فتح الأرشيف: " + (e.message ?: "")))
        }
        return ArchiveReport(problems.isEmpty(), problems, null, packs)
    }
}
