package com.herotoner.herobackup.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onSettings: () -> Unit,
    onJob: () -> Unit,
) {
    val ctx = LocalContext.current
    val stats by vm.stats.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()

    ScreenScaffold(
        title = "",
        onBack = null,
        actions = {
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings))
            }
        },
    ) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { Logo(logoSize = 120.dp) }
            item {
                Text("HERO BACKUP", color = HeroColors.Text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            }
            item { Text(stringResource(R.string.tagline), color = HeroColors.TextSecondary, fontSize = 15.sp) }
            if (job?.active == true) {
                item {
                    InfoBanner(
                        text = stringResource(R.string.job_running_banner),
                        modifier = Modifier.clickable(onClick = onJob),
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(stats.count.toString(), stringResource(R.string.stat_count), Modifier.weight(1f))
                    StatTile(
                        stats.lastAt?.let { formatDate(it) } ?: stringResource(R.string.none_yet),
                        stringResource(R.string.stat_last), Modifier.weight(1.4f),
                    )
                    StatTile(formatBytes(ctx, stats.usedBytes), stringResource(R.string.stat_used), Modifier.weight(1f))
                }
            }
            if (stats.count > 0) {
                item { InfoBanner(stringResource(R.string.private_storage_warning), warning = true) }
            }
            item {
                BigButton(stringResource(R.string.create_backup), onBackup, icon = Icons.Filled.Add)
            }
            item {
                BigButton(
                    stringResource(R.string.restore_backup), onRestore,
                    iconRes = R.drawable.ic_restore, primary = false,
                )
            }
        }
    }
}
