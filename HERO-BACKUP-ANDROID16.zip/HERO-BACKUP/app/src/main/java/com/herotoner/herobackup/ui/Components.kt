package com.herotoner.herobackup.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.herobackup.R

@Composable
fun HeroCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = HeroColors.Card),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun BigButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    iconRes: Int? = null,
    enabled: Boolean = true,
    primary: Boolean = true,
    danger: Boolean = false,
) {
    val content: @Composable RowScope.() -> Unit = {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
        } else if (iconRes != null) {
            Icon(androidx.compose.ui.res.painterResource(iconRes), contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
    val shape = RoundedCornerShape(16.dp)
    val m = modifier.fillMaxWidth().height(56.dp)
    if (primary) {
        Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (danger) HeroColors.Danger else HeroColors.Primary,
                contentColor = HeroColors.OnPrimary,
                disabledContainerColor = HeroColors.Card,
                disabledContentColor = HeroColors.TextSecondary,
            ),
            content = content,
        )
    } else {
        OutlinedButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = if (danger) HeroColors.Danger else HeroColors.Primary,
                disabledContentColor = HeroColors.TextSecondary,
            ),
            content = content,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        containerColor = HeroColors.Bg,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                        }
                    }
                },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = HeroColors.Bg,
                    titleContentColor = HeroColors.Text,
                    navigationIconContentColor = HeroColors.Text,
                    actionIconContentColor = HeroColors.Text,
                ),
            )
        },
        content = content,
    )
}

@Composable
fun InfoBanner(text: String, warning: Boolean = false, modifier: Modifier = Modifier) {
    val tint = if (warning) HeroColors.Warning else HeroColors.Primary
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = HeroColors.Card),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(
                if (warning) Icons.Filled.Warning else Icons.Filled.Info,
                contentDescription = null, tint = tint, modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(10.dp))
            Text(text, color = HeroColors.Text, fontSize = 14.sp, lineHeight = 22.sp)
        }
    }
}

@Composable
fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = HeroColors.Card),
    ) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = HeroColors.Primary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(label, color = HeroColors.TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = HeroColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun Muted(text: String, modifier: Modifier = Modifier) {
    Text(text, color = HeroColors.TextSecondary, fontSize = 13.sp, modifier = modifier)
}

/** شعار HERO BACKUP: درع مع علامة صح، يتنفّس بحركة خفيفة. */
@Composable
fun Logo(logoSize: Dp, animate: Boolean = true) {
    val t = rememberInfiniteTransition(label = "logo")
    val s by t.animateFloat(
        initialValue = 1f, targetValue = if (animate) 1.06f else 1f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "scale",
    )
    Canvas(Modifier.size(logoSize).scale(s)) {
        val w = size.width
        val h = size.height
        val shield = Path().apply {
            moveTo(w * 0.5f, h * 0.04f)
            lineTo(w * 0.9f, h * 0.18f)
            lineTo(w * 0.9f, h * 0.50f)
            cubicTo(w * 0.9f, h * 0.76f, w * 0.7f, h * 0.9f, w * 0.5f, h * 0.97f)
            cubicTo(w * 0.3f, h * 0.9f, w * 0.1f, h * 0.76f, w * 0.1f, h * 0.50f)
            lineTo(w * 0.1f, h * 0.18f)
            close()
        }
        drawPath(
            shield,
            brush = Brush.verticalGradient(listOf(HeroColors.Primary, Color14513B), startY = 0f, endY = h),
        )
        val check = Path().apply {
            moveTo(w * 0.32f, h * 0.50f)
            lineTo(w * 0.45f, h * 0.64f)
            lineTo(w * 0.70f, h * 0.36f)
        }
        drawPath(
            check, color = HeroColors.Bg,
            style = Stroke(width = w * 0.075f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

private val Color14513B = androidx.compose.ui.graphics.Color(0xFF14513B)
