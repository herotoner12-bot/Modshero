package com.herotoner.herobackup.data

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContract

/** اختيار مجلد عبر SAF. الإدخال: هل نحتاج صلاحية كتابة (وجهة) أم قراءة فقط (مصدر)؟ */
class PickTree : ActivityResultContract<Boolean, Uri?>() {
    override fun createIntent(context: Context, input: Boolean): Intent {
        var flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
            Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        if (input) flags = flags or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        return Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(flags)
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}

/** اختيار عدة ملفات مع إمكانية إبقاء الصلاحية. */
class PickFiles : ActivityResultContract<Unit, List<Uri>>() {
    override fun createIntent(context: Context, input: Unit): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != Activity.RESULT_OK || intent == null) return emptyList()
        val out = ArrayList<Uri>()
        val clip = intent.clipData
        if (clip != null) for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { out += it }
        if (out.isEmpty()) intent.data?.let { out += it }
        return out
    }
}

fun Context.persistRead(uri: Uri, write: Boolean = false): Boolean {
    var flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
    if (write) flags = flags or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    return try {
        contentResolver.takePersistableUriPermission(uri, flags)
        true
    } catch (e: SecurityException) {
        false
    }
}
