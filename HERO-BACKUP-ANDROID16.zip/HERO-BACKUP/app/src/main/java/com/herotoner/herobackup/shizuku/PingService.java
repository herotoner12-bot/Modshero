package com.herotoner.herobackup.shizuku;

import android.os.Build;
import android.os.Process;
import android.system.Os;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;

/**
 * تعمل داخل عملية يشغّلها Shizuku. مكتوبة بـ Java خالصة دون Kotlin ودون core عمداً:
 * إن نجحت هذه الخدمة وفشلت خدمة الملفات فالمشكلة في تحميل أصناف خدمة الملفات أو تعطلها عند البدء،
 * وإن فشلتا معاً فالمشكلة في تشغيل خدمات المستخدم عبر Shizuku نفسه.
 */
public class PingService extends IPingService.Stub {
    private static final String TAG = "HeroPingService";

    public PingService() {
        Log.i(TAG, "created: uid=" + Os.getuid() + " pid=" + Process.myPid());
    }

    @Override
    public void destroy() {
        Log.i(TAG, "destroy requested");
        System.exit(0);
    }

    @Override
    public int apiVersion() {
        return 3;
    }

    @Override
    public String info() {
        StringBuilder sb = new StringBuilder();
        sb.append("uid=").append(Os.getuid()).append('\n');
        sb.append("pid=").append(Process.myPid()).append('\n');
        sb.append("sdk=").append(Build.VERSION.SDK_INT).append('\n');
        sb.append("process=").append(readCmdline()).append('\n');
        sb.append("classpath=").append(System.getProperty("java.class.path")).append('\n');
        sb.append("classloader=").append(getClass().getClassLoader()).append('\n');
        Log.i(TAG, "info requested\n" + sb);
        return sb.toString();
    }

    private static String readCmdline() {
        try (InputStream in = new FileInputStream("/proc/self/cmdline")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[256];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            return bos.toString("UTF-8").replace('\0', ' ').trim();
        } catch (Throwable t) {
            return "تعذر القراءة: " + t;
        }
    }

    /** يحمّل أصناف خدمة الملفات داخل عملية الخدمة نفسها ويعيد كل نتيجة (OK أو FAIL مع الاستثناء الحقيقي). */
    @Override
    public String checkClasses() {
        String[] names = {
                "com.herotoner.herobackup.shizuku.IFileService",
                "com.herotoner.herobackup.shizuku.FileService",
                "com.herotoner.herobackup.core.RemoteProtocol",
                "com.herotoner.herobackup.core.Json",
                "kotlin.jvm.internal.Intrinsics",
                "kotlin.collections.CollectionsKt",
                "java.nio.file.Files",
                "android.system.Os",
                "android.system.OsConstants"
        };
        ClassLoader cl = getClass().getClassLoader();
        StringBuilder sb = new StringBuilder();
        for (String n : names) {
            try {
                Class.forName(n, true, cl);
                sb.append("OK|").append(n).append('\n');
            } catch (Throwable t) {
                sb.append("FAIL|").append(n).append('|').append(t).append('\n');
                Log.e(TAG, "class load failed: " + n, t);
            }
        }
        try {
            Object o = Class.forName("com.herotoner.herobackup.shizuku.FileService", true, cl)
                    .getConstructor().newInstance();
            sb.append("OK|new FileService() -> ").append(o.getClass().getName()).append('\n');
        } catch (Throwable t) {
            sb.append("FAIL|new FileService()|").append(t).append('\n');
            Log.e(TAG, "FileService construction failed", t);
        }
        return sb.toString();
    }
}
