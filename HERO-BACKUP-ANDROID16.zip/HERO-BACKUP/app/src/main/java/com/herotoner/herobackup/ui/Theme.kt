package com.herotoner.herobackup.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection

object HeroColors {
    val Bg = Color(0xFF101820)
    val Primary = Color(0xFF19C37D)
    val OnPrimary = Color(0xFF06251A)
    val Card = Color(0xFF1D2A31)
    val Text = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFA8B8C1)
    val Danger = Color(0xFFFF6B6B)
    val Warning = Color(0xFFFFC857)
}

private val scheme = darkColorScheme(
    primary = HeroColors.Primary,
    onPrimary = HeroColors.OnPrimary,
    background = HeroColors.Bg,
    onBackground = HeroColors.Text,
    surface = HeroColors.Card,
    onSurface = HeroColors.Text,
    surfaceVariant = HeroColors.Card,
    onSurfaceVariant = HeroColors.TextSecondary,
    error = HeroColors.Danger,
    secondaryContainer = Color(0xFF14513B),
    onSecondaryContainer = HeroColors.Text,
    outline = Color(0xFF3A4C56),
)

@Composable
fun HeroTheme(content: @Composable () -> Unit) {
    // التطبيق عربي بالكامل: الاتجاه RTL دائماً والمظهر داكن
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

val CardShape = RoundedCornerShape(20.dp)
