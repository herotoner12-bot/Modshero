package com.herotoner.herobackup.ui

import android.app.Application
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.BackupInfo
import com.herotoner.herobackup.core.BackupRepository
import com.herotoner.herobackup.core.FileEntry
import com.herotoner.herobackup.core.Json
import com.herotoner.herobackup.core.Manifest
import com.herotoner.herobackup.core.OverwritePolicy
import com.herotoner.herobackup.core.Progress
import com.herotoner.herobackup.core.RestoreReport
import com.herotoner.herobackup.core.Scanner
import com.herotoner.herobackup.core.VerifyReport
import com.herotoner.herobackup.core.Verifier
import com.herotoner.herobackup.data.AllFilesAccess
import com.herotoner.herobackup.data.SafNode
import com.herotoner.herobackup.data.SourceItem
import com.herotoner.herobackup.data.SourceStore
import com.herotoner.herobackup.data.persistRead
import com.herotoner.herobackup.work.BackupWorker
import com.herotoner.herobackup.work.JobFiles
import com.herotoner.herobackup.work.Jobs
import com.herotoner.herobackup.work.Jobs.toProgress
import com.herotoner.herobackup.work.RestoreWorker
import com.herotoner.herobackup.work.TransferWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface Scan {
    data object Scanning : Scan
    data class Done(val files: Int, val bytes: Long, val failures: Int) : Scan
    data object Expired : Scan
    data object Error : Scan
}

data class SourceUi(val item: SourceItem, val scan: Scan)
data class Stats(val count: Int, val lastAt: Long?, val usedBytes: Long, val incomplete: Int)

data class JobUi(
    val tag: String,
    val state: WorkInfo.State,
    val progress: Progress?,
    val status: String?,
    val code: String?,
    val backupId: String?,
) {
    val active: Boolean get() = !state.isFinished
}

sealed interface VerifyState {
    data object Idle : VerifyState
    data class Running(val progress: Progress?) : VerifyState
    data class Done(val report: VerifyReport) : VerifyState
}

data class TransferReport(
    val mode: String,
    val already: Boolean,
    val cancelled: Boolean,
    val imported: List<String>,
    val skipped: List<String>,
    val failed: List<Pair<String, String>>,
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    val repo = BackupRepository(File(app.filesDir, "backups"))
    private val store = SourceStore(app)
    private val wm = WorkManager.getInstance(app)
    private val prefs = app.getSharedPreferences("ui", Context.MODE_PRIVATE)

    val sources = MutableStateFlow<List<SourceUi>>(emptyList())
    val backups = MutableStateFlow<List<BackupInfo>>(emptyList())
    val stats = MutableStateFlow(Stats(0, null, 0L, 0))
    val job = MutableStateFlow<JobUi?>(null)
    val verify = MutableStateFlow<VerifyState>(VerifyState.Idle)
    val message = MutableStateFlow<Int?>(null)
    val allFiles = MutableStateFlow(AllFilesAccess.isGranted())
    /** مجلد وجهة اختاره المستخدم من متصفح الملفات الداخلي (مسار مباشر). */
    val pickedDest = MutableStateFlow<String?>(null)

    private val jobId = MutableStateFlow(
        prefs.getString("jobId", null)?.let { runCatching { UUID.fromString(it) }.getOrNull() }
    )
    private var scanJobs = listOf<Job>()
    private var verifyJob: Job? = null

    init {
        com.herotoner.herobackup.shizuku.ShizukuHelper.init(app)
        viewModelScope.launch {
            // تغيّر حالة Shizuku يعيد فحص المصادر المعتمدة عليه
            com.herotoner.herobackup.shizuku.ShizukuHelper.status.drop(1).collect { refreshSources() }
        }
        viewModelScope.launch {
            jobId.flatMapLatest { id -> if (id == null) flowOf(null) else wm.getWorkInfoByIdFlow(id) }
                .collect { info ->
                    job.value = info?.let { toUi(it) }
                    if (info == null || info.state.isFinished) refreshBackups()
                }
        }
        refreshSources()
        refreshBackups()
    }

    private fun toUi(info: WorkInfo): JobUi {
        val tag = when {
            Jobs.TAG_BACKUP in info.tags -> Jobs.TAG_BACKUP
            Jobs.TAG_RESTORE in info.tags -> Jobs.TAG_RESTORE
            Jobs.TAG_CONVERT in info.tags -> Jobs.TAG_CONVERT
            else -> Jobs.TAG_TRANSFER
        }
        return JobUi(
            tag, info.state, info.progress.toProgress(),
            info.outputData.getString(Jobs.K_STATUS), info.outputData.getString(Jobs.K_CODE),
            info.outputData.getString(Jobs.K_BACKUP_ID),
        )
    }

    // ---------- صلاحية جميع الملفات ----------
    fun addShizukuPath(path: String, name: String) {
        store.addShizuku(path, name)
        message.value = R.string.shz_source_added
        refreshSources()
    }

    fun refreshPermission() {
        com.herotoner.herobackup.shizuku.ShizukuHelper.refresh()
        val now = AllFilesAccess.isGranted()
        if (now != allFiles.value) {
            allFiles.value = now
            refreshSources()
        }
    }

    fun addPath(file: File) {
        store.addPath(file)
        refreshSources()
    }

    // ---------- المصادر ----------
    fun refreshSources() {
        scanJobs.forEach { it.cancel() }
        val items = store.list()
        sources.value = items.map { SourceUi(it, if (store.hasPermission(it)) Scan.Scanning else Scan.Expired) }
        scanJobs = items.filter { store.hasPermission(it) }.map { item ->
            viewModelScope.launch(Dispatchers.IO) {
                val me = coroutineContext.job
                val scan = try {
                    val s = Scanner.summarize(store.toNode(item), item.name) { !me.isActive }
                    Scan.Done(s.files, s.bytes, s.failures.size)
                } catch (e: SecurityException) {
                    Scan.Expired
                } catch (e: Exception) {
                    if (!me.isActive) return@launch
                    Scan.Error
                }
                sources.update { list -> list.map { if (it.item.id == item.id) it.copy(scan = scan) else it } }
            }
        }
    }

    fun addTree(uri: Uri) {
        if (!ctx.persistRead(uri)) message.value = R.string.msg_no_persist
        val name = try { SafNode.root(ctx.contentResolver, uri).name } catch (e: Exception) { ctx.getString(R.string.folder_default) }
        store.add(uri, name, true)
        refreshSources()
    }

    fun addFiles(uris: List<Uri>) {
        for (u in uris) {
            if (!ctx.persistRead(u)) message.value = R.string.msg_no_persist
            val n = try {
                com.herotoner.herobackup.data.SafFileNode.from(ctx.contentResolver, u).name
            } catch (e: Exception) { ctx.getString(R.string.file_default) }
            store.add(u, n, false)
        }
        refreshSources()
    }

    fun replaceTree(id: String, uri: Uri) {
        if (!ctx.persistRead(uri)) message.value = R.string.msg_no_persist
        val name = try { SafNode.root(ctx.contentResolver, uri).name } catch (e: Exception) { ctx.getString(R.string.folder_default) }
        store.replaceUri(id, uri, name)
        refreshSources()
    }

    fun removeSource(id: String) {
        store.remove(id)
        refreshSources()
    }

    // ---------- النسخ ----------
    fun refreshBackups() {
        viewModelScope.launch(Dispatchers.IO) {
            val l = repo.list()
            backups.value = l
            stats.value = Stats(l.size, l.maxOfOrNull { it.createdAt }, l.sumOf { it.totalBytes }, repo.incompleteCount())
        }
    }

    fun deleteBackup(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.delete(id)
            refreshBackups()
        }
    }

    fun cleanupIncomplete() {
        viewModelScope.launch(Dispatchers.IO) {
            if (job.value?.active != true) repo.cleanupIncomplete()
            refreshBackups()
        }
    }

    suspend fun manifest(id: String): Manifest? = withContext(Dispatchers.IO) { repo.loadManifest(id) }

    // ---------- التحقق ----------
    fun startVerify(id: String) {
        verifyJob?.cancel()
        verifyJob = viewModelScope.launch(Dispatchers.IO) {
            val m = repo.loadManifest(id) ?: return@launch
            val me = coroutineContext.job
            verify.value = VerifyState.Running(null)
            val r = Verifier.verify(repo, m, { !me.isActive }) { p -> verify.value = VerifyState.Running(p) }
            verify.value = if (r == null) VerifyState.Idle else VerifyState.Done(r)
        }
    }

    fun cancelVerify() {
        verifyJob?.cancel()
        verify.value = VerifyState.Idle
    }

    fun resetVerify() { verify.value = VerifyState.Idle }

    // ---------- الأعمال الطويلة ----------
    val busy: Boolean get() = job.value?.active == true

    private fun enqueue(req: OneTimeWorkRequest) {
        JobFiles.clearReport(ctx, "restore")
        JobFiles.clearReport(ctx, "transfer")
        JobFiles.clearReport(ctx, "convert")
        wm.enqueueUniqueWork(Jobs.UNIQUE, ExistingWorkPolicy.KEEP, req)
        prefs.edit().putString("jobId", req.id.toString()).apply()
        jobId.value = req.id
    }

    fun startBackup(name: String): Boolean {
        if (busy) return false
        val ids = sources.value.filter { it.scan !is Scan.Expired }.map { it.item.id }
        if (ids.isEmpty()) return false
        enqueue(
            OneTimeWorkRequestBuilder<BackupWorker>()
                .setInputData(workDataOf(Jobs.K_NAME to name, Jobs.K_SOURCES to ids.toTypedArray()))
                .addTag(Jobs.TAG_BACKUP)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
        )
        return true
    }

    fun startRestore(backupId: String, dest: Uri, policy: OverwritePolicy, selected: Collection<FileEntry>): Boolean {
        if (busy) return false
        if (dest.scheme != "file") ctx.persistRead(dest, write = true)
        JobFiles.writeSelection(ctx, selected.map { it.path })
        enqueue(
            OneTimeWorkRequestBuilder<RestoreWorker>()
                .setInputData(
                    workDataOf(
                        Jobs.K_BACKUP_ID to backupId, Jobs.K_DEST to dest.toString(), Jobs.K_POLICY to policy.name,
                    )
                )
                .addTag(Jobs.TAG_RESTORE)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
        )
        return true
    }

    fun startExport(backupId: String, dest: Uri): Boolean {
        if (busy) return false
        ctx.persistRead(dest, write = true)
        enqueue(
            OneTimeWorkRequestBuilder<TransferWorker>()
                .setInputData(workDataOf(Jobs.K_MODE to "export", Jobs.K_BACKUP_ID to backupId, Jobs.K_URI to dest.toString()))
                .addTag(Jobs.TAG_TRANSFER)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
        )
        return true
    }

    fun startImport(from: Uri): Boolean {
        if (busy) return false
        ctx.persistRead(from)
        enqueue(
            OneTimeWorkRequestBuilder<TransferWorker>()
                .setInputData(workDataOf(Jobs.K_MODE to "import", Jobs.K_URI to from.toString()))
                .addTag(Jobs.TAG_TRANSFER)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
        )
        return true
    }

    fun startConvert(mode: String, keys: Collection<String>, name: String): Boolean {
        if (busy || keys.isEmpty()) return false
        JobFiles.writeSelection(ctx, keys)
        enqueue(
            OneTimeWorkRequestBuilder<com.herotoner.herobackup.work.ConvertWorker>()
                .setInputData(workDataOf(Jobs.K_MODE to mode, Jobs.K_NAME to name))
                .addTag(Jobs.TAG_CONVERT)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
        )
        return true
    }

    suspend fun convertFailures(): List<com.herotoner.herobackup.core.FailureEntry> = withContext(Dispatchers.IO) {
        val raw = JobFiles.readReport(ctx, "convert") ?: return@withContext emptyList()
        runCatching {
            (Json.parseObject(raw)["failed"] as List<*>).map {
                val f = it as Map<*, *>
                com.herotoner.herobackup.core.FailureEntry(f["path"] as String, f["code"] as String, (f["detail"] as? String) ?: "")
            }
        }.getOrDefault(emptyList())
    }

    fun cancelJob() { wm.cancelUniqueWork(Jobs.UNIQUE) }

    fun dismissJob() {
        prefs.edit().remove("jobId").apply()
        jobId.value = null
        job.value = null
    }

    suspend fun restoreReport(): RestoreReport? = withContext(Dispatchers.IO) {
        JobFiles.readReport(ctx, "restore")?.let { runCatching { RestoreReport.fromJson(it) }.getOrNull() }
    }

    suspend fun transferReport(): TransferReport? = withContext(Dispatchers.IO) {
        val raw = JobFiles.readReport(ctx, "transfer") ?: return@withContext null
        runCatching {
            val m = Json.parseObject(raw)
            TransferReport(
                m["mode"] as String, m["already"] as Boolean, m["cancelled"] as Boolean,
                (m["imported"] as List<*>).map { it as String },
                (m["skipped"] as List<*>).map { it as String },
                (m["failed"] as List<*>).map { val f = it as Map<*, *>; (f["path"] as String) to (f["code"] as String) },
            )
        }.getOrNull()
    }

    // ---------- فتح/مشاركة ملفات Minecraft عبر Intent رسمي ----------
    fun fileUri(backupId: String, entry: FileEntry): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", repo.dataFile(backupId, entry.stored))
}

fun Context.launchFileIntent(uri: Uri, share: Boolean) {
    val intent = if (share) {
        Intent(Intent.ACTION_SEND).setType("application/octet-stream").putExtra(Intent.EXTRA_STREAM, uri)
    } else {
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream")
    }
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    intent.clipData = ClipData.newRawUri("", uri)
    try {
        startActivity(
            Intent.createChooser(intent, getString(if (share) R.string.share_title else R.string.open_title))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        android.widget.Toast.makeText(this, R.string.msg_no_app, android.widget.Toast.LENGTH_LONG).show()
    }
}
