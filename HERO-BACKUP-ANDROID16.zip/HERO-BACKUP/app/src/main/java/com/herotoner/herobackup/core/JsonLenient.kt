package com.herotoner.herobackup.core

/** manifest.json في الواقع قد يحتوي BOM أو تعليقات أو فواصل زائدة؛ ننظّفها قبل التحليل. */
object JsonLenient {
    fun clean(text: String): String {
        val s = text.removePrefix("\uFEFF")
        val noComments = StringBuilder()
        var i = 0
        var inStr = false
        while (i < s.length) {
            val c = s[i]
            if (inStr) {
                noComments.append(c)
                if (c == '\\' && i + 1 < s.length) { noComments.append(s[i + 1]); i += 2; continue }
                if (c == '"') inStr = false
                i++
                continue
            }
            if (c == '"') { inStr = true; noComments.append(c); i++; continue }
            if (c == '/' && i + 1 < s.length && s[i + 1] == '/') {
                while (i < s.length && s[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < s.length && s[i + 1] == '*') {
                i += 2
                while (i + 1 < s.length && !(s[i] == '*' && s[i + 1] == '/')) i++
                i += 2
                continue
            }
            noComments.append(c)
            i++
        }
        val t = noComments.toString()
        val out = StringBuilder()
        inStr = false
        i = 0
        while (i < t.length) {
            val c = t[i]
            if (inStr) {
                out.append(c)
                if (c == '\\' && i + 1 < t.length) { out.append(t[i + 1]); i += 2; continue }
                if (c == '"') inStr = false
                i++
                continue
            }
            if (c == '"') { inStr = true; out.append(c); i++; continue }
            if (c == ',') {
                var j = i + 1
                while (j < t.length && t[j].isWhitespace()) j++
                if (j < t.length && (t[j] == '}' || t[j] == ']')) { i++; continue }
            }
            out.append(c)
            i++
        }
        return out.toString()
    }

    fun parseObject(text: String): Map<String, Any?> = Json.parseObject(clean(text))
}
