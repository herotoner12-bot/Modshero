package com.herotoner.herobackup.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import com.herotoner.herobackup.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

enum class ShizukuStatus { NOT_INSTALLED, NOT_RUNNING, NEEDS_PERMISSION, DENIED, CONNECTED }

/** الربط مع Shizuku عبر الـ API الرسمية: حالة، طلب صلاحية، وربط خدمة الملفات (UserService). */
object ShizukuHelper {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQUEST_CODE = 4242

    val status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    val serviceFlow = MutableStateFlow<IFileService?>(null)
    val serviceUid = MutableStateFlow(-1)

    private var appCtx: Context? = null
    private var registered = false
    @Volatile private var binding = false
    @Volatile private var bindStartedAt = 0L
    private val main = Handler(Looper.getMainLooper())
    private var userArgs: Shizuku.UserServiceArgs? = null

    private val onBinder = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener {
        serviceFlow.value = null
        binding = false
        main.postDelayed({ refresh() }, 1000)
    }
    private val onPermission = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = IFileService.Stub.asInterface(binder)
            serviceUid.value = try { s.getUid() } catch (e: Exception) { -1 }
            serviceFlow.value = s
            binding = false
        }

        override fun onServiceDisconnected(name: ComponentName) {
            // انقطعت الخدمة (توقف Shizuku أو أُعيد تشغيله): نحاول إعادة الربط تلقائياً
            serviceFlow.value = null
            binding = false
            main.postDelayed({ refresh() }, 1000)
        }
    }

    fun init(ctx: Context) {
        if (registered) return
        appCtx = ctx.applicationContext
        registered = true
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPermission)
        refresh()
    }

    private fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun computeStatus(ctx: Context): ShizukuStatus {
        val alive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!alive) return if (installed(ctx)) ShizukuStatus.NOT_RUNNING else ShizukuStatus.NOT_INSTALLED
        return try {
            when {
                Shizuku.isPreV11() -> ShizukuStatus.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuStatus.CONNECTED
                Shizuku.shouldShowRequestPermissionRationale() -> ShizukuStatus.DENIED
                else -> ShizukuStatus.NEEDS_PERMISSION
            }
        } catch (e: Throwable) {
            ShizukuStatus.NOT_RUNNING
        }
    }

    fun refresh() {
        val ctx = appCtx ?: return
        val s = computeStatus(ctx)
        status.value = s
        if (s == ShizukuStatus.CONNECTED) bindIfNeeded(ctx) else serviceFlow.value = null
    }

    private fun args(ctx: Context): Shizuku.UserServiceArgs =
        userArgs ?: Shizuku.UserServiceArgs(ComponentName(ctx.packageName, FileService::class.java.name))
            .daemon(false)
            .processNameSuffix("files")
            .version(1)
            .also { userArgs = it }

    private fun bindIfNeeded(ctx: Context) {
        if (serviceFlow.value != null) return
        val now = SystemClock.elapsedRealtime()
        if (binding && now - bindStartedAt < 10_000) return
        try {
            binding = true
            bindStartedAt = now
            Shizuku.bindUserService(args(ctx), connection)
        } catch (e: Throwable) {
            binding = false
        }
    }

    fun requestPermission() {
        try {
            if (!Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku غير جاهز؛ ستظهر الحالة الصحيحة بعد إعادة الفحص
        }
        refresh()
    }

    /** ينتظر حتى تصبح الخدمة جاهزة (أو ينتهي الوقت) ويعيدها. */
    suspend fun awaitService(timeoutMs: Long = 10_000): IFileService? {
        val ctx = appCtx ?: return null
        refresh()
        return withTimeoutOrNull(timeoutMs) {
            while (status.value != ShizukuStatus.CONNECTED) {
                // لا فائدة من الانتظار إن كان الإذن مطلوباً أو Shizuku غير مثبّت
                if (status.value == ShizukuStatus.NOT_INSTALLED || status.value == ShizukuStatus.NEEDS_PERMISSION ||
                    status.value == ShizukuStatus.DENIED) return@withTimeoutOrNull null
                delay(300)
                refresh()
            }
            bindIfNeeded(ctx)
            serviceFlow.filterNotNull().first()
        }
    }

    fun awaitServiceBlocking(timeoutMs: Long = 15_000): IFileService? = runBlocking { awaitService(timeoutMs) }

    data class Snapshot(
        val installed: Boolean, val binderAlive: Boolean, val serverVersion: Int,
        val permission: String, val serviceBound: Boolean, val serviceUid: Int,
    )

    /** حالة مستقلة لكل طبقة: التثبيت، الخادم، صلاحية التطبيق، والخدمة المربوطة. */
    fun snapshot(ctx: Context): Snapshot {
        val alive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        val version = if (alive) try { Shizuku.getVersion() } catch (e: Throwable) { -1 } else -1
        val perm = if (!alive) "UNKNOWN" else try {
            when {
                Shizuku.isPreV11() -> "UNSUPPORTED"
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "GRANTED"
                Shizuku.shouldShowRequestPermissionRationale() -> "DENIED"
                else -> "ASK"
            }
        } catch (e: Throwable) { "UNKNOWN" }
        return Snapshot(installed(ctx), alive, version, perm, serviceFlow.value != null, serviceUid.value)
    }

    fun openShizukuApp(ctx: Context) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(PKG)
        if (intent != null) ctx.startActivity(intent)
        else Toast.makeText(ctx, R.string.shz_app_missing, Toast.LENGTH_LONG).show()
    }

    fun openDownloadPage(ctx: Context) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.shz_app_missing, Toast.LENGTH_LONG).show()
        }
    }
}
