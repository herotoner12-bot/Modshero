package com.herotoner.herobackup.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.ErrorInfo
import com.herotoner.herobackup.core.TraceLog
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

enum class ShizukuStatus { NOT_INSTALLED, NOT_RUNNING, NEEDS_PERMISSION, DENIED, CONNECTED }

/**
 * الربط مع Shizuku عبر الـ API الرسمية: حالة، طلب صلاحية، وربط خدمتين (UserService):
 * خدمة الملفات (IFileService) وخدمة اختبار Binder المستقلة (IPingService).
 * كل مرحلة تُسجَّل في Logcat (وسم HeroShizuku) وفي سجل داخل التطبيق، والاستثناءات تُحفظ كما هي.
 */
object ShizukuHelper {
    const val PKG = "moe.shizuku.privileged.api"
    const val TAG = "HeroShizuku"
    private const val REQUEST_CODE = 4242

    val status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    val serviceUid = MutableStateFlow(-1)

    /** سبب آخر فشل في الاتصال بخدمة الملفات (الاستثناء الحقيقي أو وصف المرحلة التي توقفت). */
    val lastError = MutableStateFlow<String?>(null)
    val traceFlow = MutableStateFlow<List<String>>(emptyList())
    private val traceLog = TraceLog(400)

    fun log(stage: String, msg: String, t: Throwable? = null) {
        if (t != null) Log.e(TAG, "[$stage] $msg", t) else Log.i(TAG, "[$stage] $msg")
        traceLog.add(stage, msg, t)
        traceFlow.value = traceLog.lines()
    }

    fun clearTrace() {
        traceLog.clear()
        traceFlow.value = emptyList()
    }

    private var appCtx: Context? = null
    private var registered = false
    private val main = Handler(Looper.getMainLooper())

    private fun versionCode(ctx: Context): Int = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else @Suppress("DEPRECATION") pi.versionCode
    } catch (e: Exception) {
        1
    }

    /** اتصال بخدمة مستخدم واحدة مع تتبّع كل مرحلة (bind، onServiceConnected، التحقق، الموت). */
    class Handle<T : Any>(
        val label: String,
        val className: String,
        private val suffixBase: String,
        private val tag: String,
        val descriptor: String,
        private val asInterface: (IBinder) -> T?,
        private val verify: (T) -> String?,
    ) {
        val flow = MutableStateFlow<T?>(null)
        @Volatile var binding = false
        @Volatile var startedAt = 0L
        @Volatile var attempt = 0
        @Volatile var callbackSeen = false
        @Volatile var bindException: Throwable? = null
        @Volatile var verifyError: String? = null
        @Volatile var binderInfo: String = ""
        @Volatile var connectedAt = 0L
        @Volatile var currentSuffix = ""
        private var args: Shizuku.UserServiceArgs? = null
        private var death: IBinder.DeathRecipient? = null
        private var lastBinder: IBinder? = null

        private val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                callbackSeen = true
                binding = false
                connectedAt = SystemClock.elapsedRealtime()
                val took = connectedAt - startedAt
                if (binder == null) {
                    verifyError = "onServiceConnected وصل بـ binder فارغ (null)"
                    log("CONNECT", "$label: $verifyError")
                    return
                }
                val alive = binder.isBinderAlive
                val ping = try { binder.pingBinder() } catch (t: Throwable) { false }
                val desc = try { binder.interfaceDescriptor } catch (t: Throwable) { "تعذر قراءته: " + t.javaClass.simpleName }
                binderInfo = "alive=$alive ping=$ping descriptor=$desc"
                log("CONNECT", "$label: onServiceConnected بعد ${took}ms component=$name $binderInfo")
                if (desc != descriptor) {
                    verifyError = "عدم تطابق AIDL: المتوقع $descriptor لكن الخدمة تعلن $desc"
                    log("VERIFY", "$label: $verifyError")
                    return
                }
                try {
                    val old = death
                    val ob = lastBinder
                    if (old != null && ob != null) try { ob.unlinkToDeath(old, 0) } catch (t: Throwable) { }
                    val d = IBinder.DeathRecipient {
                        log("DEATH", "$label: ماتت عملية الخدمة (binderDied)")
                        flow.value = null
                        binding = false
                    }
                    binder.linkToDeath(d, 0)
                    death = d
                    lastBinder = binder
                } catch (t: Throwable) {
                    log("DEATH", "$label: تعذر linkToDeath", t)
                }
                val svc = try { asInterface(binder) } catch (t: Throwable) { null }
                if (svc == null) {
                    verifyError = "asInterface أعاد null"
                    log("VERIFY", "$label: $verifyError")
                    return
                }
                val err = verify(svc)
                if (err != null) {
                    verifyError = err
                    log("VERIFY", "$label: فشل التحقق بعد الاتصال\n$err")
                    return
                }
                verifyError = null
                flow.value = svc
                log("READY", "$label: الخدمة جاهزة ومتحقَّق منها (بروتوكول متطابق)")
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                val up = if (connectedAt > 0) SystemClock.elapsedRealtime() - connectedAt else -1L
                flow.value = null
                binding = false
                log("DISCONNECT", "$label: onServiceDisconnected بعد ${up}ms من الاتصال")
                if (up in 0..3000) {
                    verifyError = "انقطعت الخدمة بعد ${up}ms فقط من الاتصال: عمليتها تتعطل بعد البدء (راجع Logcat: HeroFileService / HeroPingService)"
                } else if (label == "خدمة الملفات") {
                    main.postDelayed({ refresh() }, 1000)
                }
            }
        }

        fun bind(ctx: Context, attempt: Int) {
            this.attempt = attempt
            callbackSeen = false
            bindException = null
            verifyError = null
            // مفتاح سجل الخدمة في خادم Shizuku هو package:tag، أما processNameSuffix فيسمّي العملية فقط (المصدر الرسمي)
            currentSuffix = suffixBase
            val vc = versionCode(ctx)
            val serverVersion = try { Shizuku.getVersion() } catch (t: Throwable) { -1 }
            if (serverVersion in 0..9) {
                bindException = IllegalStateException("إصدار خادم Shizuku ($serverVersion) أقدم من 10 ولا يدعم خدمات المستخدم")
                log("BIND", "$label: ${bindException?.message}")
                return
            }
            val a = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, className))
                .daemon(false)
                .processNameSuffix(currentSuffix)
                .tag(tag)
                .version(vc)
            args = a
            log("BIND", "$label: bindUserService(component=${ctx.packageName}/$className, tag=$tag, suffix=$currentSuffix, version=$vc, daemon=false, serverApi=$serverVersion)")
            try {
                binding = true
                startedAt = SystemClock.elapsedRealtime()
                Shizuku.bindUserService(a, conn)
                log("BIND", "$label: bindUserService عاد دون استثناء، بانتظار onServiceConnected")
            } catch (t: Throwable) {
                binding = false
                bindException = t
                log("BIND", "$label: bindUserService رمى استثناءً", t)
            }
        }

        fun unbind(remove: Boolean) {
            val a = args
            if (a != null) {
                try {
                    Shizuku.unbindUserService(a, conn, remove)
                    log("UNBIND", "$label: unbindUserService(remove=$remove)")
                } catch (t: Throwable) {
                    log("UNBIND", "$label: unbindUserService رمى استثناءً", t)
                }
            }
            flow.value = null
            binding = false
            callbackSeen = false
        }

        fun ensureBound(ctx: Context) {
            if (flow.value != null) return
            if (binding && SystemClock.elapsedRealtime() - startedAt < 35_000) return // مهلة بدء الخدمة في خادم Shizuku 30 ثانية
            bind(ctx, attempt)
        }

        fun diagnose(): String {
            bindException?.let { return "استثناء أثناء bindUserService:\n" + ErrorInfo.describe(it) }
            verifyError?.let { return "اتصلت الخدمة لكن فشل التحقق منها:\n$it" }
            if (!callbackSeen) {
                return "استُدعي bindUserService دون خطأ لكن لم يصل onServiceConnected (المحاولة ${attempt + 1}): " +
                    "لم تبدأ عملية الخدمة داخل Shizuku أو تعطلت عند البدء. شغّل «اختبار اتصال Binder» لمعرفة السبب."
            }
            return "الخدمة غير متاحة حالياً (انقطعت بعد الاتصال)."
        }
    }

    private fun verifyFile(s: IFileService): String? = try {
        val v = s.apiVersion()
        if (v != FileService.API_VERSION) "بروتوكول مختلف: الخدمة=$v والتطبيق=${FileService.API_VERSION} (خدمة قديمة من إصدار سابق)"
        else { serviceUid.value = s.getUid(); null }
    } catch (t: Throwable) {
        "فشل استدعاء apiVersion/getUid (غالباً خدمة قديمة أو AIDL غير متطابق):\n" + ErrorInfo.describe(t)
    }

    private fun verifyPing(s: IPingService): String? = try {
        val v = s.apiVersion()
        if (v != 3) "بروتوكول مختلف: الخدمة=$v" else null
    } catch (t: Throwable) {
        "فشل استدعاء apiVersion:\n" + ErrorInfo.describe(t)
    }

    val fileHandle = Handle<IFileService>(
        "خدمة الملفات", FileService::class.java.name, "files", "hero-files",
        "com.herotoner.herobackup.shizuku.IFileService", { IFileService.Stub.asInterface(it) }, { verifyFile(it) },
    )
    val pingHandle = Handle<IPingService>(
        "خدمة الاختبار", PingService::class.java.name, "ping", "hero-ping",
        "com.herotoner.herobackup.shizuku.IPingService", { IPingService.Stub.asInterface(it) }, { verifyPing(it) },
    )

    val serviceFlow: MutableStateFlow<IFileService?> get() = fileHandle.flow

    private val onBinder = Shizuku.OnBinderReceivedListener {
        log("BINDER", "وصل Binder من Shizuku")
        refresh()
    }
    private val onDead = Shizuku.OnBinderDeadListener {
        log("BINDER", "مات Binder الخاص بـ Shizuku (توقف الخادم)")
        fileHandle.flow.value = null
        fileHandle.binding = false
        pingHandle.flow.value = null
        pingHandle.binding = false
        main.postDelayed({ refresh() }, 1000)
    }
    private val onPermission = Shizuku.OnRequestPermissionResultListener { code, result ->
        log("PERMISSION", "نتيجة طلب الصلاحية: code=$code result=$result")
        refresh()
    }

    fun init(ctx: Context) {
        if (registered) return
        appCtx = ctx.applicationContext
        registered = true
        log("INIT", "تهيئة ShizukuHelper (API 13.1.5)، android=${Build.VERSION.SDK_INT}")
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPermission)
        refresh()
    }

    private fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun computeStatus(ctx: Context): ShizukuStatus {
        val alive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!alive) return if (installed(ctx)) ShizukuStatus.NOT_RUNNING else ShizukuStatus.NOT_INSTALLED
        return try {
            when {
                Shizuku.isPreV11() -> ShizukuStatus.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuStatus.CONNECTED
                Shizuku.shouldShowRequestPermissionRationale() -> ShizukuStatus.DENIED
                else -> ShizukuStatus.NEEDS_PERMISSION
            }
        } catch (e: Throwable) {
            log("STATUS", "فشل فحص الحالة", e)
            ShizukuStatus.NOT_RUNNING
        }
    }

    fun refresh() {
        val ctx = appCtx ?: return
        val s = computeStatus(ctx)
        if (s != status.value) log("STATUS", "الحالة: ${status.value} ← $s")
        status.value = s
        if (s == ShizukuStatus.CONNECTED) fileHandle.ensureBound(ctx) else fileHandle.flow.value = null
    }

    fun requestPermission() {
        try {
            if (!Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            log("PERMISSION", "فشل requestPermission", e)
        }
        refresh()
    }

    /**
     * ينتظر خدمة الملفات. بدء الخدمة غير متزامن في خادم Shizuku (مهلته الرسمية 30 ثانية) ولا يُبلَّغ العميل بالفشل،
     * لذا ننتظر حتى مهلة كافية ولا نقتل المحاولة أثناء بدئها. عند الفشل يوضع السبب الحقيقي في lastError.
     */
    suspend fun awaitService(timeoutMs: Long = 40_000): IFileService? {
        val ctx = appCtx
        if (ctx == null) {
            lastError.value = "ShizukuHelper لم يُهيَّأ (init لم يُستدعَ)"
            return null
        }
        refresh()
        val h = fileHandle
        val r = withTimeoutOrNull(timeoutMs) {
            while (status.value != ShizukuStatus.CONNECTED) {
                val st = status.value
                if (st == ShizukuStatus.NOT_INSTALLED || st == ShizukuStatus.NEEDS_PERMISSION || st == ShizukuStatus.DENIED) {
                    lastError.value = "حالة Shizuku: $st (لا يمكن ربط الخدمة قبل ذلك)"
                    return@withTimeoutOrNull null
                }
                delay(300)
                refresh()
            }
            h.ensureBound(ctx)
            var out: IFileService? = null
            while (true) {
                val cur = h.flow.value
                if (cur != null) { out = cur; break }
                if (h.callbackSeen && h.verifyError != null) break
                if (h.bindException != null && !h.binding) break
                delay(200)
            }
            out
        }
        lastError.value = if (r == null) lastError.value?.takeIf { it.startsWith("حالة Shizuku") } ?: h.diagnose() else null
        if (r == null) log("AWAIT", "فشل الحصول على خدمة الملفات: ${lastError.value}")
        return r
    }

    fun awaitServiceBlocking(timeoutMs: Long = 40_000): IFileService? = runBlocking { awaitService(timeoutMs) }

    data class Snapshot(
        val installed: Boolean, val binderAlive: Boolean, val serverVersion: Int,
        val permission: String, val serviceBound: Boolean, val serviceUid: Int,
    )

    /** حالة مستقلة لكل طبقة: التثبيت، الخادم، صلاحية التطبيق، والخدمة المربوطة. */
    fun snapshot(ctx: Context): Snapshot {
        val alive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        val version = if (alive) try { Shizuku.getVersion() } catch (e: Throwable) { -1 } else -1
        val perm = if (!alive) "UNKNOWN" else try {
            when {
                Shizuku.isPreV11() -> "UNSUPPORTED"
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "GRANTED"
                Shizuku.shouldShowRequestPermissionRationale() -> "DENIED"
                else -> "ASK"
            }
        } catch (e: Throwable) { "UNKNOWN" }
        return Snapshot(installed(ctx), alive, version, perm, fileHandle.flow.value != null, serviceUid.value)
    }

    fun openShizukuApp(ctx: Context) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(PKG)
        if (intent != null) ctx.startActivity(intent)
        else Toast.makeText(ctx, R.string.shz_app_missing, Toast.LENGTH_LONG).show()
    }

    fun openDownloadPage(ctx: Context) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.shz_app_missing, Toast.LENGTH_LONG).show()
        }
    }
}
