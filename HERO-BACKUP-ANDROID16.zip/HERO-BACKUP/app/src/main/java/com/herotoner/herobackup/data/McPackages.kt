package com.herotoner.herobackup.data

import android.content.Context
import android.os.Process
import androidx.core.content.pm.PackageInfoCompat
import com.herotoner.herobackup.core.MinecraftPaths

/** اكتشاف تطبيقات Minecraft Bedrock المثبّتة (الأساسي وPreview وEducation). لا يُفترض مسار واحد. */
object McPackages {
    data class Installed(val pkg: String, val versionName: String, val versionCode: Long)

    fun installed(ctx: Context): List<Installed> = MinecraftPaths.PACKAGES.mapNotNull { p ->
        try {
            val info = ctx.packageManager.getPackageInfo(p, 0)
            Installed(p, info.versionName ?: "?", PackageInfoCompat.getLongVersionCode(info))
        } catch (e: Exception) { null }
    }

    fun primary(ctx: Context): String? = installed(ctx).firstOrNull()?.pkg

    /** مستخدم Android الحالي (يختلف في «المساحة الثانية»/Dual apps: /storage/emulated/10). */
    fun userId(): Int = Process.myUid() / 100000
}
