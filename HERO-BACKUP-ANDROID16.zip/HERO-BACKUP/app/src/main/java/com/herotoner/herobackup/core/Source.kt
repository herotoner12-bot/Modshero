package com.herotoner.herobackup.core

import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream

/** عقدة مصدر (ملف أو مجلد). تنفيذ SAF في طبقة data، وتنفيذ File للاختبارات. */
interface SourceNode {
    val name: String
    val isDirectory: Boolean
    val size: Long
    val lastModified: Long

    @Throws(IOException::class)
    fun children(): List<SourceNode>

    @Throws(IOException::class)
    fun openInput(): InputStream
}

class FileSourceNode(private val file: File) : SourceNode {
    override val name: String get() = file.name
    override val isDirectory: Boolean get() = file.isDirectory
    override val size: Long get() = if (file.isFile) file.length() else 0L
    override val lastModified: Long get() = file.lastModified()

    override fun children(): List<SourceNode> {
        if (!file.exists()) throw java.io.FileNotFoundException("المسار غير ظاهر للتطبيق (غير موجود أو محجوب): ${file.path}")
        val list = file.listFiles() ?: throw SecurityException("رفض النظام قراءة المجلد: ${file.path}")
        return list.sortedBy { it.name }.map { FileSourceNode(it) }
    }

    override fun openInput(): InputStream = FileInputStream(file)
}

class SourceRoot(val displayName: String, val node: SourceNode)

interface WalkVisitor {
    fun onFile(parts: List<String>, node: SourceNode)
    fun onEmptyDir(parts: List<String>)
    fun onFailure(path: String, code: String, detail: String)
}

object Scanner {
    /**
     * يمشي على الشجرة بدون تعاود (stack صريح) لدعم المسارات العميقة والطويلة.
     * parts[0] هو اسم الجذر.
     */
    fun walk(root: SourceNode, rootName: String, visitor: WalkVisitor, cancel: () -> Boolean) {
        if (!root.isDirectory) {
            visitor.onFile(listOf(rootName), root)
            return
        }
        val stack = ArrayDeque<Pair<List<String>, SourceNode>>()
        stack.addLast(listOf(rootName) to root)
        while (stack.isNotEmpty()) {
            if (cancel()) throw OperationCancelled()
            val (parts, dir) = stack.removeLast()
            val kids = try {
                dir.children()
            } catch (e: OperationCancelled) {
                throw e
            } catch (e: SecurityException) {
                visitor.onFailure(parts.joinToString("/"), FailureCode.PERMISSION_DENIED, e.message ?: "")
                continue
            } catch (e: Exception) {
                visitor.onFailure(parts.joinToString("/"), FailureCode.IO_ERROR, e.message ?: "")
                continue
            }
            if (kids.isEmpty()) {
                visitor.onEmptyDir(parts)
                continue
            }
            for (k in kids.reversed()) {
                val childParts = parts + k.name
                if (k.isDirectory) stack.addLast(childParts to k) else visitor.onFile(childParts, k)
            }
        }
    }

    data class Summary(val files: Int, val bytes: Long, val failures: List<FailureEntry>)

    /** ملخص سريع لعرضه عند اختيار المجلدات (عدد الملفات والحجم وما تعذر الوصول إليه). */
    fun summarize(root: SourceNode, name: String, cancel: () -> Boolean = { false }): Summary {
        var files = 0
        var bytes = 0L
        val failures = ArrayList<FailureEntry>()
        walk(root, name, object : WalkVisitor {
            override fun onFile(parts: List<String>, node: SourceNode) {
                files++
                if (node.size > 0) bytes += node.size
            }

            override fun onEmptyDir(parts: List<String>) {}
            override fun onFailure(path: String, code: String, detail: String) {
                failures += FailureEntry(path, code, detail)
            }
        }, cancel)
        return Summary(files, bytes, failures)
    }
}
