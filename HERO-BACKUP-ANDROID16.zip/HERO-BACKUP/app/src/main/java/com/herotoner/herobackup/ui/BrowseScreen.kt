package com.herotoner.herobackup.ui

import android.os.Environment
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.data.AllFilesAccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * متصفح ملفات داخلي يستخدم صلاحية جميع الملفات.
 * mode = "source": إضافة مجلد/ملف كمصدر نسخ. mode = "dest": اختيار مجلد وجهة للاستعادة.
 */
@Composable
fun BrowseScreen(vm: MainViewModel, mode: String, onBack: () -> Unit, onPermission: () -> Unit) {
    val ctx = LocalContext.current
    val granted by vm.allFiles.collectAsStateWithLifecycle()
    val root = remember { Environment.getExternalStorageDirectory() }
    var currentPath by rememberSaveable { mutableStateOf(root.absolutePath) }
    val current = File(currentPath)
    val isSource = mode == "source"

    val listing by produceState<Pair<Boolean, List<File>>?>(null, currentPath, granted) {
        value = null
        value = withContext(Dispatchers.IO) {
            val kids = File(currentPath).listFiles()
            if (kids == null) false to emptyList()
            else true to kids.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        }
    }

    ScreenScaffold(
        stringResource(if (isSource) R.string.title_browse_source else R.string.title_browse_dest), onBack,
    ) { inner ->
        if (!granted) {
            LazyColumn(Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { InfoBanner(stringResource(R.string.perm_status_off), warning = true) }
                item { BigButton(stringResource(R.string.perm_open_settings), onPermission) }
            }
            return@ScreenScaffold
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                HeroCard {
                    Text(current.absolutePath, color = HeroColors.Primary, fontSize = 13.sp)
                    BigButton(
                        stringResource(if (isSource) R.string.add_this_folder else R.string.use_this_folder),
                        {
                            if (isSource) {
                                vm.addPath(current)
                            } else {
                                vm.pickedDest.value = android.net.Uri.fromFile(current).toString()
                            }
                            onBack()
                        },
                    )
                    if (current.absolutePath != root.absolutePath) {
                        BigButton(
                            stringResource(R.string.go_up),
                            { current.parentFile?.let { currentPath = it.absolutePath } },
                            primary = false,
                        )
                    }
                }
            }
            if (currentPath.contains("/Android/data") || currentPath.contains("/Android/obb")) {
                item { InfoBanner(stringResource(R.string.browse_android_data_note), warning = true) }
            }
            val l = listing
            when {
                l == null -> item { Muted(stringResource(R.string.loading)) }
                !l.first -> item { InfoBanner(stringResource(R.string.browse_blocked), warning = true) }
                l.second.isEmpty() -> item { Muted(stringResource(R.string.browse_empty)) }
                else -> items(l.second, key = { it.absolutePath }) { f ->
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = f.isDirectory) { currentPath = f.absolutePath }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                painterResource(if (f.isDirectory) R.drawable.ic_folder else R.drawable.ic_file),
                                contentDescription = null, tint = HeroColors.Primary, modifier = Modifier.size(24.dp),
                            )
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(f.name, color = HeroColors.Text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (f.isFile) Muted(formatBytes(ctx, f.length()))
                            }
                            if (isSource && f.isFile) {
                                TextButton(onClick = { vm.addPath(f) }) {
                                    Text(stringResource(R.string.add_file), color = HeroColors.Primary)
                                }
                            }
                        }
                        HorizontalDivider(color = HeroColors.Card)
                    }
                }
            }
        }
    }
}
