package com.herotoner.herobackup.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.CheckResult
import com.herotoner.herobackup.core.CheckStatus

private fun statusMark(s: CheckStatus) = when (s) {
    CheckStatus.PASS -> "✔"; CheckStatus.FAIL -> "✘"; CheckStatus.WARN -> "⚠"; CheckStatus.INFO -> "ℹ"; CheckStatus.SKIP -> "–"
}

private fun statusColor(s: CheckStatus): Color = when (s) {
    CheckStatus.PASS -> HeroColors.Primary; CheckStatus.FAIL -> HeroColors.Danger
    CheckStatus.WARN -> HeroColors.Warning; else -> HeroColors.TextSecondary
}

@Composable
fun CompatScreen(compat: CompatViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val results by compat.results.collectAsStateWithLifecycle()
    val running by compat.running.collectAsStateWithLifecycle()
    val quick by compat.quick.collectAsStateWithLifecycle()
    val summary = results.filter { it.group == CompatChecks.G_SUMMARY }
    val rest = results.filter { it.group != CompatChecks.G_SUMMARY }

    ScreenScaffold(stringResource(R.string.title_compat), onBack) { inner ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inner), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { InfoBanner(stringResource(R.string.compat_intro)) }
            quick?.let { q ->
                item {
                    HeroCard {
                        Text(q.android, color = HeroColors.Primary, fontWeight = FontWeight.Bold)
                        Muted(q.device)
                        Muted(q.minecraft)
                        Muted(stringResource(R.string.compat_ready_methods, q.methods))
                    }
                }
            }
            item {
                BigButton(stringResource(R.string.compat_run), { compat.run() }, icon = Icons.Filled.Refresh, enabled = !running)
            }
            if (running) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = HeroColors.Primary, trackColor = HeroColors.Card) }
            if (summary.isNotEmpty()) {
                item {
                    HeroCard {
                        SectionTitle(stringResource(R.string.compat_summary))
                        summary.forEach {
                            Text(statusMark(it.status) + " " + it.title, color = statusColor(it.status), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (it.detail.isNotBlank()) Muted(it.detail)
                        }
                    }
                }
            }
            var group = ""
            rest.forEach { r: CheckResult ->
                val header = r.group != group
                group = r.group
                item(key = r.group + "|" + r.title + "|" + rest.indexOf(r)) {
                    HeroCard {
                        if (header) SectionTitle(r.group)
                        Text(statusMark(r.status) + " " + r.title, color = statusColor(r.status), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        if (r.detail.isNotBlank()) Muted(r.detail)
                    }
                }
            }
            if (results.isNotEmpty() && !running) {
                item {
                    BigButton(stringResource(R.string.compat_copy), {
                        val cm = ctx.getSystemService(ClipboardManager::class.java)
                        cm?.setPrimaryClip(ClipData.newPlainText("HERO BACKUP", compat.reportText()))
                        Toast.makeText(ctx, R.string.compat_copied, Toast.LENGTH_SHORT).show()
                    }, primary = false)
                }
                item {
                    BigButton(stringResource(R.string.compat_share), {
                        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, compat.reportText())
                        ctx.startActivity(Intent.createChooser(i, null))
                    }, primary = false)
                }
            }
            item {
                BigButton(stringResource(R.string.compat_battery_settings), {
                    try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) {
                        Toast.makeText(ctx, R.string.perm_cannot_open, Toast.LENGTH_LONG).show()
                    }
                }, primary = false)
            }
            item {
                BigButton(stringResource(R.string.compat_app_settings), {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                    } catch (e: Exception) { Toast.makeText(ctx, R.string.perm_cannot_open, Toast.LENGTH_LONG).show() }
                }, primary = false)
            }
        }
    }
}
