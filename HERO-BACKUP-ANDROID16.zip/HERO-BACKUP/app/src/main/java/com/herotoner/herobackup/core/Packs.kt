package com.herotoner.herobackup.core

import java.io.ByteArrayOutputStream
import java.text.Normalizer

enum class PackType { RESOURCE, BEHAVIOR, SKIN, TEMPLATE, UNKNOWN }

data class PackDep(val uuid: String?, val moduleName: String?, val version: List<Int>?)

data class PackManifest(
    val formatVersion: Int,
    val name: String,
    val uuid: String,
    val version: List<Int>,
    val moduleTypes: List<String>,
    val moduleUuids: List<String>,
    val deps: List<PackDep>,
    val type: PackType,
)

data class ManifestParse(val manifest: PackManifest?, val problems: List<String>, val warnings: List<String>)

object Versions {
    fun parse(v: Any?): List<Int>? = when (v) {
        is List<*> -> if (v.size == 3 && v.all { it is Number }) v.map { (it as Number).toInt() } else null
        is String -> {
            val nums = Regex("\\d+").findAll(v.substringBefore('-')).map { it.value.toInt() }.toList()
            if (nums.size == 3) nums else null
        }
        else -> null
    }

    fun compare(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until minOf(a.size, b.size)) if (a[i] != b[i]) return a[i].compareTo(b[i])
        return a.size.compareTo(b.size)
    }

    fun text(v: List<Int>) = v.joinToString(".")
}

object PackManifestParser {
    private val UUID_RE = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
    fun isUuid(s: String?) = s != null && UUID_RE.matches(s)

    fun parse(text: String): ManifestParse {
        val problems = ArrayList<String>()
        val warnings = ArrayList<String>()
        val root = try {
            JsonLenient.parseObject(text)
        } catch (e: Exception) {
            return ManifestParse(null, listOf("ملف manifest.json غير صالح (JSON): " + (e.message ?: "")), emptyList())
        }
        val fv = (root["format_version"] as? Number)?.toInt()
        if (fv == null) problems += "format_version مفقود أو غير صالح"
        val header = root["header"] as? Map<*, *>
        if (header == null) {
            return ManifestParse(null, problems + "قسم header مفقود", warnings)
        }
        val name = (header["name"] as? String) ?: ""
        if (name.isBlank()) problems += "اسم الحزمة (header.name) مفقود"
        val uuid = (header["uuid"] as? String)?.lowercase() ?: ""
        if (!isUuid(uuid)) problems += "UUID الحزمة غير صالح: «$uuid»"
        val version = Versions.parse(header["version"])
        if (version == null) problems += "نسخة الحزمة (header.version) غير صالحة"

        val modules = root["modules"] as? List<*>
        val types = ArrayList<String>()
        val moduleUuids = ArrayList<String>()
        if (modules == null || modules.isEmpty()) {
            problems += "لا توجد modules في الحزمة"
        } else {
            for (m in modules) {
                val mm = m as? Map<*, *>
                if (mm == null) { problems += "عنصر modules غير صالح"; continue }
                types += ((mm["type"] as? String) ?: "").lowercase()
                val mu = (mm["uuid"] as? String)?.lowercase() ?: ""
                if (!isUuid(mu)) problems += "UUID وحدة (module) غير صالح: «$mu»" else moduleUuids += mu
            }
        }
        val all = (listOf(uuid) + moduleUuids).filter { it.isNotEmpty() }
        if (all.size != all.toSet().size) problems += "UUID مكرر داخل الحزمة نفسها (header/modules)"

        val deps = ArrayList<PackDep>()
        val rawDeps = root["dependencies"]
        if (rawDeps != null && rawDeps !is List<*>) problems += "قسم dependencies غير صالح"
        (rawDeps as? List<*>)?.forEach { d ->
            val dm = d as? Map<*, *>
            if (dm == null) { problems += "عنصر في dependencies غير صالح"; return@forEach }
            val du = (dm["uuid"] as? String)?.lowercase()
            if (du != null && !isUuid(du)) problems += "UUID اعتمادية غير صالح: «$du»"
            deps += PackDep(du, dm["module_name"] as? String, Versions.parse(dm["version"]))
        }
        if (deps.any { it.uuid != null && it.uuid == uuid }) problems += "الحزمة تعتمد على نفسها"

        val type = when {
            types.contains("resources") && types.any { it in setOf("data", "script", "javascript", "client_data") } -> {
                problems += "الحزمة تجمع وحدات موارد وسلوك معاً"
                PackType.UNKNOWN
            }
            types.contains("resources") -> PackType.RESOURCE
            types.any { it in setOf("data", "script", "javascript", "client_data") } -> PackType.BEHAVIOR
            types.contains("skin_pack") -> PackType.SKIN
            types.contains("world_template") -> PackType.TEMPLATE
            else -> PackType.UNKNOWN
        }
        if (type == PackType.UNKNOWN && problems.none { it.startsWith("الحزمة تجمع") } && types.isNotEmpty()) {
            warnings += "نوع الحزمة غير معروف من وحدات: " + types.joinToString("، ")
        }
        if (problems.isNotEmpty() || version == null || fv == null) return ManifestParse(null, problems, warnings)
        return ManifestParse(PackManifest(fv, name, uuid, version, types, moduleUuids, deps, type), emptyList(), warnings)
    }
}

class PackInfo(
    val key: String,
    val folderName: String,
    val parts: List<String>,
    val node: SourceNode,
    val manifest: PackManifest?,
    val problems: List<String>,
    val warnings: List<String>,
    val suffixHint: PackType?,
    val locationHint: PackType?,
    val sizeBytes: Long,
    val fileCount: Int,
) {
    val type: PackType get() = manifest?.type ?: PackType.UNKNOWN
    val base: String get() = PackNames.baseName(folderName)
    val valid: Boolean get() = manifest != null && problems.isEmpty()
}

object PackNames {
    private val SUFFIX = Regex("^(.*?)[\\s._\\-(\\[]+(rp|rb|bp)[)\\]]?$", RegexOption.IGNORE_CASE)

    fun suffixOf(folder: String): PackType? {
        val m = SUFFIX.find(folder.trim()) ?: return null
        return if (m.groupValues[2].equals("rp", true)) PackType.RESOURCE else PackType.BEHAVIOR
    }

    /** الاسم الأساسي بعد إزالة لاحقة RP أو RB أو BP (لا تُزال إلا إن سبقها فاصل مثل . _ - مسافة). */
    fun baseName(folder: String): String {
        val t = folder.trim()
        val m = SUFFIX.find(t)
        val base = if (m != null && m.groupValues[1].isNotBlank()) m.groupValues[1] else t
        return Normalizer.normalize(base.trim(), Normalizer.Form.NFC)
    }

    fun matchKey(folder: String): String = baseName(folder).lowercase()
}

data class PackScanResult(val packs: List<PackInfo>, val failures: List<FailureEntry>, val truncated: Boolean)

object PackScanner {
    private const val MAX_DIRS = 20000
    private const val MAX_MANIFEST = 2_000_000

    internal fun readCapped(node: SourceNode, max: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        node.openInput().use { ins ->
            val buf = ByteArray(8192)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                bos.write(buf, 0, n)
                if (bos.size() > max) throw java.io.IOException("الملف كبير جداً")
            }
        }
        return bos.toByteArray()
    }

    fun scan(roots: List<SourceRoot>, cancel: () -> Boolean = { false }): PackScanResult {
        val packs = ArrayList<PackInfo>()
        val failures = ArrayList<FailureEntry>()
        var dirs = 0
        var truncated = false
        val names = Names.uniqueRootNames(roots.map { it.displayName })
        roots.forEachIndexed { i, r ->
            val stack = ArrayDeque<Pair<List<String>, SourceNode>>()
            stack.addLast(listOf(names[i]) to r.node)
            while (stack.isNotEmpty()) {
                if (cancel()) throw OperationCancelled()
                if (dirs++ > MAX_DIRS) { truncated = true; break }
                val (parts, dir) = stack.removeLast()
                if (!dir.isDirectory) continue
                val kids = try { dir.children() } catch (e: OperationCancelled) { throw e } catch (e: Exception) {
                    failures += FailureEntry(parts.joinToString("/"), if (e is SecurityException) FailureCode.PERMISSION_DENIED else FailureCode.IO_ERROR, e.message ?: "")
                    continue
                }
                if (kids.any { !it.isDirectory && it.name == "level.dat" }) continue // مجلد عالم: لا نبحث داخله
                val mf = kids.firstOrNull { !it.isDirectory && it.name == "manifest.json" }
                if (mf != null) {
                    packs += buildPack(parts, dir, mf, cancel)
                    continue
                }
                for (k in kids.reversed()) if (k.isDirectory) stack.addLast((parts + k.name) to k)
            }
        }
        return PackScanResult(packs, failures, truncated)
    }

    private fun buildPack(parts: List<String>, dir: SourceNode, mf: SourceNode, cancel: () -> Boolean): PackInfo {
        val folder = parts.last()
        var parse: ManifestParse
        try {
            parse = PackManifestParser.parse(String(readCapped(mf, MAX_MANIFEST), Charsets.UTF_8))
        } catch (e: SecurityException) {
            parse = ManifestParse(null, listOf("رفض النظام قراءة manifest.json: " + (e.message ?: "")), emptyList())
        } catch (e: Exception) {
            parse = ManifestParse(null, listOf("تعذر قراءة manifest.json: " + (e.message ?: "")), emptyList())
        }
        val problems = ArrayList(parse.problems)
        val warnings = ArrayList(parse.warnings)
        val suffix = PackNames.suffixOf(folder)
        val lower = parts.map { it.lowercase() }
        val location = when {
            lower.any { it == "resource_packs" || it == "development_resource_packs" } -> PackType.RESOURCE
            lower.any { it == "behavior_packs" || it == "development_behavior_packs" } -> PackType.BEHAVIOR
            else -> null
        }
        val t = parse.manifest?.type
        if (t != null && suffix != null && t != PackType.UNKNOWN && t != suffix) {
            problems += "اسم المجلد يشير إلى " + (if (suffix == PackType.RESOURCE) "RP" else "BP") +
                " لكن محتوى manifest من نوع " + (if (t == PackType.RESOURCE) "RP" else if (t == PackType.BEHAVIOR) "BP" else t.name)
        }
        if (t != null && location != null && t != PackType.UNKNOWN && t != location && t != PackType.SKIN && t != PackType.TEMPLATE) {
            warnings += "موقع المجلد لا يطابق نوع الحزمة"
        }
        val sum = try { Scanner.summarize(dir, folder, cancel) } catch (e: OperationCancelled) { throw e } catch (e: Exception) { Scanner.Summary(0, 0, emptyList()) }
        val m = if (problems.isEmpty()) parse.manifest else parse.manifest
        return PackInfo(parts.joinToString("/"), folder, parts, dir, m, problems, warnings, suffix, location, sum.bytes, sum.files)
    }
}

enum class Confidence { NAME_AND_DEPENDENCY, DEPENDENCY, NAME_ONLY }

class PackPair(val rp: PackInfo, val bp: PackInfo, val base: String, val confidence: Confidence, val warnings: List<String>) {
    val key: String get() = rp.key + "|" + bp.key
}

class Unmatched(val pack: PackInfo, val reason: String)

class MatchResult(
    val pairs: List<PackPair>,
    val rpOnly: List<PackInfo>,
    val bpOnly: List<PackInfo>,
    val others: List<PackInfo>,
    val unmatched: List<Unmatched>,
)

object PackValidator {
    /** أخطاء تمنع دمج حزمتين (RP + BP). القائمة الفارغة تعني أن الدمج آمن. */
    fun pairProblems(rp: PackInfo, bp: PackInfo): List<String> {
        val r = rp.manifest ?: return listOf("manifest الـ RP غير صالح")
        val b = bp.manifest ?: return listOf("manifest الـ BP غير صالح")
        val out = ArrayList<String>()
        if (r.type != PackType.RESOURCE) out += "الحزمة الأولى ليست Resource Pack"
        if (b.type != PackType.BEHAVIOR) out += "الحزمة الثانية ليست Behavior Pack"
        val ru = (listOf(r.uuid) + r.moduleUuids).toSet()
        val bu = (listOf(b.uuid) + b.moduleUuids).toSet()
        if (ru.intersect(bu).isNotEmpty()) out += "UUID مكرر بين الـ RP والـ BP"
        for (d in b.deps) if (d.uuid == r.uuid && d.version != null && Versions.compare(d.version, r.version) > 0) {
            out += "الـ BP يتطلب نسخة RP ${Versions.text(d.version)} لكن الموجودة ${Versions.text(r.version)}"
        }
        for (d in r.deps) if (d.uuid == b.uuid && d.version != null && Versions.compare(d.version, b.version) > 0) {
            out += "الـ RP يتطلب نسخة BP ${Versions.text(d.version)} لكن الموجودة ${Versions.text(b.version)}"
        }
        return out
    }
}

object PackMatcher {
    fun match(all: List<PackInfo>): MatchResult {
        val unmatched = ArrayList<Unmatched>()
        val valid = ArrayList<PackInfo>()
        for (p in all) if (p.valid) valid += p else unmatched += Unmatched(p, p.problems.joinToString("؛ ").ifBlank { "manifest غير صالح" })

        // تكرار نفس الحزمة (نفس UUID ونفس النسخة) في مسارات مختلفة: نُبقي الأولى فقط
        val seen = HashMap<String, PackInfo>()
        val unique = ArrayList<PackInfo>()
        for (p in valid) {
            val k = p.manifest!!.uuid + "@" + Versions.text(p.manifest.version)
            val first = seen[k]
            if (first == null) { seen[k] = p; unique += p }
            else unmatched += Unmatched(p, "حزمة مكررة: نفس UUID والنسخة موجودة في ${first.key}")
        }

        val rps = unique.filter { it.type == PackType.RESOURCE }
        val bps = unique.filter { it.type == PackType.BEHAVIOR }
        val others = unique.filter { it.type != PackType.RESOURCE && it.type != PackType.BEHAVIOR }
        val rpByUuid = rps.associateBy { it.manifest!!.uuid }
        val bpByUuid = bps.associateBy { it.manifest!!.uuid }

        val pairs = ArrayList<PackPair>()
        val usedRp = HashSet<String>()
        val usedBp = HashSet<String>()
        val blocked = HashSet<String>()

        fun dependsOnRp(bp: PackInfo, rp: PackInfo) = bp.manifest!!.deps.any { it.uuid == rp.manifest!!.uuid }
        fun dependsOnBp(rp: PackInfo, bp: PackInfo) = rp.manifest!!.deps.any { it.uuid == bp.manifest!!.uuid }

        // 1) المطابقة بالاسم الأساسي
        val rpGroups = rps.groupBy { PackNames.matchKey(it.folderName) }
        val bpGroups = bps.groupBy { PackNames.matchKey(it.folderName) }
        for (base in rpGroups.keys.intersect(bpGroups.keys)) {
            val rl = rpGroups.getValue(base)
            val bl = bpGroups.getValue(base)
            if (rl.size > 1 || bl.size > 1) {
                for (p in rl + bl) { blocked += p.key; unmatched += Unmatched(p, "الاسم الأساسي «${p.base}» مكرر لأكثر من حزمة من النوع نفسه، لا يمكن الجزم بالمطابقة") }
                continue
            }
            val rp = rl[0]
            val bp = bl[0]
            val problems = PackValidator.pairProblems(rp, bp)
            if (problems.isNotEmpty()) {
                blocked += rp.key; blocked += bp.key
                unmatched += Unmatched(rp, "لم تُدمج مع ${bp.folderName}: " + problems.joinToString("؛ "))
                unmatched += Unmatched(bp, "لم تُدمج مع ${rp.folderName}: " + problems.joinToString("؛ "))
                continue
            }
            // اعتمادية تشير إلى حزمة أخرى معروفة = ليستا لبعضهما
            val bpOther = bp.manifest!!.deps.mapNotNull { it.uuid }.any { it != rp.manifest!!.uuid && rpByUuid.containsKey(it) }
            val rpOther = rp.manifest!!.deps.mapNotNull { it.uuid }.any { it != bp.manifest.uuid && bpByUuid.containsKey(it) }
            if ((bpOther && !dependsOnRp(bp, rp)) || (rpOther && !dependsOnBp(rp, bp))) {
                blocked += rp.key; blocked += bp.key
                val why = "تتطابق الأسماء لكن اعتمادية إحدى الحزمتين تشير إلى حزمة أخرى، فلم تُدمجا"
                unmatched += Unmatched(rp, why); unmatched += Unmatched(bp, why)
                continue
            }
            val conf = if (dependsOnRp(bp, rp) || dependsOnBp(rp, bp)) Confidence.NAME_AND_DEPENDENCY else Confidence.NAME_ONLY
            val warn = if (conf == Confidence.NAME_ONLY) listOf("المطابقة بالاسم فقط: لا توجد اعتمادية بين الحزمتين") else emptyList()
            pairs += PackPair(rp, bp, rp.base, conf, warn)
            usedRp += rp.key; usedBp += bp.key
        }

        // 2) المطابقة بالاعتمادية (حتى لو اختلف الاسم) عندما تكون فريدة
        for (bp in bps) {
            if (bp.key in usedBp || bp.key in blocked) continue
            val candidates = bp.manifest!!.deps.mapNotNull { it.uuid }.mapNotNull { rpByUuid[it] }
                .filter { it.key !in usedRp && it.key !in blocked }.distinct()
            if (candidates.size != 1) continue
            val rp = candidates[0]
            val problems = PackValidator.pairProblems(rp, bp)
            if (problems.isNotEmpty()) {
                blocked += rp.key; blocked += bp.key
                unmatched += Unmatched(rp, "لم تُدمج مع ${bp.folderName}: " + problems.joinToString("؛ "))
                unmatched += Unmatched(bp, "لم تُدمج مع ${rp.folderName}: " + problems.joinToString("؛ "))
                continue
            }
            pairs += PackPair(rp, bp, bp.base, Confidence.DEPENDENCY, listOf("الأسماء مختلفة؛ المطابقة بالاعتمادية بين الحزمتين"))
            usedRp += rp.key; usedBp += bp.key
        }

        val rpOnly = rps.filter { it.key !in usedRp && it.key !in blocked }
        val bpOnly = bps.filter { it.key !in usedBp && it.key !in blocked }
        return MatchResult(pairs.sortedBy { it.base.lowercase() }, rpOnly, bpOnly, others, unmatched)
    }

    /** تحذير للحزمة المنفردة: اعتمادية على حزمة غير موجودة. */
    fun missingDependencyWarning(p: PackInfo, all: List<PackInfo>): String? {
        val known = all.mapNotNull { it.manifest?.uuid }.toSet()
        val missing = p.manifest?.deps?.mapNotNull { it.uuid }?.filter { it !in known } ?: return null
        return if (missing.isEmpty()) null else "تعتمد على حزمة غير موجودة بين المصادر الممسوحة: " + missing.joinToString("، ")
    }
}
