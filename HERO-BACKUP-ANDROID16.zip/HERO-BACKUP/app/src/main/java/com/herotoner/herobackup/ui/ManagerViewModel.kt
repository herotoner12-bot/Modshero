package com.herotoner.herobackup.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.herotoner.herobackup.R
import android.content.Intent
import android.net.Uri
import androidx.core.content.IntentCompat
import com.herotoner.herobackup.core.AccessMethod
import com.herotoner.herobackup.core.BackupEngine
import com.herotoner.herobackup.core.BackupOutcome
import com.herotoner.herobackup.core.DiscoverResult
import com.herotoner.herobackup.data.AccessDiscovery
import com.herotoner.herobackup.data.AllFilesAccess
import com.herotoner.herobackup.data.SafFileNode
import com.herotoner.herobackup.core.BackupRepository
import com.herotoner.herobackup.core.ImportKind
import com.herotoner.herobackup.core.ImportLog
import com.herotoner.herobackup.core.ImportLogEntry
import com.herotoner.herobackup.core.ImportPlanner
import com.herotoner.herobackup.core.ImportSession
import com.herotoner.herobackup.core.ImportStatus
import com.herotoner.herobackup.core.MatchResult
import com.herotoner.herobackup.core.OperationCancelled
import com.herotoner.herobackup.core.PackMatcher
import com.herotoner.herobackup.core.PackScanResult
import com.herotoner.herobackup.core.PackScanner
import com.herotoner.herobackup.core.SourceRoot
import com.herotoner.herobackup.core.WorldScanResult
import com.herotoner.herobackup.core.WorldScanner
import com.herotoner.herobackup.data.SourceStore
import com.herotoner.herobackup.shizuku.MinecraftProbe
import com.herotoner.herobackup.shizuku.ShizukuHelper
import com.herotoner.herobackup.shizuku.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class WorldScanUi(
    val running: Boolean = false, val done: Boolean = false, val current: String = "",
    val sourceCount: Int = 0, val result: WorldScanResult? = null,
)

data class ModScanUi(
    val running: Boolean = false, val done: Boolean = false,
    val sourceCount: Int = 0, val scan: PackScanResult? = null, val match: MatchResult? = null,
)

data class ImportRowUi(val id: String, val name: String, val status: ImportStatus, val detail: String)

data class DiscoverUi(val running: Boolean = false, val result: DiscoverResult? = null, val noteRes: Int? = null)

enum class ImportPhase { IDLE, PREPARING, READY, RUNNING, DONE }

data class ImportUi(
    val kind: ImportKind? = null, val backupName: String = "", val phase: ImportPhase = ImportPhase.IDLE,
    val rows: List<ImportRowUi> = emptyList(), val progress: Pair<Int, Int> = 0 to 0, val emptyNote: Boolean = false,
)

class ManagerViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    private val repo = BackupRepository(File(app.filesDir, "backups"))
    private val store = SourceStore(app)
    private val log = ImportLog(File(app.filesDir, "import-log.json"))

    init { AllFilesAccess.init(app) }

    val worldScan = MutableStateFlow(WorldScanUi())
    val selectedWorlds = MutableStateFlow<Set<String>>(emptySet())
    val modScan = MutableStateFlow(ModScanUi())
    val selectedMods = MutableStateFlow<Set<String>>(emptySet())
    val importUi = MutableStateFlow(ImportUi())
    val logEntries = MutableStateFlow<List<ImportLogEntry>>(emptyList())
    val message = MutableStateFlow<Int?>(null)
    val discover = MutableStateFlow(DiscoverUi())
    val incoming = MutableStateFlow<String?>(null)

    private var scanJob: Job? = null
    private var session: ImportSession? = null
    private var sessionName = ""

    private fun liveRoots(): List<SourceRoot> {
        ShizukuHelper.init(ctx)
        return store.list().filter { store.hasPermission(it) }.map { SourceRoot(it.name, store.toNode(it)) }
    }

    fun sourceCount(): Int = store.list().count { store.hasPermission(it) }

    // ---------- العوالم ----------
    fun scanWorlds() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val me = coroutineContext.job
            worldScan.value = WorldScanUi(running = true)
            val roots = liveRoots()
            if (roots.isEmpty()) { worldScan.value = WorldScanUi(done = true, sourceCount = 0); return@launch }
            try {
                val r = WorldScanner.scan(roots, { !me.isActive }) { n -> worldScan.update { it.copy(current = n) } }
                worldScan.value = WorldScanUi(done = true, sourceCount = roots.size, result = r)
                selectedWorlds.value = r.worlds.map { it.key }.toSet()
            } catch (e: OperationCancelled) {
                worldScan.value = WorldScanUi()
            }
        }
    }

    fun toggleWorld(key: String, on: Boolean) { selectedWorlds.update { if (on) it + key else it - key } }
    fun setAllWorlds(on: Boolean) {
        selectedWorlds.value = if (on) worldScan.value.result?.worlds?.map { it.key }?.toSet() ?: emptySet() else emptySet()
    }

    // ---------- المودات ----------
    fun scanMods() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val me = coroutineContext.job
            modScan.value = ModScanUi(running = true)
            val roots = liveRoots()
            if (roots.isEmpty()) { modScan.value = ModScanUi(done = true, sourceCount = 0); return@launch }
            try {
                val scan = PackScanner.scan(roots) { !me.isActive }
                val match = PackMatcher.match(scan.packs)
                modScan.value = ModScanUi(done = true, sourceCount = roots.size, scan = scan, match = match)
                selectedMods.value = match.pairs.map { "pair:" + it.key }.toSet()
            } catch (e: OperationCancelled) {
                modScan.value = ModScanUi()
            }
        }
    }

    fun toggleMod(key: String, on: Boolean) { selectedMods.update { if (on) it + key else it - key } }

    fun cancelScan() { scanJob?.cancel() }

    /** يجرّب SAF ثم جميع الملفات ثم Shizuku (يتوقف عند أول نجاح ويرجع للبديل عند الفشل) ويضيف المجلد كمصدر. */
    fun autoDiscover(thenScan: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val me = coroutineContext.job
            discover.value = DiscoverUi(running = true)
            val r = try {
                AccessDiscovery.run(ctx, store) { !me.isActive }
            } catch (e: OperationCancelled) {
                discover.value = DiscoverUi(); return@launch
            }
            var note: Int? = null
            val f = r.found
            if (f != null) {
                when (f.method) {
                    AccessMethod.FILES -> { store.addPath(File(f.label)); note = R.string.disc_added_files }
                    AccessMethod.SHIZUKU -> { store.addShizuku(f.label, "com.mojang"); note = R.string.disc_added_shizuku }
                    AccessMethod.SAF -> note = R.string.disc_used_saf
                    AccessMethod.OFFICIAL -> {}
                }
            }
            discover.value = DiscoverUi(false, r, note)
            if (f != null) thenScan()
        }
    }

    // ---------- استلام ملفات من Minecraft (مشاركة/فتح) ----------
    fun handleIncoming(intent: Intent?) {
        if (intent == null) return
        val uris: List<Uri> = when (intent.action) {
            Intent.ACTION_SEND -> listOfNotNull(IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE -> IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
            Intent.ACTION_VIEW -> listOfNotNull(intent.data)
            else -> return
        }
        intent.action = null // لا نعالجه مرتين عند تدوير الشاشة
        if (uris.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            incoming.value = ctx.getString(R.string.incoming_working)
            val roots = ArrayList<SourceRoot>()
            for (u in uris) {
                val n = try { SafFileNode.from(ctx.contentResolver, u) } catch (e: Exception) { null } ?: continue
                val ext = n.name.substringAfterLast('.', "").lowercase()
                if (ext in setOf("mcworld", "mcpack", "mcaddon", "mctemplate", "zip")) roots += SourceRoot(n.name, n)
            }
            if (roots.isEmpty()) { incoming.value = ctx.getString(R.string.incoming_unsupported); return@launch }
            val version = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
            val outcome = BackupEngine(repo).run(roots, ctx.getString(R.string.incoming_backup_name, formatDate(System.currentTimeMillis())), version)
            incoming.value = when (outcome) {
                is BackupOutcome.Success -> ctx.getString(R.string.incoming_done, outcome.manifest.files.size)
                is BackupOutcome.Failed -> ctx.getString(R.string.incoming_failed) + " " + (outcome.failures.firstOrNull()?.detail ?: "")
                else -> ctx.getString(R.string.incoming_failed)
            }
        }
    }

    fun dismissIncoming() { incoming.value = null }

    // ---------- الاستيراد إلى Minecraft ----------
    private fun rows(s: ImportSession?, items: List<com.herotoner.herobackup.core.ImportItem>) =
        items.map { ImportRowUi(it.id, it.displayName, it.status, it.detail) }

    private fun record(it: com.herotoner.herobackup.core.ImportItem) {
        if (it.status == ImportStatus.OPENED || it.status == ImportStatus.READY || it.status == ImportStatus.PENDING) return
        log.append(ImportLogEntry(System.currentTimeMillis(), sessionName, it.displayName, it.kind.name, it.status.name, it.detail))
        refreshLog()
    }

    fun prepareImport(backupId: String, kind: ImportKind) {
        viewModelScope.launch(Dispatchers.IO) {
            val m = repo.loadManifest(backupId) ?: return@launch
            sessionName = m.name
            val items = ImportPlanner.items(repo, m, kind)
            if (items.isEmpty()) {
                importUi.value = ImportUi(kind, m.name, ImportPhase.IDLE, emptyNote = true); return@launch
            }
            importUi.value = ImportUi(kind, m.name, ImportPhase.PREPARING, rows(null, items))
            ImportPlanner.prepare(items) { i, n -> importUi.update { it.copy(progress = i to n) } }
            items.filter { it.status == ImportStatus.FAILED }.forEach { record(it) }
            session = ImportSession(items, AndroidImportEnv(ctx)) { changed ->
                record(changed)
                importUi.update { it.copy(rows = rows(null, items)) }
            }
            importUi.update { it.copy(phase = ImportPhase.READY, rows = rows(null, items)) }
        }
    }

    fun startImport() {
        val s = session ?: return
        viewModelScope.launch(Dispatchers.IO) {
            importUi.update { it.copy(phase = ImportPhase.RUNNING) }
            if (!s.launchNext()) importUi.update { it.copy(phase = ImportPhase.DONE) }
        }
    }

    /** عند عودة المستخدم من Minecraft: نتحقق من العنصر المفتوح ثم نفتح التالي تلقائياً. */
    fun onAppResumed() {
        val s = session ?: return
        if (!s.waiting) return
        viewModelScope.launch(Dispatchers.IO) {
            delay(1500)
            s.onReturned()
            if (!s.launchNext()) importUi.update { it.copy(phase = ImportPhase.DONE, rows = rows(null, s.items)) }
        }
    }

    fun stopImport() {
        val s = session ?: return
        s.stop()
        importUi.update { it.copy(phase = ImportPhase.DONE, rows = rows(null, s.items)) }
    }

    fun confirmImport(id: String) {
        val s = session ?: return
        s.items.firstOrNull { it.id == id }?.let { s.confirm(it) }
    }

    fun resetImport() { session = null; importUi.value = ImportUi() }

    fun refreshLog() {
        viewModelScope.launch(Dispatchers.IO) { logEntries.value = log.list().reversed() }
    }

    fun clearLog() {
        viewModelScope.launch(Dispatchers.IO) { log.clear(); logEntries.value = emptyList() }
    }
}
