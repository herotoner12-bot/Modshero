package com.herotoner.herobackup.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.BackupRepository
import com.herotoner.herobackup.core.ImportKind
import com.herotoner.herobackup.core.ImportLog
import com.herotoner.herobackup.core.ImportLogEntry
import com.herotoner.herobackup.core.ImportPlanner
import com.herotoner.herobackup.core.ImportSession
import com.herotoner.herobackup.core.ImportStatus
import com.herotoner.herobackup.core.MatchResult
import com.herotoner.herobackup.core.OperationCancelled
import com.herotoner.herobackup.core.PackMatcher
import com.herotoner.herobackup.core.PackScanResult
import com.herotoner.herobackup.core.PackScanner
import com.herotoner.herobackup.core.SourceRoot
import com.herotoner.herobackup.core.WorldScanResult
import com.herotoner.herobackup.core.WorldScanner
import com.herotoner.herobackup.data.SourceStore
import com.herotoner.herobackup.shizuku.MinecraftProbe
import com.herotoner.herobackup.shizuku.ShizukuHelper
import com.herotoner.herobackup.shizuku.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class WorldScanUi(
    val running: Boolean = false, val done: Boolean = false, val current: String = "",
    val sourceCount: Int = 0, val result: WorldScanResult? = null,
)

data class ModScanUi(
    val running: Boolean = false, val done: Boolean = false,
    val sourceCount: Int = 0, val scan: PackScanResult? = null, val match: MatchResult? = null,
)

data class ImportRowUi(val id: String, val name: String, val status: ImportStatus, val detail: String)

enum class ImportPhase { IDLE, PREPARING, READY, RUNNING, DONE }

data class ImportUi(
    val kind: ImportKind? = null, val backupName: String = "", val phase: ImportPhase = ImportPhase.IDLE,
    val rows: List<ImportRowUi> = emptyList(), val progress: Pair<Int, Int> = 0 to 0, val emptyNote: Boolean = false,
)

class ManagerViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    private val repo = BackupRepository(File(app.filesDir, "backups"))
    private val store = SourceStore(app)
    private val log = ImportLog(File(app.filesDir, "import-log.json"))

    val worldScan = MutableStateFlow(WorldScanUi())
    val selectedWorlds = MutableStateFlow<Set<String>>(emptySet())
    val modScan = MutableStateFlow(ModScanUi())
    val selectedMods = MutableStateFlow<Set<String>>(emptySet())
    val importUi = MutableStateFlow(ImportUi())
    val logEntries = MutableStateFlow<List<ImportLogEntry>>(emptyList())
    val message = MutableStateFlow<Int?>(null)

    private var scanJob: Job? = null
    private var session: ImportSession? = null
    private var sessionName = ""

    private fun liveRoots(): List<SourceRoot> {
        ShizukuHelper.init(ctx)
        return store.list().filter { store.hasPermission(it) }.map { SourceRoot(it.name, store.toNode(it)) }
    }

    fun sourceCount(): Int = store.list().count { store.hasPermission(it) }

    // ---------- العوالم ----------
    fun scanWorlds() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val me = coroutineContext.job
            worldScan.value = WorldScanUi(running = true)
            val roots = liveRoots()
            if (roots.isEmpty()) { worldScan.value = WorldScanUi(done = true, sourceCount = 0); return@launch }
            try {
                val r = WorldScanner.scan(roots, { !me.isActive }) { n -> worldScan.update { it.copy(current = n) } }
                worldScan.value = WorldScanUi(done = true, sourceCount = roots.size, result = r)
                selectedWorlds.value = r.worlds.map { it.key }.toSet()
            } catch (e: OperationCancelled) {
                worldScan.value = WorldScanUi()
            }
        }
    }

    fun toggleWorld(key: String, on: Boolean) { selectedWorlds.update { if (on) it + key else it - key } }
    fun setAllWorlds(on: Boolean) {
        selectedWorlds.value = if (on) worldScan.value.result?.worlds?.map { it.key }?.toSet() ?: emptySet() else emptySet()
    }

    // ---------- المودات ----------
    fun scanMods() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val me = coroutineContext.job
            modScan.value = ModScanUi(running = true)
            val roots = liveRoots()
            if (roots.isEmpty()) { modScan.value = ModScanUi(done = true, sourceCount = 0); return@launch }
            try {
                val scan = PackScanner.scan(roots) { !me.isActive }
                val match = PackMatcher.match(scan.packs)
                modScan.value = ModScanUi(done = true, sourceCount = roots.size, scan = scan, match = match)
                selectedMods.value = match.pairs.map { "pair:" + it.key }.toSet()
            } catch (e: OperationCancelled) {
                modScan.value = ModScanUi()
            }
        }
    }

    fun toggleMod(key: String, on: Boolean) { selectedMods.update { if (on) it + key else it - key } }

    fun cancelScan() { scanJob?.cancel() }

    /** يستخدم Shizuku (إن وافق المستخدم) لإيجاد مجلد Minecraft وإضافته كمصدر. */
    fun addMinecraftViaShizuku(onResult: (String) -> Unit) {
        viewModelScope.launch {
            if (ShizukuHelper.status.value != ShizukuStatus.CONNECTED) {
                onResult(ctx.getString(R.string.mgr_shizuku_not_connected)); return@launch
            }
            val svc = ShizukuHelper.awaitService(10_000)
            if (svc == null) { onResult(ctx.getString(R.string.shz_no_service)); return@launch }
            val r = withContext(Dispatchers.IO) { MinecraftProbe.check(ctx, svc) }
            val w = r.workingPath
            if (w == null) {
                onResult(ctx.getString(R.string.mgr_shizuku_blocked) + "\n" + (r.lines.lastOrNull()?.detail ?: ""))
            } else {
                store.addShizuku(w, "com.mojang")
                onResult(ctx.getString(R.string.shz_source_added))
            }
        }
    }

    // ---------- الاستيراد إلى Minecraft ----------
    private fun rows(s: ImportSession?, items: List<com.herotoner.herobackup.core.ImportItem>) =
        items.map { ImportRowUi(it.id, it.displayName, it.status, it.detail) }

    private fun record(it: com.herotoner.herobackup.core.ImportItem) {
        if (it.status == ImportStatus.OPENED || it.status == ImportStatus.READY || it.status == ImportStatus.PENDING) return
        log.append(ImportLogEntry(System.currentTimeMillis(), sessionName, it.displayName, it.kind.name, it.status.name, it.detail))
        refreshLog()
    }

    fun prepareImport(backupId: String, kind: ImportKind) {
        viewModelScope.launch(Dispatchers.IO) {
            val m = repo.loadManifest(backupId) ?: return@launch
            sessionName = m.name
            val items = ImportPlanner.items(repo, m, kind)
            if (items.isEmpty()) {
                importUi.value = ImportUi(kind, m.name, ImportPhase.IDLE, emptyNote = true); return@launch
            }
            importUi.value = ImportUi(kind, m.name, ImportPhase.PREPARING, rows(null, items))
            ImportPlanner.prepare(items) { i, n -> importUi.update { it.copy(progress = i to n) } }
            items.filter { it.status == ImportStatus.FAILED }.forEach { record(it) }
            session = ImportSession(items, AndroidImportEnv(ctx)) { changed ->
                record(changed)
                importUi.update { it.copy(rows = rows(null, items)) }
            }
            importUi.update { it.copy(phase = ImportPhase.READY, rows = rows(null, items)) }
        }
    }

    fun startImport() {
        val s = session ?: return
        viewModelScope.launch(Dispatchers.IO) {
            importUi.update { it.copy(phase = ImportPhase.RUNNING) }
            if (!s.launchNext()) importUi.update { it.copy(phase = ImportPhase.DONE) }
        }
    }

    /** عند عودة المستخدم من Minecraft: نتحقق من العنصر المفتوح ثم نفتح التالي تلقائياً. */
    fun onAppResumed() {
        val s = session ?: return
        if (!s.waiting) return
        viewModelScope.launch(Dispatchers.IO) {
            delay(1500)
            s.onReturned()
            if (!s.launchNext()) importUi.update { it.copy(phase = ImportPhase.DONE, rows = rows(null, s.items)) }
        }
    }

    fun stopImport() {
        val s = session ?: return
        s.stop()
        importUi.update { it.copy(phase = ImportPhase.DONE, rows = rows(null, s.items)) }
    }

    fun confirmImport(id: String) {
        val s = session ?: return
        s.items.firstOrNull { it.id == id }?.let { s.confirm(it) }
    }

    fun resetImport() { session = null; importUi.value = ImportUi() }

    fun refreshLog() {
        viewModelScope.launch(Dispatchers.IO) { logEntries.value = log.list().reversed() }
    }

    fun clearLog() {
        viewModelScope.launch(Dispatchers.IO) { log.clear(); logEntries.value = emptyList() }
    }
}
