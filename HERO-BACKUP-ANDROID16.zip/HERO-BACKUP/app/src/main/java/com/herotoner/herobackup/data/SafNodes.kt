package com.herotoner.herobackup.data

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.herotoner.herobackup.core.RestoreTarget
import com.herotoner.herobackup.core.SourceNode
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** عقدة داخل شجرة SAF (مجلد اختاره المستخدم). تستعلم عبر DocumentsContract مباشرة لسرعة أعلى. */
class SafNode(
    private val resolver: ContentResolver,
    private val treeUri: Uri,
    private val documentId: String,
    override val name: String,
    override val isDirectory: Boolean,
    override val size: Long,
    override val lastModified: Long,
) : SourceNode {

    override fun children(): List<SourceNode> {
        if (!isDirectory) return emptyList()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val cursor = resolver.query(childrenUri, projection, null, null, null)
            ?: throw IOException("تعذر قراءة المجلد: $name")
        val out = ArrayList<SourceNode>()
        cursor.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val display = c.getString(1) ?: id
                val mime = c.getString(2) ?: ""
                val sz = if (c.isNull(3)) -1L else c.getLong(3)
                val lm = if (c.isNull(4)) 0L else c.getLong(4)
                out += SafNode(
                    resolver, treeUri, id, display,
                    mime == DocumentsContract.Document.MIME_TYPE_DIR, sz, lm,
                )
            }
        }
        return out.sortedBy { it.name }
    }

    override fun openInput(): InputStream {
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
        return resolver.openInputStream(uri) ?: throw IOException("تعذر فتح الملف: $name")
    }

    companion object {
        fun root(resolver: ContentResolver, treeUri: Uri): SafNode {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
            var display = docId.substringAfterLast(':').substringAfterLast('/').ifBlank { "مجلد" }
            resolver.query(
                docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null,
            )?.use { c -> if (c.moveToFirst() && !c.isNull(0)) display = c.getString(0) }
            return SafNode(resolver, treeUri, docId, display, true, 0L, 0L)
        }
    }
}

/** ملف واحد اختاره المستخدم عبر منتقي المستندات. */
class SafFileNode(
    private val resolver: ContentResolver,
    private val uri: Uri,
    override val name: String,
    override val size: Long,
) : SourceNode {
    override val isDirectory: Boolean get() = false
    override val lastModified: Long get() = 0L
    override fun children(): List<SourceNode> = emptyList()
    override fun openInput(): InputStream =
        resolver.openInputStream(uri) ?: throw IOException("تعذر فتح الملف: $name")

    companion object {
        fun from(resolver: ContentResolver, uri: Uri): SafFileNode {
            var name = uri.lastPathSegment ?: "ملف"
            var size = -1L
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        if (!c.isNull(0)) name = c.getString(0)
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            return SafFileNode(resolver, uri, name, size)
        }
    }
}

/** وجهة كتابة داخل مجلد SAF يختاره المستخدم. لا تحاول تجاوز أي حماية من النظام. */
class SafRestoreTarget(
    private val resolver: ContentResolver,
    private val treeUri: Uri,
) : RestoreTarget {
    private val rootId = DocumentsContract.getTreeDocumentId(treeUri)
    private val cache = HashMap<String, String>() // مسار -> documentId

    private class Child(val id: String, val isDir: Boolean)

    private fun docUri(id: String) = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)

    private fun findChild(parentId: String, name: String): Child? {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        resolver.query(uri, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == name) {
                    return Child(c.getString(0), c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR)
                }
            }
        }
        return null
    }

    private fun key(parts: List<String>) = parts.joinToString("/")

    private fun resolveDir(parts: List<String>, create: Boolean): String? {
        var currentId = rootId
        val soFar = ArrayList<String>()
        for (p in parts) {
            soFar += p
            val k = key(soFar)
            val cached = cache[k]
            if (cached != null) { currentId = cached; continue }
            val existing = findChild(currentId, p)
            currentId = when {
                existing != null && existing.isDir -> existing.id
                existing != null -> throw IOException("يوجد ملف بنفس اسم المجلد: $p")
                create -> {
                    val created = DocumentsContract.createDocument(
                        resolver, docUri(currentId), DocumentsContract.Document.MIME_TYPE_DIR, p,
                    ) ?: throw IOException("تعذر إنشاء المجلد: $p")
                    DocumentsContract.getDocumentId(created)
                }
                else -> return null
            }
            cache[k] = currentId
        }
        return currentId
    }

    override fun exists(path: List<String>): Boolean {
        return try {
            val parent = resolveDir(path.dropLast(1), create = false) ?: return false
            findChild(parent, path.last()) != null
        } catch (e: IOException) {
            false
        }
    }

    override fun openOutput(path: List<String>, truncate: Boolean): OutputStream {
        val parent = resolveDir(path.dropLast(1), create = true) ?: throw IOException("تعذر تجهيز المجلد")
        val name = path.last()
        val existing = findChild(parent, name)
        val uri = if (existing != null) {
            if (existing.isDir) throw IOException("يوجد مجلد بنفس اسم الملف: $name")
            docUri(existing.id)
        } else {
            DocumentsContract.createDocument(resolver, docUri(parent), "application/octet-stream", name)
                ?: throw IOException("تعذر إنشاء الملف: $name")
        }
        return try {
            resolver.openOutputStream(uri, "wt") ?: throw IOException("تعذر فتح الملف للكتابة: $name")
        } catch (e: FileNotFoundException) {
            throw IOException(e.message, e)
        }
    }

    override fun delete(path: List<String>) {
        try {
            val parent = resolveDir(path.dropLast(1), create = false) ?: return
            val child = findChild(parent, path.last()) ?: return
            DocumentsContract.deleteDocument(resolver, docUri(child.id))
            cache.remove(key(path))
        } catch (e: Exception) {
            // أفضل جهد: حذف ملف ناقص أنشأناه نحن
        }
    }
}
