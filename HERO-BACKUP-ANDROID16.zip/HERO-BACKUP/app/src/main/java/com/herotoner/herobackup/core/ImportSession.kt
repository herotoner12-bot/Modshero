package com.herotoner.herobackup.core

import java.io.File

enum class ImportKind { WORLD, MOD }

enum class ImportStatus { PENDING, READY, OPENED, VERIFIED, NEEDS_CONFIRM, CONFIRMED, FAILED, SKIPPED }

class ImportItem(
    val id: String,
    val displayName: String,
    val kind: ImportKind,
    val file: File,
    val sha256: String,
    var status: ImportStatus = ImportStatus.PENDING,
    var detail: String = "",
    var levelName: String? = null,
)

interface ImportEnv {
    /** يفتح الملف في Minecraft. يعيد null عند النجاح أو رسالة خطأ. */
    fun launch(item: ImportItem): String?

    /** أسماء المجلدات الحالية داخل Minecraft (عوالم أو حزم) أو null إن تعذّر الفحص. */
    fun snapshot(kind: ImportKind): Set<String>?

    fun levelName(folder: String): String?
}

object ImportPlanner {
    private val WORLD_EXT = setOf("mcworld")
    private val MOD_EXT = setOf("mcaddon", "mcpack")

    fun items(repo: BackupRepository, manifest: Manifest, kind: ImportKind): List<ImportItem> {
        val exts = if (kind == ImportKind.WORLD) WORLD_EXT else MOD_EXT
        return manifest.files.filter { it.path.substringAfterLast('.', "").lowercase() in exts }.map {
            ImportItem(manifest.id + ":" + it.stored, it.path.substringAfterLast('/'), kind, repo.dataFile(manifest.id, it.stored), it.sha256)
        }
    }

    /** يتحقق من كل ملف: SHA-256 مقابل المانيفست ثم بنية الأرشيف. الفاشل يُعلَّم FAILED مع السبب. */
    fun prepare(items: List<ImportItem>, cancel: () -> Boolean = { false }, onProgress: (Int, Int) -> Unit = { _, _ -> }) {
        items.forEachIndexed { i, it ->
            if (cancel()) throw OperationCancelled()
            onProgress(i, items.size)
            if (!it.file.isFile) { it.status = ImportStatus.FAILED; it.detail = "الملف مفقود من النسخة"; return@forEachIndexed }
            val actual = try { Hashing.sha256(it.file, cancel = cancel) } catch (e: OperationCancelled) { throw e } catch (e: Exception) {
                it.status = ImportStatus.FAILED; it.detail = "تعذر قراءة الملف: " + (e.message ?: ""); return@forEachIndexed
            }
            if (actual != it.sha256) { it.status = ImportStatus.FAILED; it.detail = "الملف تالف (SHA-256 غير مطابق)"; return@forEachIndexed }
            val rep = if (it.kind == ImportKind.WORLD) McArchives.inspectWorld(it.file)
            else McArchives.inspectPack(it.file, it.file.name.lowercase().endsWith(".mcaddon"))
            if (!rep.ok) { it.status = ImportStatus.FAILED; it.detail = rep.problems.joinToString("؛ "); return@forEachIndexed }
            it.levelName = rep.levelName
            it.status = ImportStatus.READY
        }
        onProgress(items.size, items.size)
    }
}

/** آلة حالات الاستيراد: تفتح عنصراً، وعند العودة للتطبيق تتحقق (إن أمكن) ثم تنتقل للتالي. لا تدّعي النجاح دون دليل. */
class ImportSession(
    val items: List<ImportItem>,
    private val env: ImportEnv,
    private val onChange: (ImportItem) -> Unit = {},
) {
    private var cursor = 0
    private var before: Set<String>? = null
    var current: ImportItem? = null
        private set
    val waiting: Boolean get() = current != null && current!!.status == ImportStatus.OPENED
    var stopped = false
        private set

    private fun set(it: ImportItem, s: ImportStatus, d: String) { it.status = s; it.detail = d; onChange(it) }

    /** يفتح العنصر الجاهز التالي. يعيد false إذا لم يبقَ شيء. */
    fun launchNext(): Boolean {
        if (stopped) return false
        while (cursor < items.size) {
            val it = items[cursor++]
            if (it.status != ImportStatus.READY) continue
            before = env.snapshot(it.kind)
            val err = env.launch(it)
            if (err != null) { set(it, ImportStatus.FAILED, err); continue }
            current = it
            set(it, ImportStatus.OPENED, "فُتح في Minecraft بانتظار إتمام الاستيراد")
            return true
        }
        current = null
        return false
    }

    /** يُستدعى عند عودة المستخدم للتطبيق بعد فتح عنصر. */
    fun onReturned() {
        val it = current ?: return
        if (it.status != ImportStatus.OPENED) return
        val b = before
        val a = env.snapshot(it.kind)
        if (b == null || a == null) {
            set(it, ImportStatus.NEEDS_CONFIRM, "لا يمكن التحقق تلقائياً (Shizuku غير متصل). أكّد بنفسك أن Minecraft أتمّ الاستيراد")
            return
        }
        val added = a - b
        when {
            it.kind == ImportKind.WORLD && added.isNotEmpty() -> {
                val named = it.levelName
                if (named == null || added.any { f -> env.levelName(f) == named })
                    set(it, ImportStatus.VERIFIED, "ظهر العالم داخل Minecraft (تم التحقق عبر Shizuku)")
                else set(it, ImportStatus.NEEDS_CONFIRM, "ظهر عالم جديد لكن باسم مختلف عن «$named»؛ راجعه داخل اللعبة")
            }
            it.kind == ImportKind.MOD && added.isNotEmpty() ->
                set(it, ImportStatus.VERIFIED, "ظهرت ${added.size} حزمة جديدة داخل Minecraft (تم التحقق عبر Shizuku)")
            else -> set(it, ImportStatus.NEEDS_CONFIRM, "لم يُرصد عنصر جديد داخل Minecraft: قد يكون الاستيراد ما زال جارياً أو أُلغي أو مثبّتاً مسبقاً")
        }
    }

    fun confirm(item: ImportItem) {
        if (item.status == ImportStatus.NEEDS_CONFIRM) set(item, ImportStatus.CONFIRMED, "أكّد المستخدم نجاح الاستيراد")
    }

    fun stop() {
        stopped = true
        for (i in items) if (i.status == ImportStatus.READY) set(i, ImportStatus.SKIPPED, "أُوقفت العملية قبل فتحه")
    }
}

data class ImportLogEntry(val time: Long, val source: String, val item: String, val kind: String, val status: String, val detail: String)

/** سجل دائم لعمليات الاستيراد (ما تم وما يحتاج موافقة وما فشل). */
class ImportLog(private val file: File) {
    @Synchronized
    fun list(): List<ImportLogEntry> {
        if (!file.isFile) return emptyList()
        return try {
            (Json.parse(file.readText()) as List<*>).map {
                val m = it as Map<*, *>
                ImportLogEntry(
                    (m["t"] as Number).toLong(), m["s"] as String, m["i"] as String, m["k"] as String, m["st"] as String, (m["d"] as? String) ?: "",
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    fun append(e: ImportLogEntry) {
        val all = (list() + e).takeLast(500)
        file.parentFile?.mkdirs()
        file.writeText(Json.stringify(all.map { linkedMapOf("t" to it.time, "s" to it.source, "i" to it.item, "k" to it.kind, "st" to it.status, "d" to it.detail) }))
    }

    @Synchronized
    fun clear() { file.delete() }
}
