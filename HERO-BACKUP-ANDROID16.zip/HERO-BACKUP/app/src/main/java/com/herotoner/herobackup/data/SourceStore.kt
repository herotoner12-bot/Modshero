package com.herotoner.herobackup.data

import android.content.Context
import android.net.Uri
import com.herotoner.herobackup.core.Json
import java.util.UUID

data class SourceItem(val id: String, val uri: String, val name: String, val isTree: Boolean)

/** يحفظ المصادر التي اختارها المستخدم (مع صلاحيات URI المستمرة). */
class SourceStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("sources", Context.MODE_PRIVATE)

    fun list(): List<SourceItem> {
        val raw = prefs.getString("items", null) ?: return emptyList()
        return try {
            (Json.parse(raw) as List<*>).map {
                val m = it as Map<*, *>
                SourceItem(m["id"] as String, m["uri"] as String, m["name"] as String, m["tree"] as Boolean)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(items: List<SourceItem>) {
        val json = Json.stringify(items.map {
            linkedMapOf("id" to it.id, "uri" to it.uri, "name" to it.name, "tree" to it.isTree)
        })
        prefs.edit().putString("items", json).apply()
    }

    fun add(uri: Uri, name: String, isTree: Boolean): SourceItem {
        val items = list().toMutableList()
        items.firstOrNull { it.uri == uri.toString() }?.let { return it }
        val item = SourceItem(UUID.randomUUID().toString(), uri.toString(), name, isTree)
        items += item
        save(items)
        return item
    }

    /** يستبدل URI لمصدر انتهت صلاحيته بعد إعادة اختيار المجلد. */
    fun replaceUri(id: String, uri: Uri, name: String) {
        save(list().map { if (it.id == id) it.copy(uri = uri.toString(), name = name) else it })
    }

    fun remove(id: String) {
        val items = list()
        val gone = items.firstOrNull { it.id == id } ?: return
        save(items.filter { it.id != id })
        // لا نُفرج عن الصلاحية إن كان مصدر آخر يستخدم نفس URI
        if (items.none { it.id != id && it.uri == gone.uri }) {
            try {
                context.contentResolver.releasePersistableUriPermission(
                    Uri.parse(gone.uri), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            } catch (e: Exception) { }
        }
    }

    fun clear() {
        list().forEach { remove(it.id) }
    }

    fun hasPermission(item: SourceItem): Boolean {
        val uri = Uri.parse(item.uri)
        return context.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
    }

    fun toNode(item: SourceItem): com.herotoner.herobackup.core.SourceNode {
        if (!hasPermission(item)) return ExpiredNode(item.name)
        val uri = Uri.parse(item.uri)
        return try {
            if (item.isTree) SafNode.root(context.contentResolver, uri)
            else SafFileNode.from(context.contentResolver, uri)
        } catch (e: SecurityException) {
            ExpiredNode(item.name)
        }
    }
}

/** مصدر انتهت صلاحيته: أي قراءة تُرمي SecurityException فيسجلها المحرك كفشل بدل أن يتعطل. */
class ExpiredNode(override val name: String) : com.herotoner.herobackup.core.SourceNode {
    override val isDirectory: Boolean get() = true
    override val size: Long get() = 0L
    override val lastModified: Long get() = 0L
    override fun children(): List<com.herotoner.herobackup.core.SourceNode> =
        throw SecurityException("انتهت صلاحية الوصول إلى: $name")

    override fun openInput(): java.io.InputStream = throw SecurityException("انتهت صلاحية الوصول إلى: $name")
}
