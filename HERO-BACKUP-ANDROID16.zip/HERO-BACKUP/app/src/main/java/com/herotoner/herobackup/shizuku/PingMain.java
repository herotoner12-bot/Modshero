package com.herotoner.herobackup.shizuku;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.os.Build;
import android.os.Looper;
import android.os.Process;
import android.os.UserHandle;
import android.system.Os;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * يُشغَّل يدوياً من shell عبر app_process (وليس عبر خدمة Shizuku) لإعادة تنفيذ الخطوات نفسها التي ينفذها
 * rikka.shizuku.server.UserService.create في المصدر الرسمي، ويطبع نتيجة كل خطوة والاستثناء الحقيقي:
 *   systemMain ← getSystemContext ← createPackageContextAsUser(INCLUDE_CODE|IGNORE_SECURITY) ← mPackageInfo
 *   ← makeApplication(true, null) ← mInitialApplication ← loadClass ← newInstance.
 * إن فشلت خطوة هنا فهي نفسها سبب عدم بدء خدمة Shizuku. الاستخدام:
 *   CLASSPATH=/path/base.apk app_process /system/bin com.herotoner.herobackup.shizuku.PingMain PKG CLASS USERID
 */
public final class PingMain {
    private static final String TAG = "HeroPingMain";

    private static void out(String s) {
        System.out.println(s);
        Log.i(TAG, s);
    }

    private static void ok(int n, String what) {
        out("STEP " + n + " OK: " + what);
    }

    private static void fail(int n, String what, Throwable t) {
        Throwable r = t;
        if (r instanceof InvocationTargetException && r.getCause() != null) r = r.getCause();
        out("STEP " + n + " FAIL: " + what);
        out("  " + r);
        StackTraceElement[] st = r.getStackTrace();
        for (int i = 0; i < Math.min(8, st.length); i++) out("  at " + st[i]);
        Throwable c = r.getCause();
        int d = 0;
        while (c != null && d < 3) {
            out("  caused by " + c);
            c = c.getCause();
            d++;
        }
        Log.e(TAG, "STEP " + n + " FAIL: " + what, r);
        System.exit(2);
    }

    public static void main(String[] args) {
        String pkg = args.length > 0 ? args[0] : "com.herotoner.herobackup";
        String cls = args.length > 1 ? args[1] : "com.herotoner.herobackup.shizuku.PingService";
        int userId = 0;
        try {
            if (args.length > 2) userId = Integer.parseInt(args[2]);
        } catch (NumberFormatException ignored) {
        }
        try {
            ok(0, "main بدأ: uid=" + Os.getuid() + " pid=" + Process.myPid() + " sdk=" + Build.VERSION.SDK_INT
                    + " class.path=" + System.getProperty("java.class.path"));
        } catch (Throwable t) {
            fail(0, "قراءة معلومات العملية", t);
        }
        try {
            Looper.prepareMainLooper();
            ok(1, "Looper.prepareMainLooper");
        } catch (Throwable t) {
            fail(1, "Looper.prepareMainLooper", t);
        }
        Class<?> atClass = null;
        Object activityThread = null;
        try {
            atClass = Class.forName("android.app.ActivityThread");
            activityThread = atClass.getMethod("systemMain").invoke(null);
            ok(2, "ActivityThread.systemMain()");
        } catch (Throwable t) {
            fail(2, "ActivityThread.systemMain()", t);
        }
        Object systemContext = null;
        try {
            systemContext = atClass.getMethod("getSystemContext").invoke(activityThread);
            ok(3, "getSystemContext()");
        } catch (Throwable t) {
            fail(3, "getSystemContext()", t);
        }
        UserHandle uh = null;
        try {
            uh = (UserHandle) UserHandle.class.getMethod("of", int.class).invoke(null, userId);
            ok(4, "UserHandle.of(" + userId + ")");
        } catch (Throwable t) {
            fail(4, "UserHandle.of(" + userId + ")", t);
        }
        Context appContext = null;
        try {
            Method m = systemContext.getClass().getMethod("createPackageContextAsUser", String.class, int.class, UserHandle.class);
            appContext = (Context) m.invoke(systemContext, pkg, 1 | 2, uh); // CONTEXT_INCLUDE_CODE | CONTEXT_IGNORE_SECURITY
            ok(5, "createPackageContextAsUser(" + pkg + ", INCLUDE_CODE|IGNORE_SECURITY)");
        } catch (Throwable t) {
            fail(5, "createPackageContextAsUser(" + pkg + ")", t);
        }
        Object loadedApk = null;
        try {
            Field f = appContext.getClass().getDeclaredField("mPackageInfo");
            f.setAccessible(true);
            loadedApk = f.get(appContext);
            ok(6, "ContextImpl.mPackageInfo (LoadedApk) = " + loadedApk);
        } catch (Throwable t) {
            fail(6, "قراءة mPackageInfo", t);
        }
        Application app = null;
        try {
            Method mk = loadedApk.getClass().getDeclaredMethod("makeApplication", boolean.class, Instrumentation.class);
            mk.setAccessible(true);
            app = (Application) mk.invoke(loadedApk, true, null);
            ok(7, "LoadedApk.makeApplication(true, null) = " + app);
        } catch (Throwable t) {
            fail(7, "LoadedApk.makeApplication(true, null)", t);
        }
        try {
            Field ia = atClass.getDeclaredField("mInitialApplication");
            ia.setAccessible(true);
            ia.set(activityThread, app);
            ok(8, "ActivityThread.mInitialApplication = app");
        } catch (Throwable t) {
            fail(8, "تعيين mInitialApplication", t);
        }
        ClassLoader cl = null;
        try {
            cl = app.getClassLoader();
            ok(9, "ClassLoader = " + cl);
        } catch (Throwable t) {
            fail(9, "app.getClassLoader()", t);
        }
        Class<?> c = null;
        try {
            c = cl.loadClass(cls);
            ok(10, "loadClass(" + cls + ")");
        } catch (Throwable t) {
            fail(10, "loadClass(" + cls + ")", t);
        }
        try {
            Object svc;
            Constructor<?> withCtx = null;
            try {
                withCtx = c.getConstructor(Context.class);
            } catch (NoSuchMethodException ignored) {
            }
            svc = withCtx != null ? withCtx.newInstance(app) : c.newInstance();
            ok(11, "إنشاء الكائن: " + svc.getClass().getName() + " (binder=" + (svc instanceof android.os.IBinder) + ")");
        } catch (Throwable t) {
            fail(11, "إنشاء كائن الخدمة", t);
        }
        out("RESULT OK: كل خطوات بدء خدمة المستخدم نجحت يدوياً من shell");
        System.exit(0);
    }
}
