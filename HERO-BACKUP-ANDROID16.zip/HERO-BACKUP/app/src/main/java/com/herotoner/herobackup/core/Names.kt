package com.herotoner.herobackup.core

internal object Names {
    private const val MAX_COMPONENT_BYTES = 200

    fun utf8Len(s: String): Int = s.toByteArray(Charsets.UTF_8).size

    private fun truncateToBytes(s: String, maxBytes: Int): String {
        var t = s
        while (t.isNotEmpty() && utf8Len(t) > maxBytes) {
            t = if (t.length >= 2 && Character.isLowSurrogate(t.last()) && Character.isHighSurrogate(t[t.length - 2])) {
                t.dropLast(2)
            } else {
                t.dropLast(1)
            }
        }
        return t
    }

    /** يحوّل اسم مكوّن مسار إلى اسم آمن لنظام ملفات Linux (حد 255 بايت للمكوّن). */
    fun safeComponent(name: String): String {
        var n = name.replace('/', '_').replace('\u0000', '_')
        if (n.isEmpty() || n == "." || n == "..") n = "_"
        if (utf8Len(n) > MAX_COMPONENT_BYTES) {
            val dot = n.lastIndexOf('.')
            val ext = if (dot > 0 && n.length - dot <= 16) n.substring(dot) else ""
            val base = if (ext.isEmpty()) n else n.substring(0, dot)
            val h = Hashing.sha256(n.toByteArray(Charsets.UTF_8)).take(8)
            val room = MAX_COMPONENT_BYTES - 1 - 8 - utf8Len(ext)
            n = truncateToBytes(base, room) + "~" + h + ext
        }
        return n
    }

    fun uniqueRootNames(names: List<String>): List<String> {
        val seen = HashMap<String, Int>()
        return names.map { raw ->
            val base = raw.ifBlank { "مجلد" }
            val count = (seen[base] ?: 0) + 1
            seen[base] = count
            if (count == 1) base else "$base ($count)"
        }
    }

    fun uniqueStored(parts: List<String>, used: MutableSet<String>): String {
        val safe = parts.map { safeComponent(it) }
        var candidate = safe.joinToString("/")
        var n = 2
        while (!used.add(candidate)) {
            val last = safe.last()
            val dot = last.lastIndexOf('.')
            val renamed = if (dot > 0) last.substring(0, dot) + "~" + n + last.substring(dot) else "$last~$n"
            candidate = (safe.dropLast(1) + renamed).joinToString("/")
            n++
        }
        return candidate
    }
}
