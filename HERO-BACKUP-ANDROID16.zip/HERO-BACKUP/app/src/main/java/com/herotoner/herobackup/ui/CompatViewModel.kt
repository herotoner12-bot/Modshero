package com.herotoner.herobackup.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.herotoner.herobackup.core.CheckResult
import com.herotoner.herobackup.core.CompatReport
import com.herotoner.herobackup.data.SourceStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CompatViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    private val store = SourceStore(app)
    val results = MutableStateFlow<List<CheckResult>>(emptyList())
    val running = MutableStateFlow(false)
    val quick = MutableStateFlow<Quick?>(null)

    init { quickScan() }

    /** اكتشاف سريع بلا عمليات ثقيلة: الإصدار، الجهاز، Minecraft، الطرق الجاهزة. */
    fun quickScan() {
        viewModelScope.launch(Dispatchers.IO) { quick.value = runCatching { CompatChecks.quick(ctx, store) }.getOrNull() }
    }

    fun run() {
        if (running.value) return
        viewModelScope.launch(Dispatchers.IO) {
            running.value = true
            results.value = emptyList()
            try {
                CompatChecks.run(ctx, store) { r -> results.update { it + r } }
            } finally {
                running.value = false
            }
        }
    }

    fun reportText(): String {
        val v = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        return CompatReport.text(v, formatDate(System.currentTimeMillis()), results.value)
    }
}
