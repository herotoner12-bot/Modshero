package com.herotoner.herobackup.core

data class Finding(val severity: CheckStatus, val title: String, val evidence: List<String>)

/**
 * يحلّل أدلة حقيقية جُمعت أثناء محاولة تشغيل خدمة مستخدم عبر Shizuku، ويستخرج السبب المثبت بالدليل فقط.
 * الأدلة: (1) مخرجات PingMain (إعادة تنفيذ خطوات UserService.create يدوياً من shell)،
 * (2) Logcat أثناء المحاولة، (3) عينات من قائمة العمليات، (4) هل وصل الاتصال ومتى.
 * لا يُستنتج شيء بلا دليل: إن لم يوجد دليل يُقال ذلك صراحة.
 */
object ServiceStartAnalyzer {
    private val FAIL_STEP = Regex("^STEP (\\d+) FAIL: (.*)$")
    private val ANY_STEP = Regex("^(STEP \\d+ (OK|FAIL)|RESULT )")
    private val UNABLE = Regex("unable to start service", RegexOption.IGNORE_CASE)
    private val AVC = Regex("avc:\\s+denied", RegexOption.IGNORE_CASE)
    private val SERVER_START = Regex("Starting process for service record|startUserService|Start user service", RegexOption.IGNORE_CASE)
    private val SERVER_TIMEOUT = Regex("not started in \\d+ ?ms|starting timeout|Service record .* timeout", RegexOption.IGNORE_CASE)
    private val KILLED = Regex("Killing|has died|phantom|child process|process .* (was )?killed|SIGKILL", RegexOption.IGNORE_CASE)
    private val EXC = Regex("(Exception|Error)\\b")

    fun relevantLogLines(pkg: String, log: List<String>): List<String> {
        val key = Regex("shizuku|UserService|ServiceStarter|HeroPing|HeroFile|${Regex.escape(pkg)}|app_process|avc:|ClassNotFound|NoClassDef|unable to start|Killing|phantom|appComponentFactory|createPackageContext",
            RegexOption.IGNORE_CASE)
        return log.filter { key.containsMatchIn(it) }
    }

    fun analyze(
        pkg: String,
        replica: List<String>,
        logcat: List<String>,
        psSamples: List<String>,
        connectedAfterMs: Long?,
    ): List<Finding> {
        val out = ArrayList<Finding>()

        // 1) إعادة التنفيذ اليدوي: أقوى دليل لأنه يمرّ بنفس الخطوات ويطبع الاستثناء الحقيقي
        val failIdx = replica.indexOfFirst { FAIL_STEP.matches(it) }
        if (failIdx >= 0) {
            val m = FAIL_STEP.find(replica[failIdx])!!
            val block = ArrayList<String>()
            block += replica[failIdx]
            var i = failIdx + 1
            while (i < replica.size && !ANY_STEP.containsMatchIn(replica[i]) && block.size < 14) { block += replica[i]; i++ }
            out += Finding(CheckStatus.FAIL, "سبب مثبت: فشلت الخطوة ${m.groupValues[1]} (${m.groupValues[2]}) عند إعادة تنفيذ خطوات خدمة المستخدم من shell", block)
        } else if (replica.any { it.startsWith("RESULT OK") }) {
            out += Finding(CheckStatus.PASS, "خطوات بدء الخدمة (تحميل التطبيق وإنشاء الكلاس) تنجح يدوياً من shell: السبب ليس في كود التطبيق أو الـ APK", replica.filter { it.startsWith("STEP") || it.startsWith("RESULT") }.takeLast(4))
        } else if (replica.isEmpty()) {
            out += Finding(CheckStatus.WARN, "لم تُنفَّذ إعادة الخطوات اليدوية (تعذر تشغيل أوامر shell عبر Shizuku)", emptyList())
        } else {
            out += Finding(CheckStatus.WARN, "إعادة الخطوات اليدوية لم تنتهِ بنتيجة واضحة", replica.takeLast(6))
        }

        // 2) سجل عملية الخدمة نفسها
        val unable = logcat.indexOfFirst { UNABLE.containsMatchIn(it) }
        if (unable >= 0) {
            out += Finding(CheckStatus.FAIL, "سبب مثبت من Logcat: Shizuku سجّل فشل بدء الخدمة", logcat.subList(unable, minOf(logcat.size, unable + 8)))
        }

        // 3) رفض SELinux متعلق بالعملية أو التطبيق
        val avc = logcat.filter { AVC.containsMatchIn(it) && Regex("shizuku|app_process|${Regex.escape(pkg)}|shell", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        if (avc.isNotEmpty()) out += Finding(CheckStatus.FAIL, "رفض SELinux مرتبط بالمحاولة (${avc.size} سطر)", avc.take(6))

        // 4) هل حاول خادم Shizuku بدء العملية أصلاً؟
        val serverStart = logcat.filter { SERVER_START.containsMatchIn(it) }
        if (logcat.isNotEmpty()) {
            out += if (serverStart.isNotEmpty()) Finding(CheckStatus.INFO, "خادم Shizuku حاول بدء عملية الخدمة", serverStart.take(3))
            else Finding(CheckStatus.WARN, "لا أثر في Logcat لمحاولة خادم Shizuku بدء العملية (قد يحجب النظام السجل أو لم تصل الطلبية)", emptyList())
        }
        val timeout = logcat.filter { SERVER_TIMEOUT.containsMatchIn(it) }
        if (timeout.isNotEmpty()) out += Finding(CheckStatus.FAIL, "انتهت مهلة بدء الخدمة في خادم Shizuku", timeout.take(3))

        // 5) قتل العملية
        val killed = logcat.filter { KILLED.containsMatchIn(it) && it.contains(pkg) }
        if (killed.isNotEmpty()) out += Finding(CheckStatus.FAIL, "النظام قتل عملية متعلقة بالتطبيق أثناء المحاولة", killed.take(5))

        // 6) هل وُجدت عملية الخدمة؟
        val svcProc = psSamples.filter { it.contains("$pkg:") }
        if (psSamples.isNotEmpty()) {
            out += if (svcProc.isNotEmpty()) Finding(CheckStatus.INFO, "ظهرت عملية الخدمة في قائمة العمليات (تم إنشاؤها)", svcProc.take(3))
            else Finding(CheckStatus.WARN, "لم تظهر أي عملية خدمة باسم $pkg:* في العينات (العملية لم تُنشأ أو ماتت فوراً)", psSamples.takeLast(2))
        }

        // 7) أخطاء عامة بالقرب من وسوم الخدمة
        val excLines = logcat.filter { EXC.containsMatchIn(it) && Regex("HeroPing|HeroFile|UserService|ServiceStarter", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        if (excLines.isNotEmpty() && unable < 0) out += Finding(CheckStatus.FAIL, "استثناءات في سجل عملية الخدمة", excLines.take(6))

        if (connectedAfterMs != null) out += Finding(CheckStatus.PASS, "وصل onServiceConnected بعد $connectedAfterMs مللي ثانية في المحاولة الفعلية", emptyList())
        else out += Finding(CheckStatus.FAIL, "لم يصل onServiceConnected خلال مهلة الانتظار الكاملة في المحاولة الفعلية", emptyList())

        if (out.none { it.severity == CheckStatus.FAIL && it.title.startsWith("سبب مثبت") } && connectedAfterMs == null) {
            out += Finding(CheckStatus.WARN, "لا يوجد سبب مثبت بعد: لم تظهر أدلة كافية في الاختبار اليدوي ولا في السجل. أرسل السجل الكامل.", emptyList())
        }
        return out
    }
}
