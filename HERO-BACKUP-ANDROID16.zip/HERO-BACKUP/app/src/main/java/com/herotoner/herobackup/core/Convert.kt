package com.herotoner.herobackup.core

import java.io.File

sealed interface ConvertJob {
    val label: String

    data class World(val info: WorldInfo) : ConvertJob { override val label get() = info.name }
    data class Pack(val pack: PackInfo) : ConvertJob { override val label get() = pack.folderName }
    data class Addon(val pair: PackPair) : ConvertJob { override val label get() = pair.base }
}

sealed interface ConvertOutcome {
    data class Success(val manifest: Manifest) : ConvertOutcome
    data object Cancelled : ConvertOutcome
    data object NothingToDo : ConvertOutcome
    data class Failed(val code: String, val failures: List<FailureEntry>) : ConvertOutcome
}

/** يحوّل العوالم إلى .mcworld والحزم إلى .mcpack/.mcaddon ويحفظ النتيجة كنسخة في المستودع (كل عالم/مود ملف مستقل). */
class ConvertEngine(
    private val repo: BackupRepository,
    private val now: () -> Long = { System.currentTimeMillis() },
    private val bufferSize: Int = 64 * 1024,
    private val freeSpace: () -> Long = { repo.root.usableSpace },
) {
    companion object {
        fun safeFileName(name: String): String {
            var n = name.map { c -> if (c in "/\\:*?\"<>|" || c.code < 32) '_' else c }.joinToString("").trim().trimEnd('.')
            if (n.isEmpty()) n = "عالم"
            return Names.safeComponent(n).take(120)
        }
    }

    private fun estimate(job: ConvertJob): Long = when (job) {
        is ConvertJob.World -> job.info.sizeBytes
        is ConvertJob.Pack -> job.pack.sizeBytes
        is ConvertJob.Addon -> job.pair.rp.sizeBytes + job.pair.bp.sizeBytes
    }

    fun run(
        jobs: List<ConvertJob>,
        backupName: String,
        appVersion: String,
        cancel: () -> Boolean = { false },
        onProgress: (Progress) -> Unit = {},
    ): ConvertOutcome {
        if (jobs.isEmpty()) return ConvertOutcome.NothingToDo
        repo.root.mkdirs()
        val ts = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(java.util.Date(now()))
        val id = ts + "-" + Hashing.hex(kotlin.random.Random.nextBytes(4))
        val tmp = File(repo.root, BackupRepository.TMP_PREFIX + id)
        val total = jobs.sumOf { estimate(it) }
        if (freeSpace() < total) return ConvertOutcome.Failed(FailureCode.NO_SPACE, emptyList())
        try {
            val dataDir = File(tmp, BackupRepository.DATA)
            dataDir.mkdirs()
            val entries = ArrayList<FileEntry>()
            val failures = ArrayList<FailureEntry>()
            val used = HashSet<String>()
            var bytesDone = 0L
            var lastEmit = 0L
            fun emit(done: Int, cur: String, force: Boolean) {
                val t = System.nanoTime()
                if (force || t - lastEmit > 100_000_000L) { lastEmit = t; onProgress(Progress(done, jobs.size, bytesDone, total, cur)) }
            }
            jobs.forEachIndexed { idx, job ->
                if (cancel()) throw OperationCancelled()
                emit(idx, job.label, true)
                val (dir, ext) = when (job) {
                    is ConvertJob.World -> "mcworld" to "mcworld"
                    is ConvertJob.Pack -> "mcpack" to "mcpack"
                    is ConvertJob.Addon -> "mcaddon" to "mcaddon"
                }
                val baseName = when (job) {
                    is ConvertJob.World -> safeFileName(job.info.name)
                    is ConvertJob.Pack -> safeFileName(job.pack.base) + (if (job.pack.type == PackType.RESOURCE) "_RP" else if (job.pack.type == PackType.BEHAVIOR) "_BP" else "_pack")
                    is ConvertJob.Addon -> safeFileName(job.pair.base)
                }
                var stored = "$dir/$baseName.$ext"
                var n = 2
                while (!used.add(stored)) { stored = "$dir/$baseName ($n).$ext"; n++ }
                val out = File(dataDir, stored)
                try {
                    val problems = ArrayList<String>()
                    val parts: List<ZipPart> = when (job) {
                        is ConvertJob.World -> listOf(ZipPart("", job.info.node))
                        is ConvertJob.Pack -> {
                            if (!job.pack.valid) problems += job.pack.problems
                            listOf(ZipPart("", job.pack.node))
                        }
                        is ConvertJob.Addon -> {
                            problems += PackValidator.pairProblems(job.pair.rp, job.pair.bp)
                            val b = safeFileName(job.pair.base)
                            listOf(ZipPart(b + "_RP/", job.pair.rp.node), ZipPart(b + "_BP/", job.pair.bp.node))
                        }
                    }
                    if (problems.isNotEmpty()) {
                        failures += FailureEntry(job.label, FailureCode.INVALID, problems.joinToString("؛ "))
                        return@forEachIndexed
                    }
                    val built = ZipBuilder.build(out, parts, cancel, { bytesDone += it; emit(idx, job.label, false) }, bufferSize)
                    if (built.failures.isNotEmpty()) {
                        out.delete()
                        failures += FailureEntry(job.label, built.failures.first().code,
                            "تعذر قراءة ${built.failures.size} عنصر من المصدر، فلم يُنشأ أرشيف ناقص: " + built.failures.first().path + " " + built.failures.first().detail)
                        return@forEachIndexed
                    }
                    val zr = ZipVerifier.verify(out, built.files, cancel)
                    val shape = when (job) {
                        is ConvertJob.World -> McArchives.inspectWorld(out)
                        is ConvertJob.Pack -> McArchives.inspectPack(out, false)
                        is ConvertJob.Addon -> McArchives.inspectPack(out, true)
                    }
                    val all = zr.problems + shape.problems
                    if (all.isNotEmpty()) {
                        out.delete()
                        failures += FailureEntry(job.label, FailureCode.VERIFY_FAILED, all.take(5).joinToString("؛ "))
                        return@forEachIndexed
                    }
                    entries += FileEntry("$stored", stored, out.length(), Hashing.sha256(out, bufferSize, cancel), now())
                } catch (e: OperationCancelled) {
                    throw e
                } catch (e: SecurityException) {
                    out.delete(); failures += FailureEntry(job.label, FailureCode.PERMISSION_DENIED, e.message ?: "")
                } catch (e: Exception) {
                    out.delete(); failures += FailureEntry(job.label, FailureCode.IO_ERROR, e.message ?: "")
                }
            }
            emit(jobs.size, "", true)
            if (entries.isEmpty()) { tmp.deleteRecursively(); return ConvertOutcome.Failed(failures.firstOrNull()?.code ?: FailureCode.IO_ERROR, failures) }
            val manifest = Manifest(
                formatVersion = 1, id = id, name = backupName.ifBlank { id }, createdAt = now(), appVersion = appVersion,
                status = if (failures.isEmpty()) BackupStatus.COMPLETE else BackupStatus.PARTIAL,
                roots = entries.map { it.path.substringBefore('/') }.distinct(), files = entries, emptyDirs = emptyList(), failures = failures,
            )
            repo.commit(tmp, manifest)
            return ConvertOutcome.Success(manifest)
        } catch (e: OperationCancelled) {
            tmp.deleteRecursively()
            return ConvertOutcome.Cancelled
        } catch (e: Exception) {
            tmp.deleteRecursively()
            return ConvertOutcome.Failed(FailureCode.IO_ERROR, listOf(FailureEntry("", FailureCode.IO_ERROR, e.message ?: "")))
        }
    }
}
