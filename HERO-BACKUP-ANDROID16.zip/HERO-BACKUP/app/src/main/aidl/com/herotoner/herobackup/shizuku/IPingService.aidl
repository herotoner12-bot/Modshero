package com.herotoner.herobackup.shizuku;

// خدمة اختبار Binder مستقلة (Java خالصة) لا تلمس أي ملف: تفصل مشاكل تشغيل الخدمة عن مشاكل خدمة الملفات.
interface IPingService {
    void destroy() = 16777114;
    String info() = 1;
    String checkClasses() = 2;
    int apiVersion() = 3;
}
