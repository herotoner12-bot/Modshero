package com.herotoner.herobackup.shizuku;

import android.os.ParcelFileDescriptor;

// خدمة ملفات تعمل في عملية Shizuku (shell أو root). عمليات قراءة فقط: لا حذف ولا تعديل ولا كتابة.
interface IFileService {
    // مطلوبة من Shizuku لإنهاء الخدمة
    void destroy() = 16777114;

    int getUid() = 1;
    String probe(String path) = 2;
    String list(String path, int offset, int limit) = 3;
    ParcelFileDescriptor openRead(String path) = 4;
}
