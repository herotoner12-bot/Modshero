package com.herotoner.herobackup.core

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.util.concurrent.atomic.AtomicBoolean

class CoreTests {
    private val temps = ArrayList<File>()

    private fun tempDir(): File = Files.createTempDirectory("herobackup").toFile().also { temps += it }

    @After
    fun cleanup() {
        temps.forEach { it.deleteRecursively() }
        temps.clear()
    }

    private fun write(f: File, text: String) {
        f.parentFile?.mkdirs()
        f.writeText(text)
    }

    private fun repo() = BackupRepository(File(tempDir(), "backups"))

    private fun backup(repo: BackupRepository, src: File, name: String = "test"): BackupOutcome =
        BackupEngine(repo).run(listOf(SourceRoot(src.name, FileSourceNode(src))), name, "test")

    private fun success(o: BackupOutcome): Manifest {
        if (o !is BackupOutcome.Success) fail("متوقع نجاح لكن الناتج: $o")
        return (o as BackupOutcome.Success).manifest
    }

    // 1) نسخ مجلد يحتوي ملفات متعددة (ولا تُمَسّ الملفات الأصلية)
    @Test
    fun backsUpFolderWithMultipleFiles() {
        val src = File(tempDir(), "worlds")
        write(File(src, "a.txt"), "alpha")
        write(File(src, "sub/b.bin"), "bravo")
        write(File(src, "sub/deep/c.txt"), "charlie")
        val repo = repo()
        val m = success(backup(repo, src, "نسخة اختبار"))
        assertEquals(3, m.files.size)
        assertEquals(BackupStatus.COMPLETE, m.status)
        assertEquals("نسخة اختبار", m.name)
        assertEquals(5L + 5L + 7L, m.totalBytes)
        assertEquals("alpha", repo.dataFile(m.id, "worlds/a.txt").readText())
        assertEquals("charlie", repo.dataFile(m.id, "worlds/sub/deep/c.txt").readText())
        assertTrue(File(repo.dir(m.id), "manifest.json").isFile)
        // الأصل سليم
        assertEquals("alpha", File(src, "a.txt").readText())
        assertEquals(3, src.walkTopDown().filter { it.isFile }.count())
        // المانيفست يُقرأ من القرص كما هو
        assertEquals(m, repo.loadManifest(m.id))
        assertEquals(1, repo.list().size)
    }

    // 2) أسماء عربية
    @Test
    fun backsUpArabicNames() {
        val src = File(tempDir(), "عوالم ماين كرافت")
        write(File(src, "عالمي الأول.mcworld"), "world-data")
        write(File(src, "حزم الموارد/ملف ١.txt"), "pack")
        val repo = repo()
        val m = success(backup(repo, src))
        val paths = m.files.map { it.path }.toSet()
        assertTrue(paths.contains("عوالم ماين كرافت/عالمي الأول.mcworld"))
        assertTrue(paths.contains("عوالم ماين كرافت/حزم الموارد/ملف ١.txt"))
        val loaded = repo.loadManifest(m.id)!!
        assertEquals(paths, loaded.files.map { it.path }.toSet())
        val e = loaded.files.first { it.path.endsWith(".mcworld") }
        assertEquals("world-data", repo.dataFile(m.id, e.stored).readText())
    }

    // 3) ملف كبير دون تحميله كاملاً في الذاكرة
    @Test
    fun backsUpLargeFileInChunks() {
        val src = File(tempDir(), "big")
        src.mkdirs()
        val big = File(src, "huge.mcworld")
        val chunk = ByteArray(1024 * 1024) { (it * 31 + 7).toByte() }
        FileOutputStream(big).use { os -> repeat(48) { os.write(chunk) } }
        val expected = Hashing.sha256(big)
        val repo = repo()
        val m = success(backup(repo, src))
        assertEquals(48L * 1024 * 1024, m.files.single().size)
        assertEquals(expected, m.files.single().sha256)
        assertEquals(expected, Hashing.sha256(repo.dataFile(m.id, m.files.single().stored)))
    }

    // 4) استعادة نسخة
    @Test
    fun restoresBackup() {
        val src = File(tempDir(), "packs")
        write(File(src, "one.mcpack"), "1111")
        write(File(src, "dir/two.txt"), "22")
        val repo = repo()
        val m = success(backup(repo, src))
        val dest = tempDir()
        val report = RestoreEngine(repo).restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.SKIP)
        assertEquals(2, report.restored.size)
        assertTrue(report.failed.isEmpty())
        assertEquals("1111", File(dest, "packs/one.mcpack").readText())
        assertEquals("22", File(dest, "packs/dir/two.txt").readText())
    }

    // 5) اكتشاف ملف تالف + عدم استعادته
    @Test
    fun detectsCorruptedFile() {
        val src = File(tempDir(), "w")
        write(File(src, "good.txt"), "good-content")
        write(File(src, "bad.txt"), "bad-content-here")
        val repo = repo()
        val m = success(backup(repo, src))
        val bad = m.files.first { it.path.endsWith("bad.txt") }
        val stored = repo.dataFile(m.id, bad.stored)
        val bytes = stored.readBytes()
        bytes[0] = (bytes[0].toInt() xor 0x55).toByte()
        stored.writeBytes(bytes)

        val v = Verifier.verify(repo, m)!!
        assertFalse(v.ok)
        assertEquals(listOf(bad.path), v.corrupted)

        val dest = tempDir()
        val r = RestoreEngine(repo).restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.SKIP)
        assertEquals(1, r.restored.size)
        assertEquals(FailureCode.CORRUPT, r.failed.single().code)
        assertFalse(File(dest, "w/bad.txt").exists())
        assertTrue(File(dest, "w/good.txt").exists())
    }

    // 6) SHA-256
    @Test
    fun sha256IsCorrect() {
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            Hashing.sha256("abc".toByteArray()),
        )
        val src = File(tempDir(), "h")
        write(File(src, "abc.txt"), "abc")
        val m = success(backup(repo(), src))
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", m.files.single().sha256)
        assertEquals(
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            Hashing.sha256(ByteArray(0)),
        )
    }

    private class FakeNode(
        override val name: String,
        override val isDirectory: Boolean,
        private val kids: List<SourceNode> = emptyList(),
        private val data: ByteArray = ByteArray(0),
        private val openError: Exception? = null,
        private val listError: Exception? = null,
    ) : SourceNode {
        override val size: Long get() = data.size.toLong()
        override val lastModified: Long get() = 0L
        override fun children(): List<SourceNode> {
            listError?.let { throw it }
            return kids
        }

        override fun openInput(): InputStream {
            openError?.let { throw it }
            return ByteArrayInputStream(data)
        }
    }

    // 7) صلاحية URI منتهية
    @Test
    fun handlesExpiredPermission() {
        val good = FakeNode("good.txt", false, data = "ok".toByteArray())
        val expired = FakeNode("expired.txt", false, data = "x".toByteArray(), openError = SecurityException("Permission Denial"))
        val root = FakeNode("حزم", true, kids = listOf(good, expired))
        val repo = repo()
        val o = BackupEngine(repo).run(listOf(SourceRoot("حزم", root)), "n", "t")
        val m = success(o)
        assertEquals(BackupStatus.PARTIAL, m.status)
        assertEquals(1, m.files.size)
        assertEquals(FailureCode.PERMISSION_DENIED, m.failures.single().code)
        assertEquals("حزم/expired.txt", m.failures.single().path)

        // الجذر نفسه لا يمكن الوصول إليه: لا تُنشأ نسخة
        val deadRoot = FakeNode("ميت", true, listError = SecurityException("revoked"))
        val repo2 = repo()
        val o2 = BackupEngine(repo2).run(listOf(SourceRoot("ميت", deadRoot)), "n", "t")
        assertTrue(o2 is BackupOutcome.Failed)
        assertEquals(FailureCode.PERMISSION_DENIED, (o2 as BackupOutcome.Failed).code)
        assertTrue(repo2.list().isEmpty())
    }

    // 8) إلغاء النسخ بأمان
    @Test
    fun cancelLeavesNoBackup() {
        val src = File(tempDir(), "many")
        repeat(5) { write(File(src, "f$it.txt"), "data$it") }
        val repo = repo()
        val flag = AtomicBoolean(false)
        val o = BackupEngine(repo).run(
            listOf(SourceRoot("many", FileSourceNode(src))), "n", "t",
            cancel = { flag.get() },
            onProgress = { if (it.filesDone >= 1) flag.set(true) },
        )
        assertTrue(o is BackupOutcome.Cancelled)
        assertTrue(repo.list().isEmpty())
        assertEquals(0, repo.root.listFiles()?.size ?: 0)
        assertEquals(5, src.listFiles()!!.size)
    }

    // 9) عدم الكتابة فوق ملف موجود دون موافقة
    @Test
    fun neverOverwritesWithoutConsent() {
        val src = File(tempDir(), "d")
        write(File(src, "a.txt"), "new")
        val repo = repo()
        val m = success(backup(repo, src))
        val engine = RestoreEngine(repo)

        val dest = tempDir()
        write(File(dest, "d/a.txt"), "old")
        val skip = engine.restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.SKIP)
        assertEquals(1, skip.skipped.size)
        assertEquals("old", File(dest, "d/a.txt").readText())

        val renamed = engine.restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.RENAME)
        assertEquals(1, renamed.renamed.size)
        assertEquals("old", File(dest, "d/a.txt").readText())
        assertEquals("new", File(dest, "d/a (استعادة).txt").readText())

        val over = engine.restore(m, m.files, FileRestoreTarget(dest), OverwritePolicy.OVERWRITE)
        assertEquals(1, over.restored.size)
        assertEquals("new", File(dest, "d/a.txt").readText())
    }

    // 10) مجلد فارغ
    @Test
    fun emptyFolderCreatesNoBackup() {
        val src = File(tempDir(), "empty")
        src.mkdirs()
        File(src, "also-empty").mkdirs()
        val repo = repo()
        val o = backup(repo, src)
        assertTrue(o is BackupOutcome.EmptySource)
        assertTrue(repo.list().isEmpty())
        assertEquals(0, repo.root.listFiles()?.size ?: 0)
    }

    @Test
    fun incompleteBackupIsNeverListed() {
        val repo = repo()
        val tmp = File(repo.root, ".tmp-20260101-000000-aabbccdd")
        write(File(tmp, "manifest.json"), "{}")
        write(File(tmp, "data/x"), "x")
        assertTrue(repo.list().isEmpty())
        assertEquals(1, repo.incompleteCount())
        assertEquals(1, repo.cleanupIncomplete())
        assertFalse(tmp.exists())
    }

    @Test
    fun newBackupDoesNotRemoveOldOnes() {
        val src = File(tempDir(), "s")
        write(File(src, "a.txt"), "a")
        val repo = repo()
        val m1 = success(backup(repo, src, "الأولى"))
        val m2 = success(backup(repo, src, "الثانية"))
        assertTrue(m1.id != m2.id)
        assertEquals(2, repo.list().size)
    }

    @Test
    fun veryLongNamesAreHandled() {
        val longName = "م".repeat(300) + ".mcworld"
        val m = success(
            BackupEngine(repo()).run(
                listOf(
                    SourceRoot(
                        "جذر",
                        FakeNode("جذر", true, kids = listOf(FakeNode(longName, false, data = "z".toByteArray()))),
                    )
                ),
                "n", "t",
            )
        )
        val e = m.files.single()
        assertTrue(e.path.endsWith(longName))
        e.stored.split('/').forEach { assertTrue(Names.utf8Len(it) <= 255) }
        assertTrue(e.stored.endsWith(".mcworld"))
    }

    @Test
    fun exportThenImportRoundTrip() {
        val src = File(tempDir(), "world")
        write(File(src, "level.dat"), "LEVEL")
        write(File(src, "db/000001.ldb"), "LDB")
        val repo1 = repo()
        val m = success(backup(repo1, src))
        val external = tempDir()
        val ex = TransferEngine(repo1).export(m, FileRestoreTarget(external))
        assertTrue(ex.ok)
        assertTrue(TransferEngine(repo1).export(m, FileRestoreTarget(external)).alreadyExported)

        val repo2 = repo()
        val rep = TransferEngine(repo2).importFrom(FileSourceNode(external))
        assertEquals(listOf(m.id), rep.imported)
        assertEquals(m.files, repo2.loadManifest(m.id)!!.files)
        assertTrue(Verifier.verify(repo2, repo2.loadManifest(m.id)!!)!!.ok)

        // نسخة خارجية تالفة لا تُستورد
        val bad = File(external, "HERO-BACKUP/${m.id}/data/world/level.dat")
        bad.writeText("TAMPERED")
        val repo3 = repo()
        val rep3 = TransferEngine(repo3).importFrom(FileSourceNode(external))
        assertTrue(rep3.imported.isEmpty())
        assertEquals(FailureCode.CORRUPT, rep3.failed.first().code)
        assertTrue(repo3.list().isEmpty())
        assertEquals(0, repo3.root.listFiles()?.size ?: 0)
    }

    @Test
    fun classifiesMinecraftFiles() {
        assertEquals(Kind.WORLD, FileKinds.of("x/عالم.mcworld"))
        assertEquals(Kind.ADDON, FileKinds.of("a.MCADDON"))
        assertEquals(Kind.PACK, FileKinds.of("a.mcpack"))
        assertEquals(Kind.ZIP, FileKinds.of("a.zip"))
        assertEquals(Kind.WORLD, FileKinds.of("games/com.mojang/minecraftWorlds/abc/level.dat"))
        assertEquals(Kind.RESOURCE_PACK, FileKinds.of("games/com.mojang/resource_packs/p/manifest.json"))
        assertEquals(Kind.BEHAVIOR_PACK, FileKinds.of("games/com.mojang/behavior_packs/p/manifest.json"))
        assertEquals(Kind.SKIN_PACK, FileKinds.of("games/com.mojang/skin_packs/p/skins.json"))
        assertEquals(Kind.OTHER, FileKinds.of("notes.txt"))
        assertTrue(FileKinds.isImportable("a.mcworld"))
        assertFalse(FileKinds.isImportable("a.zip"))
    }

    @Test
    fun jsonRoundTripKeepsSpecialCharacters() {
        val text = "سطر \"مقتبس\" \\ \n\t وحرف تحكم \u0001 😀"
        val back = Json.parseObject(Json.stringify(mapOf("k" to text, "n" to 12345678901L, "l" to listOf(1, 2))))
        assertEquals(text, back["k"])
        assertEquals(12345678901L, (back["n"] as Number).toLong())
        assertNotNull(back["l"])
    }

    @Test
    fun ioErrorOnOneFileDoesNotStopOthers() {
        val bad = FakeNode("bad", false, openError = IOException("boom"))
        val ok = FakeNode("ok", false, data = "fine".toByteArray())
        val m = success(
            BackupEngine(repo()).run(listOf(SourceRoot("r", FakeNode("r", true, kids = listOf(bad, ok)))), "n", "t")
        )
        assertEquals(1, m.files.size)
        assertEquals(FailureCode.IO_ERROR, m.failures.single().code)
    }
}
