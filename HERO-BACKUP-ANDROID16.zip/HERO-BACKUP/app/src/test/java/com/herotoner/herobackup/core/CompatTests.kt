package com.herotoner.herobackup.core

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files

class CompatTests {
    private val temps = ArrayList<File>()
    private fun tempDir(): File = Files.createTempDirectory("hbc").toFile().also { temps += it }

    @After
    fun cleanup() { temps.forEach { it.deleteRecursively() }; temps.clear() }

    private class Node(
        override val name: String, override val isDirectory: Boolean,
        private val kids: List<SourceNode> = emptyList(), private val err: Exception? = null,
    ) : SourceNode {
        override val size = 0L
        override val lastModified = 0L
        override fun children(): List<SourceNode> { err?.let { throw it }; return kids }
        override fun openInput(): InputStream = ByteArrayInputStream(ByteArray(0))
    }

    private class Prov(
        override val method: AccessMethod,
        val pre: Precheck = Precheck(true, true, ""),
        val nodes: List<Pair<String, SourceNode>> = emptyList(),
    ) : AccessProvider {
        var called = 0
        override fun precheck() = pre
        override fun candidates(paths: List<String>): List<Pair<String, SourceNode>> { called++; return nodes }
    }

    private fun mojang() = Node("com.mojang", true, listOf(Node("minecraftWorlds", true), Node("resource_packs", true)))

    // ---------- الإصدارات والشركات ----------
    @Test
    fun apiSupportAndNames() {
        assertEquals("Android 8.0", ApiSupport.androidName(26))
        assertEquals("Android 16", ApiSupport.androidName(36))
        assertEquals("Android 9", ApiSupport.androidName(28))
        assertFalse(ApiSupport.supported(25))
        assertTrue(ApiSupport.supported(26))
        assertEquals(DirectFilesKind.LEGACY_PERMISSION, ApiSupport.directFilesKind(26))
        assertEquals(DirectFilesKind.LEGACY_PERMISSION, ApiSupport.directFilesKind(28))
        assertEquals(DirectFilesKind.NONE, ApiSupport.directFilesKind(29))
        assertEquals(DirectFilesKind.ALL_FILES, ApiSupport.directFilesKind(30))
        assertEquals(DirectFilesKind.ALL_FILES, ApiSupport.directFilesKind(36))
        assertTrue(ApiSupport.safMayReachAndroidData(29))
        assertFalse(ApiSupport.safMayReachAndroidData(30))
    }

    @Test
    fun detectsOemFamilies() {
        assertEquals(OemFamily.XIAOMI, Oem.detect("Xiaomi", "POCO"))
        assertEquals(OemFamily.XIAOMI, Oem.detect("Xiaomi", "Redmi"))
        assertEquals(OemFamily.XIAOMI, Oem.detect("Xiaomi", "poco"))
        assertEquals(OemFamily.SAMSUNG, Oem.detect("samsung", "samsung"))
        assertEquals(OemFamily.OPPO, Oem.detect("OPPO", "OPPO"))
        assertEquals(OemFamily.OPPO, Oem.detect("realme", "realme"))
        assertEquals(OemFamily.OPPO, Oem.detect("OnePlus", "OnePlus"))
        assertEquals(OemFamily.GOOGLE, Oem.detect("Google", "google"))
        assertEquals(OemFamily.MOTOROLA, Oem.detect("motorola", "motorola"))
        assertEquals(OemFamily.TRANSSION, Oem.detect("TECNO", "TECNO"))
        assertEquals(OemFamily.TRANSSION, Oem.detect("INFINIX", "Infinix"))
        assertEquals(OemFamily.TRANSSION, Oem.detect("Transsion Holdings", "itel"))
        assertEquals(OemFamily.OTHER, Oem.detect("Sony", "sony"))
        assertEquals(OemFamily.OTHER, Oem.detect(null, null))
    }

    // ---------- مسارات Minecraft ----------
    @Test
    fun minecraftPathsAreNotHardcodedToOneLocation() {
        val roots = MinecraftPaths.roots(10)
        assertEquals("/storage/emulated/10", roots[0])
        assertTrue(roots.contains("/storage/emulated/0"))
        assertTrue(roots.contains("/sdcard"))
        val c = MinecraftPaths.candidates(listOf("com.mojang.minecraftpe", "com.mojang.minecraftpe.preview"), roots)
        assertTrue(c.contains("/storage/emulated/10/Android/data/com.mojang.minecraftpe/files/games/com.mojang"))
        assertTrue(c.contains("/storage/emulated/0/Android/data/com.mojang.minecraftpe.preview/files/games/com.mojang"))
        assertTrue(c.contains("/sdcard/games/com.mojang"))
        assertEquals(c.size, c.toSet().size)
        assertEquals(MinecraftPaths.roots(0).size, MinecraftPaths.roots(0).toSet().size)
    }

    @Test
    fun layoutDetection() {
        assertTrue(MinecraftLayout.looksLikeMojang(listOf("minecraftWorlds", "x")))
        assertTrue(MinecraftLayout.looksLikeMojang(listOf("behavior_packs")))
        assertFalse(MinecraftLayout.looksLikeMojang(listOf("Download", "DCIM")))
        assertFalse(MinecraftLayout.looksLikeMojang(emptyList()))
        val li = LayoutInfo(listOf("minecraftWorlds", "development_behavior_packs"))
        assertTrue(li.hasWorlds); assertTrue(li.hasBehaviorPacks); assertFalse(li.hasResourcePacks)
    }

    // ---------- كل طريقة وصول وحدها ----------
    @Test
    fun directFilesProviderFindsRealMojangFolder() {
        val base = tempDir()
        val mojang = File(base, "Android/data/com.mojang.minecraftpe/files/games/com.mojang")
        File(mojang, "minecraftWorlds").mkdirs(); File(mojang, "resource_packs").mkdirs()
        val p = DirectFilesProvider({ true to "" })
        val r = StorageEngine.discover(listOf(p), listOf(File(base, "nope").path, mojang.path))
        assertNotNull(r.found)
        assertEquals(AccessMethod.FILES, r.found!!.method)
        assertTrue(r.found!!.layout.hasWorlds)
        assertFalse(r.useOfficial)
        assertEquals(AttemptResult.MISSING, r.attempts[0].result) // المسار الأول غير موجود
        assertEquals(AttemptResult.FOUND, r.attempts.last().result)
    }

    @Test
    fun directFilesProviderRejectsNonMinecraftFolders() {
        val d = tempDir(); File(d, "Download").mkdirs(); File(d, "DCIM").mkdirs()
        val r = StorageEngine.discover(listOf(DirectFilesProvider({ true to "" })), listOf(d.path))
        assertTrue(r.found == null)
        assertEquals(AttemptResult.NOT_MINECRAFT, r.attempts.single().result)
        assertTrue(r.useOfficial)
        val empty = tempDir()
        val r2 = StorageEngine.discover(listOf(DirectFilesProvider({ true to "" })), listOf(empty.path))
        assertEquals("المجلد فارغ", r2.attempts.single().detail)
    }

    @Test
    fun directFilesProviderHonoursMissingPermissionAndUnavailable() {
        val d = tempDir()
        val notGranted = StorageEngine.discover(listOf(DirectFilesProvider({ false to "الصلاحية غير ممنوحة" })), listOf(d.path))
        assertEquals(AttemptResult.NOT_READY, notGranted.attempts.single().result)
        assertEquals("الصلاحية غير ممنوحة", notGranted.attempts.single().detail)
        val unavailable = StorageEngine.discover(listOf(DirectFilesProvider({ true to "" }, available = false)), listOf(d.path))
        assertEquals(AttemptResult.UNAVAILABLE, unavailable.attempts.single().result)
        assertTrue(unavailable.useOfficial)
    }

    @Test
    fun shizukuStyleDeniedIsClassifiedNotFatal() {
        val denied = Prov(AccessMethod.SHIZUKU, nodes = listOf("/x" to Node("x", true, err = SecurityException("EACCES"))))
        val r = StorageEngine.discover(listOf(denied), listOf("/x"))
        assertEquals(AttemptResult.DENIED, r.attempts.single().result)
        assertTrue(r.useOfficial)
    }

    @Test
    fun safStyleProviderWithUserTree() {
        val saf = Prov(AccessMethod.SAF, nodes = listOf("شجرة SAF" to mojang()))
        val r = StorageEngine.discover(listOf(saf), emptyList())
        assertEquals(AccessMethod.SAF, r.found!!.method)
        assertEquals("شجرة SAF", r.found!!.label)
    }

    // ---------- الترتيب والرجوع للبديل ----------
    @Test
    fun triesMethodsInOrderAndFallsBack() {
        val saf = Prov(AccessMethod.SAF, nodes = listOf("saf" to Node("t", true, err = SecurityException("blocked"))))
        val files = Prov(AccessMethod.FILES, Precheck(true, false, "لا صلاحية"))
        val shz = Prov(AccessMethod.SHIZUKU, nodes = listOf("/p" to mojang()))
        // نمرّرها بترتيب مقلوب: المحرك يرتّبها بنفسه
        val r = StorageEngine.discover(listOf(shz, files, saf), listOf("/p"))
        assertEquals(AccessMethod.SHIZUKU, r.found!!.method)
        assertEquals(listOf(AccessMethod.SAF, AccessMethod.FILES, AccessMethod.SHIZUKU), r.attempts.map { it.method })
        assertEquals(AttemptResult.DENIED, r.attempts[0].result)
        assertEquals(AttemptResult.NOT_READY, r.attempts[1].result)
        assertEquals(AttemptResult.FOUND, r.attempts[2].result)
    }

    @Test
    fun stopsAtFirstSuccessAndDoesNotTouchLaterMethods() {
        val saf = Prov(AccessMethod.SAF, nodes = listOf("saf" to mojang()))
        val shz = Prov(AccessMethod.SHIZUKU, nodes = listOf("/p" to mojang()))
        val r = StorageEngine.discover(listOf(saf, shz), listOf("/p"))
        assertEquals(AccessMethod.SAF, r.found!!.method)
        assertEquals(0, shz.called)
    }

    @Test
    fun fallsBackToOfficialWhenAllMethodsFail() {
        val saf = Prov(AccessMethod.SAF, Precheck(true, false, "لم تختر مجلداً"))
        val files = Prov(AccessMethod.FILES, nodes = listOf("/a" to Node("a", true, err = FileNotFoundException("محجوب"))))
        val shz = Prov(AccessMethod.SHIZUKU, Precheck(false, false, "Shizuku غير مثبّت"))
        val r = StorageEngine.discover(listOf(saf, files, shz), listOf("/a"))
        assertTrue(r.found == null)
        assertTrue(r.useOfficial)
        assertEquals(
            listOf(AttemptResult.NOT_READY, AttemptResult.MISSING, AttemptResult.UNAVAILABLE),
            r.attempts.map { it.result },
        )
    }

    @Test
    fun missingProvidersAreSkippedAndErrorsContained() {
        val boom = Prov(AccessMethod.FILES, nodes = listOf("/b" to Node("b", true, err = IOException("io"))))
        val r = StorageEngine.discover(listOf(boom), listOf("/b"))
        assertEquals(AttemptResult.ERROR, r.attempts.single().result)
        assertTrue(StorageEngine.discover(emptyList(), emptyList()).useOfficial)
    }

    @Test
    fun cancellationStopsDiscovery() {
        var thrown = false
        try {
            StorageEngine.discover(listOf(Prov(AccessMethod.SAF, nodes = listOf("s" to mojang()))), emptyList(), cancel = { true })
        } catch (e: OperationCancelled) { thrown = true }
        assertTrue(thrown)
    }

    // ---------- التقرير ----------
    @Test
    fun reportContainsEveryResultClearly() {
        val rs = listOf(
            CheckResult("الجهاز", "إصدار Android", CheckStatus.PASS, "Android 16"),
            CheckResult("الوصول", "Shizuku", CheckStatus.FAIL, "غير مثبّت\nسطر ثانٍ"),
            CheckResult("الوصول", "SAF", CheckStatus.SKIP, ""),
        )
        val t = CompatReport.text("3.0.0", "2026-11-11", rs)
        assertTrue(t.contains("HERO BACKUP 3.0.0"))
        assertTrue(t.contains("[نجح] إصدار Android — Android 16"))
        assertTrue(t.contains("[فشل] Shizuku — غير مثبّت | سطر ثانٍ"))
        assertTrue(t.contains("[لم يُختبر] SAF"))
        assertEquals(2, Regex("## ").findAll(t).count())
    }

    @Test
    fun fileSourceNodeClassifiesErrors() {
        val missing = FileSourceNode(File(tempDir(), "ghost"))
        var cls = ""
        try { missing.children() } catch (e: FileNotFoundException) { cls = "missing" }
        assertEquals("missing", cls)
    }

    // ---------- التشخيص ----------
    @Test
    fun errorInfoShowsRealExceptionAndCause() {
        val t = IllegalStateException("EACCES: Permission denied", java.io.IOException("root cause"))
        val d = ErrorInfo.describe(t, frames = 2)
        assertTrue(d.startsWith("java.lang.IllegalStateException: EACCES: Permission denied"))
        assertTrue(d.contains("caused by java.io.IOException: root cause"))
        assertEquals(2, Regex("\n  at ").findAll(d).count())
        assertTrue(ErrorInfo.describe(RuntimeException(), 0).startsWith("java.lang.RuntimeException"))
    }

    @Test
    fun traceLogKeepsOrderAndEvictsOldest() {
        var now = 0L
        val log = TraceLog(3) { now += 1000; now }
        log.add("BIND", "first-entry"); log.add("CONNECT", "two"); log.add("READY", "three"); log.add("DEATH", "four", RuntimeException("boom"))
        val lines = log.lines()
        assertEquals(3, lines.size)
        assertTrue(lines[0].contains("[CONNECT] two"))
        assertTrue(lines[2].contains("[DEATH] four") && lines[2].contains("java.lang.RuntimeException: boom"))
        assertFalse(lines.any { it.contains("first-entry") })
        log.clear()
        assertTrue(log.lines().isEmpty())
    }

    // ---------- محلل أسباب فشل بدء خدمة المستخدم ----------
    private val pkg = "com.herotoner.herobackup"

    @Test
    fun analyzerReportsProvenFailureStepFromReplica() {
        val replica = listOf(
            "STEP 0 OK: main بدأ",
            "STEP 5 OK: createPackageContextAsUser(x)",
            "STEP 7 FAIL: LoadedApk.makeApplication(true, null)",
            "  java.lang.NoClassDefFoundError: Failed resolution of: Landroidx/core/app/CoreComponentFactory;",
            "  at android.app.Instrumentation.newApplication(Instrumentation.java:1)",
        )
        val f = ServiceStartAnalyzer.analyze(pkg, replica, emptyList(), emptyList(), null)
        val proven = f.first { it.title.startsWith("سبب مثبت") }
        assertEquals(CheckStatus.FAIL, proven.severity)
        assertTrue(proven.title.contains("الخطوة 7"))
        assertTrue(proven.evidence.any { it.contains("NoClassDefFoundError") })
    }

    @Test
    fun analyzerUsesLogcatWhenReplicaPasses() {
        val replica = listOf("STEP 0 OK: x", "RESULT OK: كل خطوات بدء خدمة المستخدم نجحت يدوياً من shell")
        val log = listOf(
            "11-12 10:00:00.100 1234 1250 I ShizukuServer: Starting process for service record $pkg:hero-ping",
            "11-12 10:00:01.000 4000 4000 W UserService: unable to start service $pkg/com.herotoner.herobackup.shizuku.PingService",
            "11-12 10:00:01.001 4000 4000 W UserService: java.lang.SecurityException: boom",
            "11-12 10:00:01.500 1000 1000 E audit: avc:  denied  { read } for comm=\"app_process\" scontext=u:r:shell:s0",
        )
        val f = ServiceStartAnalyzer.analyze(pkg, replica, log, emptyList(), null)
        assertTrue(f.any { it.severity == CheckStatus.PASS && it.title.contains("تنجح يدوياً") })
        val unable = f.first { it.title.contains("Logcat") }
        assertTrue(unable.evidence.first().contains("unable to start service"))
        assertTrue(f.any { it.title.startsWith("رفض SELinux") })
        assertTrue(f.any { it.title.contains("حاول بدء عملية الخدمة") })
    }

    @Test
    fun analyzerSaysNoProvenCauseWhenNoEvidence() {
        val f = ServiceStartAnalyzer.analyze(pkg, listOf("STEP 0 OK"), listOf("I something unrelated"), emptyList(), null)
        assertFalse(f.any { it.title.startsWith("سبب مثبت") })
        assertTrue(f.any { it.title.startsWith("لا يوجد سبب مثبت") })
    }

    @Test
    fun analyzerDetectsProcessAndConnection() {
        val ps = listOf("t=3s | shell 5000 1 0 0 S $pkg:hero-ping")
        val f = ServiceStartAnalyzer.analyze(pkg, listOf("RESULT OK"), emptyList(), ps, 4200)
        assertTrue(f.any { it.title.contains("تم إنشاؤها") })
        assertTrue(f.any { it.title.contains("4200") })
        assertFalse(f.any { it.title.startsWith("لا يوجد سبب مثبت") })
        val none = ServiceStartAnalyzer.analyze(pkg, listOf("RESULT OK"), emptyList(), listOf("t=3s | u0_a1 9 1 0 0 S $pkg"), null)
        assertTrue(none.any { it.title.contains("لم تظهر أي عملية خدمة") })
    }

    @Test
    fun relevantLogFilterKeepsOnlyUsefulLines() {
        val log = listOf("I Foo: nothing", "I ShizukuServer: x", "E AndroidRuntime: boom in $pkg", "D unrelated")
        assertEquals(2, ServiceStartAnalyzer.relevantLogLines(pkg, log).size)
    }
}
