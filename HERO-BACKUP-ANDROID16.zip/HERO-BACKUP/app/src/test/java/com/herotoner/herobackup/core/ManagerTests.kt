package com.herotoner.herobackup.core

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.nio.file.Files
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import java.util.zip.ZipEntry

class ManagerTests {
    private val temps = ArrayList<File>()
    private fun tempDir(): File = Files.createTempDirectory("hbm").toFile().also { temps += it }

    @After
    fun cleanup() { temps.forEach { it.deleteRecursively() }; temps.clear() }

    private fun repo() = BackupRepository(File(tempDir(), "backups"))
    private fun rnd(n: Int, seed: Int) = ByteArray(n) { ((it * 31 + seed) % 251).toByte() }
    private fun w(f: File, bytes: ByteArray) { f.parentFile?.mkdirs(); f.writeBytes(bytes) }
    private fun w(f: File, text: String) = w(f, text.toByteArray())

    private fun makeWorld(dir: File, levelName: String?, seed: Int = 1, arabicFile: Boolean = false): File {
        w(File(dir, "level.dat"), rnd(500, seed))
        if (levelName != null) w(File(dir, "levelname.txt"), levelName)
        w(File(dir, "db/CURRENT"), "MANIFEST-000001\n")
        w(File(dir, "db/MANIFEST-000001"), rnd(300, seed + 1))
        w(File(dir, "db/000003.log"), rnd(2000, seed + 2))
        w(File(dir, "db/000005.ldb"), rnd(100_000, seed + 3))
        w(File(dir, "world_icon.jpeg"), rnd(1500, seed + 4))
        File(dir, "empty_dir").mkdirs()
        if (arabicFile) w(File(dir, "ملفات/خريطة العالم.txt"), "بيانات عربية")
        return dir
    }

    private val U1 = "11111111-1111-4111-8111-111111111111"
    private val U2 = "22222222-2222-4222-8222-222222222222"
    private val U3 = "33333333-3333-4333-8333-333333333333"
    private val U4 = "44444444-4444-4444-8444-444444444444"
    private val U5 = "55555555-5555-4555-8555-555555555555"
    private val U6 = "66666666-6666-4666-8666-666666666666"

    private fun manifestJson(
        name: String, uuid: String, module: String, moduleUuid: String, ver: String = "[1, 0, 0]",
        deps: String = "", extra: String = "",
    ) = """{
  "format_version": 2,
  "header": { "name": "$name", "description": "d", "uuid": "$uuid", "version": $ver, "min_engine_version": [1, 20, 0] },
  "modules": [ { "type": "$module", "uuid": "$moduleUuid", "version": [1, 0, 0] } ]$deps$extra
}"""

    private fun depsJson(vararg d: Pair<String, String>) =
        ",\n  \"dependencies\": [" + d.joinToString(",") { "{ \"uuid\": \"${it.first}\", \"version\": ${it.second} }" } + "]"

    private fun makePack(dir: File, manifest: String, withFiles: Boolean = true): File {
        w(File(dir, "manifest.json"), manifest)
        if (withFiles) {
            w(File(dir, "textures/blocks/stone.png"), rnd(3000, dir.name.length))
            w(File(dir, "texts/ar_SA.lang"), "pack.name=مود")
        }
        return dir
    }

    private fun root(dir: File) = listOf(SourceRoot(dir.name, FileSourceNode(dir)))

    // ---------- اكتشاف العوالم ----------
    @Test
    fun discoversOnlyRealWorlds() {
        val base = File(tempDir(), "com.mojang")
        makeWorld(File(base, "minecraftWorlds/abc111"), "عالم البقاء", 1, true)
        makeWorld(File(base, "minecraftWorlds/abc222"), null, 2)
        File(base, "minecraftWorlds/junk").mkdirs(); w(File(base, "minecraftWorlds/junk/readme.txt"), "x")
        w(File(base, "minecraftWorlds/leveldat_only/level.dat"), "x")
        makeWorld(File(base, "minecraftWorlds/nodb"), "x"); File(base, "minecraftWorlds/nodb/db").deleteRecursively()
        File(base, "minecraftWorlds/baddb/db").mkdirs(); w(File(base, "minecraftWorlds/baddb/level.dat"), "x"); w(File(base, "minecraftWorlds/baddb/db/000003.log"), "x")
        w(File(base, "minecraftWorlds/dbonly/db/CURRENT"), "MANIFEST-1")
        val r = WorldScanner.scan(root(base))
        assertEquals(2, r.worlds.size)
        assertEquals(setOf("عالم البقاء", "abc222"), r.worlds.map { it.name }.toSet())
        assertEquals(3, r.incomplete.size)
        assertTrue(r.worlds.all { it.sizeBytes > 100_000 && it.fileCount >= 6 && it.lastModified > 0 })
        assertFalse(r.worlds.any { it.folderName == "junk" || it.folderName == "dbonly" })
    }

    @Test
    fun worldScanReportsUnreadableFolders() {
        val bad = FNode("minecraftWorlds", true, kids = listOf(FNode("locked", true, listError = SecurityException("EACCES"))))
        val r = WorldScanner.scan(listOf(SourceRoot("mojang", bad)))
        assertTrue(r.worlds.isEmpty())
        assertEquals(FailureCode.PERMISSION_DENIED, r.failures.single().code)
    }

    // ---------- MCWORLD ----------
    @Test
    fun convertsWorldToMcworldWithoutWrapperFolder() {
        val base = File(tempDir(), "mojang")
        val wd = makeWorld(File(base, "minecraftWorlds/x1"), "عالمي", 7, true)
        val before = wd.walkTopDown().filter { it.isFile }.associate { it.relativeTo(wd).path to Hashing.sha256(it) }
        val world = WorldScanner.scan(root(base)).worlds.single()
        val repo = repo()
        val out = ConvertEngine(repo).run(listOf(ConvertJob.World(world)), "عوالم", "t")
        assertTrue(out is ConvertOutcome.Success)
        val m = (out as ConvertOutcome.Success).manifest
        assertEquals(1, m.files.size)
        assertEquals("mcworld/عالمي.mcworld", m.files[0].path)
        val file = repo.dataFile(m.id, m.files[0].stored)
        assertEquals(m.files[0].sha256, Hashing.sha256(file))
        ZipFile(file, Charsets.UTF_8).use { zf ->
            val names = zf.entries().asSequence().map { it.name }.toList()
            assertTrue(names.contains("level.dat"))
            assertTrue(names.contains("db/CURRENT"))
            assertTrue(names.contains("empty_dir/"))
            assertTrue(names.contains("ملفات/خريطة العالم.txt"))
            assertFalse(names.any { it.startsWith("x1/") })
            for ((rel, h) in before) {
                val e = zf.getEntry(rel.replace('\\', '/'))
                assertNotNull(rel, e)
                assertEquals(h, Hashing.hex(java.security.MessageDigest.getInstance("SHA-256").digest(zf.getInputStream(e).readBytes())))
            }
        }
        assertTrue(McArchives.inspectWorld(file).ok)
        assertEquals("عالمي", McArchives.inspectWorld(file).levelName)
        // الأصل لم يتغير
        val after = wd.walkTopDown().filter { it.isFile }.associate { it.relativeTo(wd).path to Hashing.sha256(it) }
        assertEquals(before, after)
        assertTrue(File(wd, "empty_dir").isDirectory)
    }

    @Test
    fun zipVerifierDetectsCorruption() {
        val src = File(tempDir(), "s"); w(File(src, "a.bin"), rnd(50_000, 3)); w(File(src, "b.txt"), "hello")
        val out = File(tempDir(), "o.zip")
        val built = ZipBuilder.build(out, listOf(ZipPart("", FileSourceNode(src))))
        assertTrue(ZipVerifier.verify(out, built.files).ok)
        val bytes = out.readBytes()
        bytes[bytes.size / 3] = (bytes[bytes.size / 3].toInt() xor 0x7F).toByte()
        out.writeBytes(bytes)
        assertFalse(ZipVerifier.verify(out, built.files).ok)
        // ملف مفقود/زائد
        val built2 = ZipBuilder.build(File(tempDir(), "o2.zip"), listOf(ZipPart("", FileSourceNode(src))))
        val wrong = built2.files + ("ghost.txt" to ZipEntryInfo(1, "00"))
        assertTrue(ZipVerifier.verify(File(temps.last(), "o2.zip"), wrong).problems.any { it.contains("ghost.txt") })
    }

    @Test
    fun failedSourceReadProducesNoPartialMcworld() {
        val good = FNode("level.dat", false, data = rnd(10, 1))
        val db = FNode("db", true, kids = listOf(
            FNode("CURRENT", false, data = "M".toByteArray()),
            FNode("MANIFEST-000001", false, data = rnd(5, 2)),
            FNode("000003.ldb", false, openError = SecurityException("Permission denied")),
        ))
        val world = WorldInfo("r/w", "w", "w", "r", FNode("w", true, kids = listOf(good, db)), 100, 4, 1)
        val repo = repo()
        val out = ConvertEngine(repo).run(listOf(ConvertJob.World(world)), "n", "t")
        assertTrue(out is ConvertOutcome.Failed)
        assertEquals(FailureCode.PERMISSION_DENIED, (out as ConvertOutcome.Failed).failures.single().code)
        assertTrue(repo.list().isEmpty())
        assertEquals(0, repo.root.listFiles()?.size ?: 0)
    }

    // ---------- manifest و UUID ----------
    @Test
    fun parsesManifestVariants() {
        val ok = PackManifestParser.parse(manifestJson("RP", U1, "resources", U2))
        assertNotNull(ok.manifest); assertEquals(PackType.RESOURCE, ok.manifest!!.type)
        val bp = PackManifestParser.parse(manifestJson("BP", U3, "data", U4, "\"1.2.3\""))
        assertEquals(PackType.BEHAVIOR, bp.manifest!!.type); assertEquals(listOf(1, 2, 3), bp.manifest!!.version)
        val scripted = PackManifestParser.parse(manifestJson("S", U5, "script", U6))
        assertEquals(PackType.BEHAVIOR, scripted.manifest!!.type)
        // BOM + تعليقات + فاصلة زائدة
        val messy = "\uFEFF// تعليق\n/* كتلة */" + manifestJson("RP", U1, "resources", U2)
            .replace("\"description\": \"d\"", "\"description\": \"d // ليس تعليقاً\"")
            .replace("[1, 0, 0] } ]", "[1, 0, 0] }, ]")
        val m = PackManifestParser.parse(messy)
        assertNotNull(m.problems.joinToString(), m.manifest)
        assertEquals(PackType.RESOURCE, m.manifest!!.type)
    }

    @Test
    fun rejectsInvalidManifests() {
        assertNull2(PackManifestParser.parse("{ not json").manifest)
        assertTrue(PackManifestParser.parse(manifestJson("X", "not-a-uuid", "resources", U2)).problems.any { it.contains("UUID") })
        assertTrue(PackManifestParser.parse(manifestJson("X", U1, "resources", U1)).problems.any { it.contains("مكرر") })
        assertTrue(PackManifestParser.parse(manifestJson("X", U1, "resources", U2, "[1,0]")).problems.any { it.contains("نسخة") })
        assertNull2(PackManifestParser.parse("""{"format_version":2,"modules":[]}""").manifest)
        assertTrue(PackManifestParser.parse(manifestJson("X", U1, "resources", U2, deps = depsJson(U1 to "[1,0,0]"))).problems.any { it.contains("تعتمد على نفسها") })
    }

    private fun assertNull2(a: Any?) = assertTrue(a == null)

    @Test
    fun versionsCompare() {
        assertTrue(Versions.compare(listOf(1, 2, 0), listOf(1, 10, 0)) < 0)
        assertEquals(0, Versions.compare(listOf(1, 0, 0), listOf(1, 0, 0)))
        assertEquals(listOf(1, 20, 3), Versions.parse("1.20.3-beta"))
    }

    // ---------- أسماء RP/RB/BP ----------
    @Test
    fun stripsPackSuffixes() {
        assertEquals("MyMod", PackNames.baseName("MyMod.rp"))
        assertEquals("MyMod", PackNames.baseName("MyMod.rb"))
        assertEquals("MyMod", PackNames.baseName("MyMod_BP"))
        assertEquals("MyMod", PackNames.baseName("MyMod RP"))
        assertEquals("MyMod", PackNames.baseName("MyMod-bp"))
        assertEquals("MyMod", PackNames.baseName("MyMod (RP)"))
        assertEquals("Group", PackNames.baseName("Group")) // لا يُقتطع rp من كلمة
        assertEquals("مودات", PackNames.baseName("مودات.rp"))
        assertEquals(PackType.RESOURCE, PackNames.suffixOf("x.RP"))
        assertEquals(PackType.BEHAVIOR, PackNames.suffixOf("x.rb"))
        assertEquals(null, PackNames.suffixOf("Group"))
    }

    // ---------- اكتشاف ومطابقة الحزم ----------
    private fun modsTree(): File {
        val base = File(tempDir(), "com.mojang")
        makePack(File(base, "resource_packs/MyMod.rp"), manifestJson("MyMod RP", U1, "resources", U2))
        makePack(File(base, "behavior_packs/MyMod.rb"), manifestJson("MyMod BP", U3, "data", U4, deps = depsJson(U1 to "[1,0,0]")))
        makePack(File(base, "resource_packs/Solo.rp"), manifestJson("Solo", "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", "resources", "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaab"))
        makePack(File(base, "behavior_packs/Lonely.bp"), manifestJson("Lonely", "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", "data", "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbc"))
        makePack(File(base, "resource_packs/Broken.rp"), "{ broken")
        makePack(File(base, "resource_packs/Wrong.rp"), manifestJson("Wrong", "cccccccc-cccc-4ccc-8ccc-cccccccccccc", "data", "cccccccc-cccc-4ccc-8ccc-cccccccccccd"))
        // عالم يحتوي حزماً داخله: لا تُحسب
        makeWorld(File(base, "minecraftWorlds/w"), "w")
        makePack(File(base, "minecraftWorlds/w/behavior_packs/inside"), manifestJson("Inside", "dddddddd-dddd-4ddd-8ddd-dddddddddddd", "data", "dddddddd-dddd-4ddd-8ddd-ddddddddddde"))
        return base
    }

    @Test
    fun scansAndMatchesPacks() {
        val scan = PackScanner.scan(root(modsTree()))
        assertEquals(6, scan.packs.size) // المجلد داخل العالم مُستبعد
        val mr = PackMatcher.match(scan.packs)
        assertEquals(1, mr.pairs.size)
        val p = mr.pairs[0]
        assertEquals("MyMod", p.base)
        assertEquals(Confidence.NAME_AND_DEPENDENCY, p.confidence)
        assertEquals(listOf("Solo.rp"), mr.rpOnly.map { it.folderName })
        assertEquals(listOf("Lonely.bp"), mr.bpOnly.map { it.folderName })
        val bad = mr.unmatched.map { it.pack.folderName }.toSet()
        assertEquals(setOf("Broken.rp", "Wrong.rp"), bad)
        assertTrue(mr.unmatched.first { it.pack.folderName == "Wrong.rp" }.reason.contains("BP"))
    }

    @Test
    fun doesNotMergeDifferentPacksByMistake() {
        val base = File(tempDir(), "m")
        // الاسم متطابق لكن BP يعتمد على RP آخر
        makePack(File(base, "A.rp"), manifestJson("A", U1, "resources", U2))
        makePack(File(base, "A.bp"), manifestJson("A", U3, "data", U4, deps = depsJson(U5 to "[1,0,0]")))
        makePack(File(base, "Other.rp"), manifestJson("Other", U5, "resources", U6))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertFalse(mr.pairs.any { it.base == "A" })
        assertTrue(mr.unmatched.any { it.pack.folderName == "A.rp" })
        assertTrue(mr.unmatched.any { it.pack.folderName == "A.bp" })
        // بالمقابل: Other.rp و A.bp يتطابقان بالاعتمادية رغم اختلاف الاسم؟ لا: A.bp حُظر بسبب التعارض
        assertEquals(0, mr.pairs.size)
    }

    @Test
    fun ambiguousDuplicateNamesAreNotMerged() {
        val base = File(tempDir(), "m")
        makePack(File(base, "x/Dup.rp"), manifestJson("D1", U1, "resources", U2))
        makePack(File(base, "y/Dup.rp"), manifestJson("D2", U3, "resources", U4))
        makePack(File(base, "z/Dup.bp"), manifestJson("D3", U5, "data", U6))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertEquals(0, mr.pairs.size)
        assertEquals(3, mr.unmatched.size)
    }

    @Test
    fun sameUuidAndVersionIsDeduplicated() {
        val base = File(tempDir(), "m")
        makePack(File(base, "resource_packs/P.rp"), manifestJson("P", U1, "resources", U2))
        makePack(File(base, "development_resource_packs/P.rp"), manifestJson("P", U1, "resources", U2))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertEquals(1, mr.rpOnly.size)
        assertTrue(mr.unmatched.single().reason.contains("مكررة"))
    }

    @Test
    fun dependencyVersionTooNewBlocksPair() {
        val base = File(tempDir(), "m")
        makePack(File(base, "V.rp"), manifestJson("V", U1, "resources", U2, "[1, 0, 0]"))
        makePack(File(base, "V.bp"), manifestJson("V", U3, "data", U4, deps = depsJson(U1 to "[2,0,0]")))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertEquals(0, mr.pairs.size)
        assertTrue(mr.unmatched.any { it.reason.contains("يتطلب نسخة RP") })
    }

    @Test
    fun suffixContradictingManifestIsRejected() {
        val base = File(tempDir(), "m")
        makePack(File(base, "T.rp"), manifestJson("T", U1, "data", U2))
        val pack = PackScanner.scan(root(base)).packs.single()
        assertFalse(pack.valid)
        assertTrue(pack.problems.any { it.contains("اسم المجلد") })
    }

    @Test
    fun matchesByDependencyWhenNamesDiffer() {
        val base = File(tempDir(), "m")
        makePack(File(base, "Visuals.rp"), manifestJson("V", U1, "resources", U2))
        makePack(File(base, "Logic.bp"), manifestJson("L", U3, "data", U4, deps = depsJson(U1 to "[1,0,0]")))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertEquals(1, mr.pairs.size)
        assertEquals(Confidence.DEPENDENCY, mr.pairs[0].confidence)
    }

    @Test
    fun nameOnlyPairIsFlagged() {
        val base = File(tempDir(), "m")
        makePack(File(base, "N.rp"), manifestJson("N", U1, "resources", U2))
        makePack(File(base, "N.rb"), manifestJson("N", U3, "data", U4))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertEquals(Confidence.NAME_ONLY, mr.pairs.single().confidence)
        assertTrue(mr.pairs.single().warnings.isNotEmpty())
    }

    // ---------- MCADDON و MCPACK ----------
    @Test
    fun buildsMcaddonFromMatchedPair() {
        val base = modsTree()
        val originalHashes = base.walkTopDown().filter { it.isFile }.associate { it.path to Hashing.sha256(it) }
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        val repo = repo()
        val out = ConvertEngine(repo).run(listOf(ConvertJob.Addon(mr.pairs[0])), "مودات", "t")
        val m = (out as ConvertOutcome.Success).manifest
        assertEquals("mcaddon/MyMod.mcaddon", m.files.single().path)
        val file = repo.dataFile(m.id, m.files.single().stored)
        val rep = McArchives.inspectPack(file, true)
        assertTrue(rep.problems.joinToString(), rep.ok)
        assertEquals(2, rep.packs.size)
        ZipFile(file, Charsets.UTF_8).use { zf ->
            val names = zf.entries().asSequence().map { it.name }.toSet()
            assertTrue(names.containsAll(setOf("MyMod_RP/manifest.json", "MyMod_BP/manifest.json", "MyMod_RP/textures/blocks/stone.png", "MyMod_BP/texts/ar_SA.lang")))
            assertFalse(names.contains("manifest.json"))
            val png = zf.getInputStream(zf.getEntry("MyMod_RP/textures/blocks/stone.png")).readBytes()
            assertEquals(Hashing.sha256(png), Hashing.sha256(File(base, "resource_packs/MyMod.rp/textures/blocks/stone.png")))
        }
        assertEquals(originalHashes, base.walkTopDown().filter { it.isFile }.associate { it.path to Hashing.sha256(it) })
    }

    @Test
    fun buildsMcpackForSinglePacksWithManifestAtRoot() {
        val base = modsTree()
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        val repo = repo()
        val out = ConvertEngine(repo).run(listOf(ConvertJob.Pack(mr.rpOnly[0]), ConvertJob.Pack(mr.bpOnly[0])), "n", "t")
        val m = (out as ConvertOutcome.Success).manifest
        assertEquals(setOf("mcpack/Solo_RP.mcpack", "mcpack/Lonely_BP.mcpack"), m.files.map { it.path }.toSet())
        for (e in m.files) {
            val rep = McArchives.inspectPack(repo.dataFile(m.id, e.stored), false)
            assertTrue(rep.problems.joinToString(), rep.ok)
            assertEquals(1, rep.packs.size)
        }
    }

    @Test
    fun refusesToMergePairWithProblems() {
        val base = File(tempDir(), "m")
        makePack(File(base, "V.rp"), manifestJson("V", U1, "resources", U2, "[1, 0, 0]"))
        makePack(File(base, "V.bp"), manifestJson("V", U3, "data", U4, deps = depsJson(U1 to "[2,0,0]")))
        val scan = PackScanner.scan(root(base)).packs
        val rp = scan.first { it.folderName == "V.rp" }; val bp = scan.first { it.folderName == "V.bp" }
        val repo = repo()
        val out = ConvertEngine(repo).run(listOf(ConvertJob.Addon(PackPair(rp, bp, "V", Confidence.NAME_ONLY, emptyList()))), "n", "t")
        assertTrue(out is ConvertOutcome.Failed)
        assertTrue((out as ConvertOutcome.Failed).failures.single().detail.contains("يتطلب نسخة"))
        assertTrue(repo.list().isEmpty())
    }

    @Test
    fun arabicPackAndFolderNames() {
        val base = File(tempDir(), "مودات")
        makePack(File(base, "مود عربي.rp"), manifestJson("مود", U1, "resources", U2))
        makePack(File(base, "مود عربي.rb"), manifestJson("مود", U3, "data", U4, deps = depsJson(U1 to "[1,0,0]")))
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        assertEquals("مود عربي", mr.pairs.single().base)
        val repo = repo()
        val m = (ConvertEngine(repo).run(listOf(ConvertJob.Addon(mr.pairs[0])), "n", "t") as ConvertOutcome.Success).manifest
        val file = repo.dataFile(m.id, m.files.single().stored)
        assertEquals("mcaddon/مود عربي.mcaddon", m.files.single().path)
        ZipFile(file, Charsets.UTF_8).use { zf ->
            assertNotNull(zf.getEntry("مود عربي_RP/texts/ar_SA.lang"))
        }
    }

    @Test
    fun incompleteModsAreReportedNotMerged() {
        val base = File(tempDir(), "m")
        makePack(File(base, "Half.rp"), manifestJson("Half", U1, "resources", U2))
        File(base, "Half.bp").mkdirs() // BP بلا manifest: ليس حزمة
        val scan = PackScanner.scan(root(base))
        assertEquals(1, scan.packs.size)
        val mr = PackMatcher.match(scan.packs)
        assertEquals(0, mr.pairs.size)
        assertEquals(1, mr.rpOnly.size)
    }

    // ---------- الاستيراد ----------
    private class FakeEnv(
        val snaps: ArrayDeque<Set<String>?> = ArrayDeque(),
        val failLaunch: Set<String> = emptySet(),
        val levelNames: Map<String, String> = emptyMap(),
    ) : ImportEnv {
        val launched = ArrayList<String>()
        override fun launch(item: ImportItem): String? {
            if (item.displayName in failLaunch) return "Minecraft غير مثبّت"
            launched += item.displayName; return null
        }
        override fun snapshot(kind: ImportKind): Set<String>? = snaps.removeFirstOrNull()
        override fun levelName(folder: String): String? = levelNames[folder]
    }

    private fun backupWithWorlds(repo: BackupRepository, vararg names: String): Manifest {
        val base = File(tempDir(), "mojang")
        names.forEachIndexed { i, n -> makeWorld(File(base, "minecraftWorlds/w$i"), n, i + 1) }
        val worlds = WorldScanner.scan(root(base)).worlds
        return (ConvertEngine(repo).run(worlds.map { ConvertJob.World(it) }, "عوالم", "t") as ConvertOutcome.Success).manifest
    }

    @Test
    fun importPlanVerifiesIntegrityAndStructure() {
        val repo = repo()
        val m = backupWithWorlds(repo, "A", "B", "C")
        // تلف ملف واحد
        val e1 = m.files[0]
        val f1 = repo.dataFile(m.id, e1.stored); val bytes = f1.readBytes(); bytes[10] = (bytes[10].toInt() xor 0x33).toByte(); f1.writeBytes(bytes)
        // ملف ثانٍ: zip صحيح الـ hash لكن البنية خاطئة (مجلد خارجي)
        val e2 = m.files[1]
        val f2 = repo.dataFile(m.id, e2.stored)
        ZipOutputStream(f2.outputStream()).use { z -> z.putNextEntry(ZipEntry("wrap/level.dat")); z.write(1); z.closeEntry() }
        val fixedManifest = m.copy(files = m.files.map { if (it.stored == e2.stored) it.copy(sha256 = Hashing.sha256(f2), size = f2.length()) else it })
        val items = ImportPlanner.items(repo, fixedManifest, ImportKind.WORLD)
        ImportPlanner.prepare(items)
        assertEquals(3, items.size)
        val s = items.map { it.status }
        assertEquals(1, s.count { it == ImportStatus.READY })
        assertTrue(items.first { it.id.endsWith(e1.stored) }.detail.contains("تالف"))
        assertTrue(items.first { it.id.endsWith(e2.stored) }.detail.contains("مجلد خارجي"))
    }

    @Test
    fun importSessionVerifiesOrAsksForConfirmation() {
        val repo = repo()
        val m = backupWithWorlds(repo, "A", "B", "C")
        val items = ImportPlanner.items(repo, m, ImportKind.WORLD)
        ImportPlanner.prepare(items)
        assertTrue(items.all { it.status == ImportStatus.READY })
        val log = ImportLog(File(tempDir(), "log.json"))
        val changes = ArrayList<String>()
        val env = FakeEnv(
            snaps = ArrayDeque(listOf(
                setOf("old"), setOf("old", "new1"),       // العنصر 1: ظهر عالم بالاسم المتوقع
                setOf("old", "new1"), setOf("old", "new1"), // العنصر 2: لم يظهر شيء
                null, null,                                  // العنصر 3: Shizuku غير متصل
            )),
            levelNames = mapOf("new1" to items[0].levelName!!),
        )
        val session = ImportSession(items, env) { changes += it.displayName + ":" + it.status; log.append(ImportLogEntry(1, "src", it.displayName, "WORLD", it.status.name, it.detail)) }
        var rounds = 0
        while (session.launchNext()) { session.onReturned(); rounds++ }
        assertEquals(3, rounds)
        assertEquals(ImportStatus.VERIFIED, items[0].status)
        assertEquals(ImportStatus.NEEDS_CONFIRM, items[1].status)
        assertEquals(ImportStatus.NEEDS_CONFIRM, items[2].status)
        assertTrue(items[2].detail.contains("Shizuku"))
        session.confirm(items[1])
        assertEquals(ImportStatus.CONFIRMED, items[1].status)
        assertEquals(3, env.launched.size)
        assertTrue(log.list().size >= 6)
        log.clear()
        assertTrue(log.list().isEmpty())
    }

    @Test
    fun importSessionRecordsLaunchFailureAndStops() {
        val repo = repo()
        val m = backupWithWorlds(repo, "A", "B")
        val items = ImportPlanner.items(repo, m, ImportKind.WORLD)
        ImportPlanner.prepare(items)
        val env = FakeEnv(failLaunch = setOf(items[0].displayName), snaps = ArrayDeque(listOf(null, null, null)))
        val session = ImportSession(items, env)
        assertTrue(session.launchNext())
        assertEquals(ImportStatus.FAILED, items[0].status)
        assertEquals(ImportStatus.OPENED, items[1].status)
        session.stop()
        assertFalse(session.launchNext())
    }

    @Test
    fun importPlansModsFromBackup() {
        val base = modsTree()
        val mr = PackMatcher.match(PackScanner.scan(root(base)).packs)
        val repo = repo()
        val m = (ConvertEngine(repo).run(listOf(ConvertJob.Addon(mr.pairs[0]), ConvertJob.Pack(mr.rpOnly[0])), "n", "t") as ConvertOutcome.Success).manifest
        val items = ImportPlanner.items(repo, m, ImportKind.MOD)
        assertEquals(2, items.size)
        ImportPlanner.prepare(items)
        assertTrue(items.all { it.status == ImportStatus.READY })
        assertEquals(0, ImportPlanner.items(repo, m, ImportKind.WORLD).size)
    }

    @Test
    fun backupsKeepOriginalsWhenConvertingTwice() {
        val repo = repo()
        val m1 = backupWithWorlds(repo, "A")
        val m2 = backupWithWorlds(repo, "A")
        assertTrue(m1.id != m2.id)
        assertEquals(2, repo.list().size)
    }

    private class FNode(
        override val name: String,
        override val isDirectory: Boolean,
        private val kids: List<SourceNode> = emptyList(),
        private val data: ByteArray = ByteArray(0),
        private val openError: Exception? = null,
        private val listError: Exception? = null,
    ) : SourceNode {
        override val size: Long get() = data.size.toLong()
        override val lastModified: Long get() = 0L
        override fun children(): List<SourceNode> { listError?.let { throw it }; return kids }
        override fun openInput(): InputStream { openError?.let { throw it }; return ByteArrayInputStream(data) }
    }
}
