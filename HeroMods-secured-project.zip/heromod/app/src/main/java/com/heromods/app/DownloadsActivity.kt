package com.heromods.app

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class DownloadsActivity : AppCompatActivity() {

    private val adapter = ItemAdapter()
    private lateinit var empty: View
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.title).setOnLongClickListener {
            showDiag()
            true
        }
        empty = findViewById(R.id.empty)

        val rv = findViewById<RecyclerView>(R.id.list)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        rv.itemAnimator = null
    }

    override fun onStart() {
        super.onStart()
        job = lifecycleScope.launch {
            while (isActive) {
                refresh()
                delay(600)
            }
        }
    }

    override fun onStop() {
        job?.cancel()
        super.onStop()
    }

    private fun failText(ctx: android.content.Context, d: DlItem): String = when {
        d.errorCode == Dl.ERR_INVALID_FILE -> ctx.getString(R.string.err_invalid_file)
        d.errorCode == android.app.DownloadManager.ERROR_INSUFFICIENT_SPACE -> ctx.getString(R.string.err_space)
        d.errorCode == android.app.DownloadManager.ERROR_DEVICE_NOT_FOUND -> ctx.getString(R.string.err_storage)
        d.errorCode in 400..599 -> ctx.getString(R.string.err_http, d.errorCode)
        d.errorCode == android.app.DownloadManager.ERROR_HTTP_DATA_ERROR ||
            d.errorCode == android.app.DownloadManager.ERROR_CANNOT_RESUME ||
            d.errorCode == android.app.DownloadManager.ERROR_TOO_MANY_REDIRECTS -> ctx.getString(R.string.err_network)
        else -> ctx.getString(R.string.failed)
    }

    private fun showDiag() {
        val text = Diag.dump().ifBlank { getString(R.string.diag_empty) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.diag_title)
            .setMessage(text)
            .setPositiveButton(R.string.copy) { _, _ ->
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("HERO MODS", text))
            }
            .setNegativeButton(R.string.close, null)
            .show()
        dlg.findViewById<TextView>(android.R.id.message)?.setTextIsSelectable(true)
    }

    private suspend fun refresh() {
        val ctx = applicationContext
        val list = withContext(Dispatchers.IO) {
            DownloadStore.edit(ctx) { l ->
                Dl.sync(ctx, l)
                l.map { it.copy() }
            }
        }
        adapter.submit(list)
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun mutate(block: (MutableList<DlItem>) -> Unit) {
        val l = DownloadStore.edit(this) { x ->
            Dl.sync(this, x)
            block(x)
            x.map { it.copy() }
        }
        adapter.submit(l)
        empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private inner class ItemAdapter : RecyclerView.Adapter<ItemAdapter.VH>() {
        private var items: List<DlItem> = emptyList()

        init {
            setHasStableIds(true)
        }

        fun submit(l: List<DlItem>) {
            items = l.map { it.copy() }
            notifyDataSetChanged()
        }

        override fun getItemCount() = items.size
        override fun getItemId(position: Int) = items[position].id

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.name)
            val info: TextView = v.findViewById(R.id.info)
            val bar: ProgressBar = v.findViewById(R.id.bar)
            val action: MaterialButton = v.findViewById(R.id.btnAction)
            val del: MaterialButton = v.findViewById(R.id.btnDelete)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            val d = items[position]
            val ctx = h.itemView.context
            h.name.text = d.fileName
            h.action.visibility = View.VISIBLE

            val total = d.total
            val pct = if (total > 0) ((d.downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
            when (d.status) {
                DlStatus.RUNNING, DlStatus.WAITING -> {
                    h.bar.visibility = View.VISIBLE
                    if (total > 0) {
                        h.bar.isIndeterminate = false
                        h.bar.max = 100
                        h.bar.progress = pct
                    } else h.bar.isIndeterminate = true
                    val sizes = if (total > 0)
                        "${Formatter.formatFileSize(ctx, d.downloaded)} / ${Formatter.formatFileSize(ctx, total)} • $pct%"
                    else Formatter.formatFileSize(ctx, d.downloaded)
                    h.info.text = if (d.status == DlStatus.WAITING)
                        ctx.getString(R.string.waiting_network) + " • " + sizes else sizes
                    h.action.setText(R.string.cancel)
                    h.action.setOnClickListener {
                        mutate { l -> l.firstOrNull { it.id == d.id }?.let { Dl.cancel(ctx, it) } }
                    }
                }
                DlStatus.DONE -> {
                    h.bar.visibility = View.GONE
                    var doneText = ctx.getString(R.string.done) + " • " + Formatter.formatFileSize(ctx, d.total)
                    if (!Dl.isMc(d.fileName) && !Dl.isApk(d.fileName)) doneText += "\n" + ctx.getString(R.string.unsupported_type)
                    h.info.text = doneText
                    val file = File(Dl.dir(ctx), d.fileName)
                    when {
                        Dl.isMc(d.fileName) -> {
                            h.action.setText(R.string.open_minecraft)
                            h.action.setOnClickListener { Opener.openInMinecraft(this@DownloadsActivity, file) }
                        }
                        Dl.isApk(d.fileName) -> {
                            h.action.setText(R.string.save_to_downloads)
                            h.action.setOnClickListener { Opener.saveToDownloads(this@DownloadsActivity, file) }
                        }
                        else -> {
                            h.action.setText(R.string.open_file)
                            h.action.setOnClickListener { Opener.openGeneric(this@DownloadsActivity, file) }
                        }
                    }
                }
                DlStatus.FAILED, DlStatus.CANCELED -> {
                    h.bar.visibility = View.GONE
                    h.info.text = if (d.status == DlStatus.FAILED) failText(ctx, d) else ctx.getString(R.string.canceled)
                    h.action.setText(R.string.retry)
                    h.action.setOnClickListener {
                        Dl.enqueue(applicationContext, d.url, null, null, d.fileName)
                        mutate { }
                    }
                }
            }
            h.del.setOnClickListener {
                mutate { l -> l.firstOrNull { it.id == d.id }?.let { Dl.delete(ctx, l, it) } }
            }
        }
    }
}
