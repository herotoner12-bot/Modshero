package com.heromods.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** يرسل إشعاراً واحداً لكل تنزيل اكتمل أو فشل؛ يضغط عليه المستخدم فتفتح صفحة التنزيلات. */
object Notifier {
    private const val CHANNEL = "downloads_done"

    fun flush(ctx: Context) {
        val pending = DownloadStore.edit(ctx) { l ->
            Dl.sync(ctx, l)
            val p = l.filter { (it.status == DlStatus.DONE || it.status == DlStatus.FAILED) && !it.notified }
            p.forEach { it.notified = true }
            p.map { it.copy() }
        }
        pending.forEach { post(ctx, it) }
    }

    private fun post(ctx: Context, d: DlItem) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_DEFAULT)
            )
            val nid = d.id.hashCode() and 0x7fffffff
            val open = PendingIntent.getActivity(
                ctx, nid,
                Intent(ctx, DownloadsActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val title = ctx.getString(if (d.status == DlStatus.DONE) R.string.notif_done else R.string.notif_failed)
            val n = Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_download)
                .setContentTitle(title)
                .setContentText(d.fileName)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(nid, n)
        } catch (_: Exception) {
        }
    }
}
