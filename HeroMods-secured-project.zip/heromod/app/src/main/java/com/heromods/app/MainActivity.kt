package com.heromods.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var root: View
    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var offline: View
    private lateinit var badge: TextView
    private lateinit var cm: ConnectivityManager
    private var failed = false
    private var callbackRegistered = false
    private var bypassUrl: String? = null
    private var badgeJob: Job? = null
    private var hadRunning = false
    private var unseenDone = false
    private var askedNotif = false

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* الإشعارات اختيارية */ }

    /** نطلب إذن الإشعارات (Android 13+) عند أول تنزيل فقط، لأنه مطلوب لإشعار الاكتمال. */
    private fun maybeAskNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val siteHost: String by lazy { Uri.parse(BuildConfig.SITE_URL).host?.lowercase() ?: "" }

    private val externalHosts = listOf(
        "youtube.com", "youtu.be", "t.me", "telegram.me", "wa.me", "instagram.com",
        "tiktok.com", "facebook.com", "twitter.com", "x.com", "discord.gg", "discord.com"
    )
    private val mediaExt = setOf("png", "jpg", "jpeg", "webp", "gif", "svg", "ico", "mp4", "webm", "mp3", "ogg")

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { if (failed) loadSite() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cm = getSystemService(ConnectivityManager::class.java)
        root = findViewById(R.id.root)
        web = findViewById(R.id.web)
        progress = findViewById(R.id.progress)
        offline = findViewById(R.id.offline)
        badge = findViewById(R.id.fabBadge)

        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }

        findViewById<FloatingActionButton>(R.id.fabDownloads).setOnClickListener { openDownloads() }
        findViewById<MaterialButton>(R.id.btnRetry).setOnClickListener { loadSite() }
        findViewById<MaterialButton>(R.id.btnOfflineDownloads).setOnClickListener { openDownloads() }

        setupWebView()

        onBackPressedDispatcher.addCallback(this) {
            if (!failed && web.canGoBack()) web.goBack() else finish()
        }

        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) {
            loadSite()
        }
    }

    private fun setupWebView() {
        web.setBackgroundColor(Color.parseColor("#12081F"))
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            // نسمح بالنوافذ المنبثقة لكن نعترضها نحن، فلا تظهر صفحة بيضاء أبداً
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.setDownloadListener { url, userAgent, contentDisposition, mime, _ ->
            Diag.log("download-listener $url cd=$contentDisposition mime=$mime")
            startDownload(url, contentDisposition, userAgent, null)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress >= 100) progress.visibility = View.GONE
            }

            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                val temp = WebView(this@MainActivity)
                temp.settings.javaScriptEnabled = true
                temp.settings.domStorageEnabled = true
                var handled = false
                fun finishTemp() {
                    temp.post {
                        try {
                            temp.stopLoading()
                            temp.destroy()
                        } catch (_: Exception) {
                        }
                    }
                }
                fun handle(url: String?) {
                    if (handled || url.isNullOrBlank() || url == "about:blank") return
                    handled = true
                    route(url, popup = true, ua = null)
                    finishTemp()
                }
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        handle(r.url.toString())
                        return true
                    }

                    override fun onPageStarted(v: WebView?, url: String?, f: Bitmap?) {
                        handle(url)
                    }
                }
                temp.setDownloadListener { url, ua, cd, mime, _ ->
                    if (!handled) {
                        handled = true
                        Diag.log("popup download-listener $url cd=$cd mime=$mime")
                        startDownload(url, cd, ua, null)
                        finishTemp()
                    }
                }
                temp.postDelayed({ if (!handled) { handled = true; finishTemp() } }, 20_000)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                route(request.url.toString(), popup = false, ua = null)

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (!failed) progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                if (!failed) offline.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showOffline()
            }
        }
    }

    private fun isFileHost(host: String, uri: Uri): Boolean {
        val e = Dl.ext(Uri.decode(uri.path ?: ""))
        if (e in mediaExt) return false
        if (host.endsWith(".r2.dev") || host.endsWith(".r2.cloudflarestorage.com")) return true
        if (host.endsWith(".supabase.co")) {
            val p = uri.path ?: ""
            return p.startsWith("/storage/") || p.startsWith("/functions/")
        }
        return false
    }

    /**
     * يقرر مصير أي رابط (تنقّل عادي أو نافذة منبثقة). يرجع true إذا تعامل معه التطبيق.
     * الهدف: روابط الملفات تبدأ تنزيلاً في الخلفية ولا يترك WebView صفحته أبداً.
     */
    private fun route(url: String, popup: Boolean, ua: String?): Boolean {
        Diag.log((if (popup) "popup " else "nav ") + url)
        if (!popup && url == bypassUrl) {
            bypassUrl = null
            return false
        }
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: return popup
        if (scheme == "blob") {
            if (popup) startDownload(url, null, ua, null)
            return popup
        }
        if (scheme == "about" || scheme == "data" || scheme == "javascript") return popup
        if (scheme != "http" && scheme != "https") {
            openExternal(uri)
            return true
        }
        val host = uri.host?.lowercase() ?: return popup
        if (Dl.isDownloadUrl(url)) {
            startDownload(url, null, ua, null)
            return true
        }
        if (externalHosts.any { host == it || host.endsWith(".$it") }) {
            openExternal(uri)
            return true
        }
        if (isFileHost(host, uri)) {
            probeAndHandle(url, ua, assumeFile = true)
            return true
        }
        if (popup) {
            if (host == siteHost || host.endsWith(".$siteHost")) loadInWeb(url)
            else probeAndHandle(url, ua, assumeFile = false)
            return true
        }
        return false
    }

    private fun loadInWeb(url: String) {
        bypassUrl = url
        web.loadUrl(url)
    }

    /** يتتبع التحويلات ويكشف هل الرابط ملف؛ إن كان ملفاً يبدأ التنزيل، وإلا يفتحه كصفحة. */
    private fun probeAndHandle(url: String, ua: String?, assumeFile: Boolean) {
        val cookie = CookieManager.getInstance().getCookie(url)
        val agent = ua ?: web.settings.userAgentString
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { Probe.run(url, agent, cookie) }
            Diag.log("probe file=${r.isFile} name=${r.fileName} mime=${r.mime} final=${r.finalUrl} err=${r.error}")
            when {
                r.isFile -> startDownload(url, null, agent, r.fileName)
                r.error != null && assumeFile -> startDownload(url, null, agent, null)
                else -> loadInWeb(url)
            }
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
        }
    }

    private fun startDownload(url: String, contentDisposition: String?, userAgent: String?, name: String?) {
        if (url.startsWith("data:") || url.startsWith("blob:")) {
            Toast.makeText(this, R.string.blob_unsupported, Toast.LENGTH_LONG).show()
            return
        }
        val agent = userAgent ?: web.settings.userAgentString
        val result = Dl.enqueue(applicationContext, url, agent, contentDisposition, name?.let { Dl.sanitize(it) })
        Diag.log("enqueue $result url=$url name=$name")
        if (result == EnqResult.STARTED) maybeAskNotifications()
        val msg = when (result) {
            EnqResult.STARTED -> R.string.download_started
            EnqResult.EXISTS -> R.string.already_downloaded
            EnqResult.RUNNING -> R.string.already_running
            EnqResult.ERROR -> R.string.download_error
        }
        Snackbar.make(root, msg, Snackbar.LENGTH_LONG)
            .setAction(R.string.downloads) { openDownloads() }
            .show()
    }

    private fun openDownloads() {
        unseenDone = false
        startActivity(Intent(this, DownloadsActivity::class.java))
    }

    private fun isOnline(): Boolean {
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** عند توفر الإنترنت يُحمَّل أحدث محتوى من الموقع دائماً. */
    private fun loadSite() {
        if (!isOnline()) {
            showOffline(); return
        }
        failed = false
        offline.visibility = View.GONE
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.loadUrl(BuildConfig.SITE_URL)
    }

    private fun showOffline() {
        failed = true
        progress.visibility = View.GONE
        offline.visibility = View.VISIBLE
    }

    /** شارة على زر السهم: نسبة التقدم أثناء التحميل، وعلامة ✓ عند الاكتمال. */
    private suspend fun updateBadge() {
        val ctx = applicationContext
        val items = withContext(Dispatchers.IO) {
            Notifier.flush(ctx)
            DownloadStore.edit(ctx) { l ->
                Dl.sync(ctx, l)
                l.map { it.copy() }
            }
        }
        val running = items.filter { it.status == DlStatus.RUNNING || it.status == DlStatus.WAITING }
        if (running.isNotEmpty()) {
            hadRunning = true
            badge.text = if (running.size == 1) {
                val d = running[0]
                if (d.total > 0) "${((d.downloaded * 100) / d.total).toInt().coerceIn(0, 100)}%" else "…"
            } else running.size.toString()
            badge.visibility = View.VISIBLE
        } else {
            if (hadRunning && items.any { it.status == DlStatus.DONE }) unseenDone = true
            hadRunning = false
            if (unseenDone) {
                badge.text = "✓"
                badge.visibility = View.VISIBLE
            } else {
                badge.visibility = View.GONE
            }
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            cm.registerDefaultNetworkCallback(netCallback)
            callbackRegistered = true
        } catch (_: Exception) {
        }
    }

    override fun onStop() {
        if (callbackRegistered) {
            try {
                cm.unregisterNetworkCallback(netCallback)
            } catch (_: Exception) {
            }
            callbackRegistered = false
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        badgeJob = lifecycleScope.launch {
            while (isActive) {
                updateBadge()
                delay(800)
            }
        }
    }

    override fun onPause() {
        badgeJob?.cancel()
        web.onPause()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
