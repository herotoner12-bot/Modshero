package com.heromods.app

import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL

data class ProbeResult(
    val finalUrl: String,
    val fileName: String?,
    val mime: String?,
    val isFile: Boolean,
    val error: String? = null
)

/** يتتبع التحويلات (redirects) ويكشف هل الرابط ملف للتحميل أم صفحة عادية، دون تنزيل المحتوى. */
object Probe {
    private fun isPageMime(m: String) =
        m.startsWith("text/") || m.contains("html") || m.contains("json") || m.contains("xml") ||
            m.startsWith("image/") || m.startsWith("video/") || m.startsWith("audio/")

    fun run(url: String, ua: String?, cookie: String?): ProbeResult {
        var cur = url
        val firstHost = try {
            URL(url).host
        } catch (_: Exception) {
            ""
        }
        try {
            for (hop in 0 until 8) {
                val c = URL(cur).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 10_000
                c.readTimeout = 10_000
                c.setRequestProperty("Range", "bytes=0-0")
                if (!ua.isNullOrBlank()) c.setRequestProperty("User-Agent", ua)
                if (!cookie.isNullOrBlank() && URL(cur).host == firstHost) c.setRequestProperty("Cookie", cookie)
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location")
                    c.disconnect()
                    if (loc.isNullOrBlank()) return ProbeResult(cur, null, null, false, "redirect without Location")
                    cur = URL(URL(cur), loc).toString()
                    continue
                }
                val cd = c.getHeaderField("Content-Disposition")
                val mime = c.contentType?.substringBefore(';')?.trim()?.lowercase()
                c.disconnect()
                if (code >= 400) return ProbeResult(cur, null, mime, false, "HTTP $code")
                val fromUrl = Uri.decode(Uri.parse(cur).lastPathSegment ?: "")
                val name = Dl.parseDisposition(cd) ?: fromUrl.ifBlank { null }
                val attachment = cd?.contains("attachment", ignoreCase = true) == true
                val isFile = attachment || Dl.isDownloadUrl(cur) || (mime != null && !isPageMime(mime))
                return ProbeResult(cur, name?.let { Dl.sanitize(it) }, mime, isFile)
            }
            return ProbeResult(cur, null, null, false, "too many redirects")
        } catch (e: Exception) {
            return ProbeResult(cur, null, null, false, e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }
}
