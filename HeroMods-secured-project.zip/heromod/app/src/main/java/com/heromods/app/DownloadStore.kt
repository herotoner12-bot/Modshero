package com.heromods.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** سجل التنزيلات محفوظ محلياً في ملف JSON — بلا حد لعدد العناصر. */
object DownloadStore {
    private const val FILE = "downloads.json"
    private val lock = Any()

    fun load(ctx: Context): MutableList<DlItem> = synchronized(lock) {
        val list = mutableListOf<DlItem>()
        val f = File(ctx.filesDir, FILE)
        if (f.exists()) {
            try {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        DlItem(
                            id = o.getLong("id"),
                            url = o.getString("url"),
                            fileName = o.getString("fileName"),
                            status = DlStatus.valueOf(o.getString("status")),
                            downloaded = o.optLong("downloaded", 0L),
                            total = o.optLong("total", -1L),
                            addedAt = o.optLong("addedAt", 0L),
                            errorCode = o.optInt("errorCode", 0),
                            // العناصر القديمة تُعتبر مُشعَراً عنها كي لا تُرسل لها إشعارات بأثر رجعي
                            notified = o.optBoolean("notified", true)
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
        list
    }

    /** قراءة وتعديل وحفظ بشكل ذري، لمنع ضياع العناصر عند تزامن التحديثات. */
    fun <T> edit(ctx: Context, block: (MutableList<DlItem>) -> T): T = synchronized(lock) {
        val l = load(ctx)
        val r = block(l)
        save(ctx, l)
        r
    }

    fun save(ctx: Context, list: List<DlItem>) {
        synchronized(lock) {
            val arr = JSONArray()
            for (d in list) {
                arr.put(
                    JSONObject()
                        .put("id", d.id)
                        .put("url", d.url)
                        .put("fileName", d.fileName)
                        .put("status", d.status.name)
                        .put("downloaded", d.downloaded)
                        .put("total", d.total)
                        .put("addedAt", d.addedAt)
                        .put("errorCode", d.errorCode)
                        .put("notified", d.notified)
                )
            }
            try {
                File(ctx.filesDir, FILE).writeText(arr.toString())
            } catch (_: Exception) {
            }
        }
    }
}
