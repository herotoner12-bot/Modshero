package com.heromods.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import java.io.File

enum class EnqResult { STARTED, EXISTS, RUNNING, ERROR }

object Dl {
    val MC_EXT = setOf("mcaddon", "mcpack", "mcworld", "mctemplate")
    const val MINECRAFT_PKG = "com.mojang.minecraftpe"
    const val ERR_INVALID_FILE = -1

    fun ext(name: String): String = name.substringAfterLast('.', "").lowercase()
    fun isApk(name: String) = ext(name) == "apk"
    fun isMc(name: String) = ext(name) in MC_EXT

    /** هل الرابط يشير إلى ملف ماين كرافت أو APK؟ */
    fun isDownloadUrl(url: String): Boolean {
        val path = try {
            Uri.parse(url).path ?: ""
        } catch (_: Exception) {
            ""
        }
        val e = ext(Uri.decode(path))
        return e == "apk" || e in MC_EXT
    }

    fun dir(ctx: Context): File =
        ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(ctx.filesDir, "Download").also { it.mkdirs() }

    /** ملفات MCADDON/MCPACK/MCWORLD هي أرشيفات ZIP؛ نتأكد من الترويسة PK حتى لا نحتفظ بصفحة خطأ محفوظة باسم ملف. */
    fun looksLikeZip(f: File): Boolean = try {
        f.inputStream().use {
            val b = ByteArray(2)
            it.read(b) == 2 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()
        }
    } catch (_: Exception) {
        false
    }

    private fun key(u: String) = u.substringBefore('?')

    fun parseDisposition(cd: String?): String? {
        if (cd.isNullOrBlank()) return null
        Regex("""filename\*\s*=\s*(?:UTF-8|utf-8)?''([^;]+)""").find(cd)?.let {
            return Uri.decode(it.groupValues[1].trim().trim('"'))
        }
        Regex("""filename\s*=\s*"?([^";]+)"?""").find(cd)?.let {
            return it.groupValues[1].trim()
        }
        return null
    }

    fun resolveName(url: String, cd: String?): String {
        val fromHeader = parseDisposition(cd)
        val n = if (!fromHeader.isNullOrBlank()) fromHeader
        else Uri.decode(Uri.parse(url).lastPathSegment ?: "")
        return sanitize(n)
    }

    fun sanitize(n: String): String {
        var s = n.replace(Regex("""[\\/:*?"<>|\u0000-\u001F]"""), "_").trim().trim('.')
        if (s.isEmpty()) s = "download"
        if (s.length > 120) {
            val e = ext(s)
            val cut = s.take(110)
            s = if (e.isNotEmpty() && e.length < 10) "$cut.$e" else cut
        }
        return s
    }

    fun uniqueName(dir: File, name: String): String {
        if (!File(dir, name).exists()) return name
        val base = name.substringBeforeLast('.', name)
        val e = name.substringAfterLast('.', "")
        var i = 1
        while (true) {
            val c = if (e.isEmpty()) "$base ($i)" else "$base ($i).$e"
            if (!File(dir, c).exists()) return c
            i++
        }
    }

    /** يبدأ تنزيلاً جديداً عبر DownloadManager، ويمنع تكرار نفس الملف. */
    fun enqueue(
        ctx: Context,
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        forcedName: String? = null
    ): EnqResult = DownloadStore.edit(ctx) { list ->
        sync(ctx, list)
        val dir = dir(ctx)

        var result: EnqResult? = null
        val same = list.firstOrNull { key(it.url) == key(url) }
        if (same != null) {
            if (same.status == DlStatus.DONE && File(dir, same.fileName).exists()) {
                result = EnqResult.EXISTS
            } else if (same.status == DlStatus.RUNNING || same.status == DlStatus.WAITING) {
                result = EnqResult.RUNNING
            } else {
                File(dir, same.fileName).delete()
                list.remove(same)
            }
        }

        if (result != null) {
            result
        } else {
            val name = uniqueName(dir, forcedName ?: resolveName(url, contentDisposition))
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                    .setTitle(name)
                    .setDescription("HERO MODS")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true)
                    .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, name)
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                if (!userAgent.isNullOrBlank()) req.addRequestHeader("User-Agent", userAgent)
                val dm = ctx.getSystemService(DownloadManager::class.java)
                val id = dm.enqueue(req)
                list.add(0, DlItem(id, url, name, DlStatus.RUNNING))
                EnqResult.STARTED
            } catch (e: Exception) {
                Diag.log("enqueue error: ${e.javaClass.simpleName} ${e.message}")
                EnqResult.ERROR
            }
        }
    }

    /** يحدّث حالة ونسبة كل التنزيلات (DownloadManager + تنزيلات blob). */
    fun sync(ctx: Context, list: MutableList<DlItem>) {
        val dm = ctx.getSystemService(DownloadManager::class.java)
        val dir = dir(ctx)
        for (item in list.toList()) {
            val file = File(dir, item.fileName)
            if (item.status == DlStatus.DONE) {
                if (!file.exists()) list.remove(item)
                continue
            }
            if (item.status == DlStatus.FAILED || item.status == DlStatus.CANCELED) continue

            val cursor = dm.query(DownloadManager.Query().setFilterById(item.id))
            cursor.use { cur ->
                if (cur == null || !cur.moveToFirst()) {
                    item.status = DlStatus.CANCELED
                } else {
                    val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    item.downloaded = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    item.total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    item.status = when (st) {
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            val exists = file.exists() && file.length() > 0
                            val valid = exists && when {
                                isMc(item.fileName) -> looksLikeZip(file)
                                isApk(item.fileName) -> ctx.packageManager.getPackageArchiveInfo(file.absolutePath, 0) != null
                                else -> true
                            }
                            if (valid) {
                                item.total = file.length()
                                item.downloaded = item.total
                                DlStatus.DONE
                            } else {
                                if (exists) {
                                    file.delete()
                                    item.errorCode = ERR_INVALID_FILE
                                }
                                DlStatus.FAILED
                            }
                        }
                        DownloadManager.STATUS_FAILED -> {
                            item.errorCode = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                            DlStatus.FAILED
                        }
                        DownloadManager.STATUS_PAUSED -> DlStatus.WAITING
                        else -> DlStatus.RUNNING
                    }
                }
            }
        }
    }

    private fun stop(ctx: Context, item: DlItem) {
        try {
            ctx.getSystemService(DownloadManager::class.java).remove(item.id)
        } catch (_: Exception) {
        }
    }

    fun cancel(ctx: Context, item: DlItem) {
        stop(ctx, item)
        File(dir(ctx), item.fileName).delete()
        item.status = DlStatus.CANCELED
    }

    fun delete(ctx: Context, list: MutableList<DlItem>, item: DlItem) {
        if (item.status == DlStatus.RUNNING || item.status == DlStatus.WAITING) stop(ctx, item)
        File(dir(ctx), item.fileName).delete()
        list.remove(item)
    }
}
