package com.heromods.app

enum class DlStatus { RUNNING, WAITING, DONE, FAILED, CANCELED }

data class DlItem(
    var id: Long,
    val url: String,
    val fileName: String,
    var status: DlStatus,
    var downloaded: Long = 0L,
    var total: Long = -1L,
    val addedAt: Long = System.currentTimeMillis(),
    var errorCode: Int = 0,
    var notified: Boolean = false
)
