package com.heromods.app

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يستقبل اكتمال أي تنزيل من DownloadManager حتى لو كان التطبيق مغلقاً. */
class DownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val app = context.applicationContext
        val pr = goAsync()
        Thread {
            try {
                Notifier.flush(app)
            } finally {
                pr.finish()
            }
        }.start()
    }
}
