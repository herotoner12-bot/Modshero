package com.heromods.app

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object Opener {
    private fun toast(ctx: Context, res: Int) = Toast.makeText(ctx, res, Toast.LENGTH_LONG).show()

    private fun uriFor(ctx: Context, file: File): Uri =
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)

    private fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    /** مشاركة الملف مع Minecraft Bedrock عبر FileProvider + Intent. */
    fun openInMinecraft(ctx: Context, file: File) {
        if (!file.exists()) {
            toast(ctx, R.string.file_missing); return
        }
        if (!isInstalled(ctx, Dl.MINECRAFT_PKG)) {
            toast(ctx, R.string.mc_not_installed); return
        }
        val uri = uriFor(ctx, file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/octet-stream")
            .setPackage(Dl.MINECRAFT_PKG)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        i.clipData = ClipData.newRawUri(file.name, uri)
        if (i.resolveActivity(ctx.packageManager) == null) {
            toast(ctx, R.string.import_failed); return
        }
        try {
            ctx.startActivity(i)
            // لا نعرف نتيجة الاستيراد من داخل Minecraft، فلا نعلن نجاحه
            toast(ctx, R.string.sent_to_minecraft)
        } catch (_: Exception) {
            toast(ctx, R.string.import_failed)
        }
    }

    /**
     * ملفات APK لا يثبّتها التطبيق (لا صلاحية تثبيت). نحفظ نسخة في مجلد التنزيلات العام
     * ليفتحها المستخدم بنفسه من تطبيق الملفات، فيظهر مثبّت Android الرسمي من هناك.
     */
    fun saveToDownloads(ctx: Context, file: File) {
        if (!file.exists()) {
            toast(ctx, R.string.file_missing); return
        }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HERO MODS")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insert failed")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            toast(ctx, R.string.saved_to_downloads)
        } catch (_: Exception) {
            toast(ctx, R.string.save_failed)
        }
    }

    fun openGeneric(ctx: Context, file: File) {
        if (!file.exists()) {
            toast(ctx, R.string.file_missing); return
        }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(Dl.ext(file.name)) ?: "*/*"
        val uri = uriFor(ctx, file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        i.clipData = ClipData.newRawUri(file.name, uri)
        try {
            ctx.startActivity(Intent.createChooser(i, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            toast(ctx, R.string.no_app_for_file)
        }
    }
}
