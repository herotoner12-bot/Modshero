package com.heromods.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** سجل تشخيصي صغير: يسجل الروابط التي اعترضها التطبيق لتسهيل معرفة آلية التحميل الحقيقية في الموقع. */
object Diag {
    private val buf = ArrayList<String>()

    @Synchronized
    fun log(s: String) {
        if (buf.size >= 80) buf.removeAt(0)
        buf.add(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + s)
    }

    @Synchronized
    fun dump(): String = buf.joinToString("\n\n")
}
