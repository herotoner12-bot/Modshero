plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.heromods.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.heromods.app"
        minSdk = 29
        targetSdk = 36
        versionCode = 4
        versionName = "1.3.0"
        // رابط الموقع — غيّره هنا فقط إذا تغيّر الدومين
        buildConfigField("String", "SITE_URL", "\"https://minecraft-mod-hub.lovable.app/\"")
    }

    signingConfigs {
        create("release") {
            // The keystore is supplied by GitHub Actions from encrypted repository secrets.
            val keystorePath = System.getenv("KEYSTORE_PATH")
                ?: throw GradleException("KEYSTORE_PATH is not configured")
            val keystorePassword = System.getenv("KS_PASS")
                ?: throw GradleException("KS_PASS is not configured")
            storeFile = file(keystorePath)
            storePassword = keystorePassword
            keyAlias = "heromods"
            keyPassword = keystorePassword
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
