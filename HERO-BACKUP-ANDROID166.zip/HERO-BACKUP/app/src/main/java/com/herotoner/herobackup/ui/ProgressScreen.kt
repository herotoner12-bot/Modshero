package com.herotoner.herobackup.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.BackupStatus
import com.herotoner.herobackup.core.FailureEntry
import com.herotoner.herobackup.core.Manifest
import com.herotoner.herobackup.core.RestoreReport
import com.herotoner.herobackup.work.Jobs

@Composable
fun ProgressScreen(vm: MainViewModel, onHome: () -> Unit, onBackups: () -> Unit) {
    val job by vm.job.collectAsStateWithLifecycle()
    val j = job
    val title = when (j?.tag) {
        Jobs.TAG_BACKUP -> R.string.title_backup_progress
        Jobs.TAG_RESTORE -> R.string.title_restore_progress
        Jobs.TAG_TRANSFER -> R.string.title_transfer_progress
        else -> R.string.title_progress
    }
    ScreenScaffold(stringResource(title), onBack = onHome) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (j == null) {
                item { Muted(stringResource(R.string.no_job)) }
                item { BigButton(stringResource(R.string.home), onHome) }
            } else if (j.active) {
                item { ActivePanel(vm, j) }
            } else {
                item { FinishedPanel(vm, j, onHome, onBackups) }
            }
        }
    }
}

@Composable
fun ActivePanel(vm: MainViewModel, j: JobUi) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val p = j.progress
    val animated by animateFloatAsState(p?.fraction ?: 0f, tween(300), label = "progress")
    HeroCard {
        if (p == null) {
            Text(
                stringResource(if (j.state.name == "RUNNING") R.string.preparing else R.string.waiting),
                color = HeroColors.Text, fontSize = 16.sp,
            )
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                color = HeroColors.Primary, trackColor = HeroColors.Bg,
            )
        } else {
            Text(
                "${(animated * 100).toInt()}%",
                color = HeroColors.Primary, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold,
            )
            LinearProgressIndicator(
                progress = { animated },
                modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)),
                color = HeroColors.Primary, trackColor = HeroColors.Bg,
            )
            Text(
                stringResource(R.string.files_done_of, p.filesDone, p.filesTotal),
                color = HeroColors.Text, fontSize = 15.sp,
            )
            Muted(stringResource(R.string.files_remaining, (p.filesTotal - p.filesDone).coerceAtLeast(0)))
            Muted(stringResource(R.string.bytes_progress, formatBytes(ctx, p.bytesDone), formatBytes(ctx, p.bytesTotal)))
            if (p.current.isNotBlank()) {
                Text(
                    p.current, color = HeroColors.TextSecondary, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Muted(stringResource(R.string.keep_running_note))
    }
    BigButton(stringResource(R.string.cancel_operation), { confirm = true }, primary = false, danger = true)
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.cancel_confirm_title)) },
            text = { Text(stringResource(R.string.cancel_confirm_text)) },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.cancelJob() }) {
                    Text(stringResource(R.string.yes_cancel), color = HeroColors.Danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.continue_op)) }
            },
            containerColor = HeroColors.Card,
            titleContentColor = HeroColors.Text,
            textContentColor = HeroColors.TextSecondary,
        )
    }
}

@Composable
fun FailureList(items: List<FailureEntry>) {
    val ctx = LocalContext.current
    items.take(30).forEach {
        Column {
            Text(it.path.ifBlank { "—" }, color = HeroColors.Text, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(failureText(ctx, it.code), color = HeroColors.Warning, fontSize = 12.sp)
        }
    }
    if (items.size > 30) Muted(stringResource(R.string.and_more, items.size - 30))
}

@Composable
fun FinishedPanel(vm: MainViewModel, j: JobUi, onHome: () -> Unit, onBackups: () -> Unit) {
    val ctx = LocalContext.current
    val finish = { vm.dismissJob(); onHome() }
    val status = j.status
    when (j.tag) {
        Jobs.TAG_BACKUP -> {
            val manifest by produceState<Manifest?>(null, j.backupId) { value = j.backupId?.let { vm.manifest(it) } }
            val m = manifest
            when {
                status == Jobs.ST_SUCCESS && m != null -> {
                    HeroCard {
                        Text(
                            stringResource(if (m.status == BackupStatus.COMPLETE) R.string.backup_done else R.string.backup_done_partial),
                            color = if (m.status == BackupStatus.COMPLETE) HeroColors.Primary else HeroColors.Warning,
                            fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        )
                        Text(m.name, color = HeroColors.Text, fontSize = 15.sp)
                        Muted(stringResource(R.string.report_copied, m.files.size))
                        Muted(stringResource(R.string.report_size, formatBytes(ctx, m.totalBytes)))
                        Muted(stringResource(R.string.report_failed, m.failures.size))
                        Muted(stringResource(R.string.report_sha_ok))
                    }
                    if (m.failures.isNotEmpty()) {
                        HeroCard {
                            SectionTitle(stringResource(R.string.failed_files))
                            FailureList(m.failures)
                        }
                    }
                    InfoBanner(stringResource(R.string.private_storage_warning), warning = true)
                    BigButton(stringResource(R.string.show_backups), { vm.dismissJob(); onBackups() })
                    BigButton(stringResource(R.string.home), finish, primary = false)
                }
                status == Jobs.ST_SUCCESS -> Muted(stringResource(R.string.loading))
                status == Jobs.ST_EMPTY -> {
                    InfoBanner(stringResource(R.string.backup_empty), warning = true)
                    BigButton(stringResource(R.string.home), finish)
                }
                status == Jobs.ST_CANCELLED || j.state.name == "CANCELLED" -> {
                    InfoBanner(stringResource(R.string.backup_cancelled))
                    BigButton(stringResource(R.string.home), finish)
                }
                else -> {
                    InfoBanner(
                        stringResource(R.string.backup_failed) + "\n" + failureText(ctx, j.code ?: ""),
                        warning = true,
                    )
                    BigButton(stringResource(R.string.home), finish)
                }
            }
        }
        Jobs.TAG_RESTORE -> {
            val report by produceState<RestoreReport?>(null, j.state) { value = vm.restoreReport() }
            val r = report
            if (r == null) {
                if (status == Jobs.ST_FAILED) {
                    InfoBanner(stringResource(R.string.restore_failed) + "\n" + failureText(ctx, j.code ?: ""), warning = true)
                } else if (j.state.name == "CANCELLED") {
                    InfoBanner(stringResource(R.string.restore_cancelled))
                } else Muted(stringResource(R.string.loading))
            } else {
                HeroCard {
                    Text(
                        stringResource(if (r.cancelled) R.string.restore_cancelled else R.string.restore_report_title),
                        color = HeroColors.Primary, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    )
                    Text(stringResource(R.string.report_restored, r.restored.size), color = HeroColors.Text)
                    Muted(stringResource(R.string.report_renamed, r.renamed.size))
                    Muted(stringResource(R.string.report_skipped, r.skipped.size))
                    Text(
                        stringResource(R.string.report_failed, r.failed.size),
                        color = if (r.failed.isEmpty()) HeroColors.TextSecondary else HeroColors.Warning,
                    )
                }
                if (r.failed.isNotEmpty()) {
                    HeroCard { SectionTitle(stringResource(R.string.failed_files)); FailureList(r.failed) }
                }
                if (r.skipped.isNotEmpty()) {
                    HeroCard {
                        SectionTitle(stringResource(R.string.skipped_files))
                        r.skipped.take(20).forEach {
                            Text(it, color = HeroColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (r.skipped.size > 20) Muted(stringResource(R.string.and_more, r.skipped.size - 20))
                    }
                }
                InfoBanner(stringResource(R.string.restore_import_hint))
            }
            BigButton(stringResource(R.string.home), finish)
        }
        else -> {
            val report by produceState<com.herotoner.herobackup.ui.TransferReport?>(null, j.state) { value = vm.transferReport() }
            val r = report
            if (r == null) {
                if (status == Jobs.ST_FAILED) {
                    InfoBanner(stringResource(R.string.transfer_failed) + "\n" + failureText(ctx, j.code ?: ""), warning = true)
                } else Muted(stringResource(R.string.loading))
            } else {
                HeroCard {
                    if (r.mode == "export") {
                        val okText = when {
                            r.cancelled -> R.string.transfer_cancelled
                            r.already -> R.string.export_already
                            r.failed.isEmpty() -> R.string.export_done
                            else -> R.string.export_partial
                        }
                        Text(stringResource(okText), color = HeroColors.Primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        if (r.failed.isEmpty() && !r.cancelled) Muted(stringResource(R.string.export_hint))
                    } else {
                        Text(
                            stringResource(if (r.cancelled) R.string.transfer_cancelled else R.string.import_report_title),
                            color = HeroColors.Primary, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        )
                        Text(stringResource(R.string.import_count, r.imported.size), color = HeroColors.Text)
                        Muted(stringResource(R.string.import_skipped, r.skipped.size))
                    }
                    if (r.failed.isNotEmpty()) {
                        Text(stringResource(R.string.report_failed, r.failed.size), color = HeroColors.Warning)
                        r.failed.take(20).forEach { (path, code) ->
                            Text(
                                path.ifBlank { "—" } + " — " + failureText(ctx, code),
                                color = HeroColors.TextSecondary, fontSize = 12.sp,
                            )
                        }
                    }
                }
            }
            BigButton(stringResource(R.string.show_backups), { vm.dismissJob(); onBackups() })
            BigButton(stringResource(R.string.home), finish, primary = false)
        }
    }
}
