package com.herotoner.herobackup.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import com.herotoner.herobackup.R

/** صلاحية «الوصول إلى جميع الملفات» (MANAGE_EXTERNAL_STORAGE). لا تضمن الوصول إلى Android/data. */
object AllFilesAccess {
    /** الصلاحية موجودة كإعداد رسمي من Android 11 (API 30) فما فوق. */
    val applicable: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    fun isGranted(): Boolean =
        applicable && try { Environment.isExternalStorageManager() } catch (e: Exception) { false }

    fun open(ctx: Context) {
        val appIntent = Intent(
            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:" + ctx.packageName),
        )
        try {
            ctx.startActivity(appIntent)
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                Toast.makeText(ctx, R.string.perm_cannot_open, Toast.LENGTH_LONG).show()
            }
        }
    }
}
