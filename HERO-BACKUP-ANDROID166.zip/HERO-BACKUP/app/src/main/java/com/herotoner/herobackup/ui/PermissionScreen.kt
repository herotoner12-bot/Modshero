package com.herotoner.herobackup.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.herotoner.herobackup.R
import com.herotoner.herobackup.data.AllFilesAccess

@Composable
fun PermissionScreen(vm: MainViewModel, onBack: () -> Unit, onBrowse: () -> Unit) {
    val ctx = LocalContext.current
    val granted by vm.allFiles.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.refreshPermission() }

    ScreenScaffold(stringResource(R.string.title_permission), onBack) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroCard {
                    Icon(
                        if (granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (granted) HeroColors.Primary else HeroColors.Warning,
                    )
                    Text(
                        stringResource(
                            when {
                                !AllFilesAccess.applicable -> R.string.perm_status_na
                                granted -> R.string.perm_status_on
                                else -> R.string.perm_status_off
                            }
                        ),
                        color = HeroColors.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
            item { InfoBanner(stringResource(R.string.perm_explain)) }
            item { InfoBanner(stringResource(R.string.perm_limits), warning = true) }
            if (AllFilesAccess.applicable) {
                item {
                    BigButton(
                        stringResource(if (granted) R.string.perm_manage else R.string.perm_open_settings),
                        { AllFilesAccess.open(ctx) },
                    )
                }
                if (granted) {
                    item {
                        BigButton(
                            stringResource(R.string.browse_files), onBrowse,
                            iconRes = R.drawable.ic_folder, primary = false,
                        )
                    }
                }
            }
        }
    }
}
