package com.herotoner.herobackup.ui

import android.content.Context
import com.herotoner.herobackup.R
import com.herotoner.herobackup.core.FailureCode
import com.herotoner.herobackup.core.Kind
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatBytes(ctx: Context, bytes: Long): String {
    if (bytes < 1024) return "$bytes " + ctx.getString(R.string.unit_b)
    val units = listOf(R.string.unit_kb, R.string.unit_mb, R.string.unit_gb, R.string.unit_tb)
    var v = bytes.toDouble()
    var i = -1
    while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f", v) + " " + ctx.getString(units[i])
}

fun formatDate(millis: Long): String =
    SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(Date(millis))

fun failureText(ctx: Context, code: String): String = ctx.getString(
    when (code) {
        FailureCode.PERMISSION_DENIED -> R.string.fail_permission
        FailureCode.IO_ERROR -> R.string.fail_io
        FailureCode.VERIFY_FAILED -> R.string.fail_verify
        FailureCode.CORRUPT -> R.string.fail_corrupt
        FailureCode.MISSING -> R.string.fail_missing
        FailureCode.TARGET_ERROR -> R.string.fail_target
        FailureCode.NO_SPACE -> R.string.fail_no_space
        else -> R.string.fail_invalid
    }
)

fun kindLabel(kind: Kind): Int = when (kind) {
    Kind.WORLD -> R.string.kind_world
    Kind.ADDON -> R.string.kind_addon
    Kind.PACK -> R.string.kind_pack
    Kind.RESOURCE_PACK -> R.string.kind_resource
    Kind.BEHAVIOR_PACK -> R.string.kind_behavior
    Kind.SKIN_PACK -> R.string.kind_skin
    Kind.ZIP -> R.string.kind_zip
    Kind.OTHER -> R.string.kind_other
}
